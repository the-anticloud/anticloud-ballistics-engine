// WASM bindings for the ballistics engine with full CLI feature parity
use serde_json;
use wasm_bindgen::prelude::*;

use crate::atmosphere::{resolve_station_conditions_with_pressure_mode, PressureReferenceMode};
use crate::bc_table_5d::Bc5dTable;
#[cfg(feature = "wasm-estimate-bc")]
use crate::cli_api::estimate_bc_fit;
#[cfg(feature = "wasm-monte-carlo")]
use crate::cli_api::run_monte_carlo_with_direction_std_dev;
#[cfg(feature = "wasm-estimate-bc")]
use crate::cli_api::BcFitMode;
use crate::cli_api::{
    calculate_zero_angle_with_conditions, calculate_zero_angle_with_resolved_conditions,
    AtmosphericConditions, BallisticInputs as InternalBallisticInputs, BcReferenceStandard,
    TrajectorySolver, WindConditions,
};
#[cfg(feature = "wasm-zero")]
use crate::cli_api::{
    calculate_zero_range_from_angle_with_conditions,
    calculate_zero_range_from_angle_with_resolved_conditions,
};
#[cfg(feature = "wasm-monte-carlo")]
use crate::cli_api::{MonteCarloParams, BC_REFERENCE_STANDARD_INERT_WARNING};
use crate::constants::GRAINS_PER_GRAM;
use crate::drag_model::DragModel;
#[cfg(feature = "wasm-lead")]
use crate::moving_target::calculate_lead;
use crate::moving_target::mover_ring;
#[cfg(feature = "wasm-power-factor")]
use crate::power_factor::{evaluate_all as pf_evaluate_all, scored_power_factor};
#[cfg(feature = "wasm-recoil")]
use crate::recoil::{free_recoil, FirearmType, FreeRecoilInputs, GasVelocityModel, POUNDS_TO_KG};
use crate::truing_dsf::{apply_dsf, DsfPoint, DsfTable};
use std::cell::RefCell;

/// Parse `--bc-reference`'s value (MBA-1365). Mirrors the native CLI's `clap::ValueEnum`
/// spelling ("icao", "army-standard-metro"), case-insensitively, since the WASM terminal
/// hand-parses its own argv rather than using clap.
fn parse_bc_reference_arg(s: &str) -> Result<BcReferenceStandard, JsValue> {
    match s.to_ascii_lowercase().as_str() {
        "icao" => Ok(BcReferenceStandard::Icao),
        "army-standard-metro" => Ok(BcReferenceStandard::ArmyStandardMetro),
        other => Err(JsValue::from_str(&format!(
            "Invalid --bc-reference '{other}' (expected 'icao' or 'army-standard-metro')"
        ))),
    }
}

/// Parse `--pressure-type`/`--zero-pressure-type`'s value (MBA-1397). Mirrors the native
/// CLI's `clap::ValueEnum` spelling ("absolute", "qnh"), case-insensitively.
fn parse_pressure_type_arg(s: &str) -> Result<PressureReferenceMode, JsValue> {
    match s.to_ascii_lowercase().as_str() {
        "absolute" => Ok(PressureReferenceMode::Absolute),
        "qnh" => Ok(PressureReferenceMode::Qnh),
        other => Err(JsValue::from_str(&format!(
            "Invalid --pressure-type '{other}' (expected 'absolute' or 'qnh')"
        ))),
    }
}

#[wasm_bindgen]
pub struct WasmBallistics {
    /// Optional BC5D correction table loaded from an in-memory `.bin`. When
    /// present, trajectory runs with `--use-bc-segments` synthesize
    /// velocity-dependent BC segments from it (offline parity with the online
    /// solver's ClusterBCDegradation + BC-segment + weather corrections).
    bc5d_table: RefCell<Option<Bc5dTable>>,
    /// Optional custom Mach:Cd drag table loaded from an in-memory CSV (MBA-1328;
    /// mirrors `bc5d_table` above). When present, every `trajectory`, `zero`, `lead`,
    /// and `monte-carlo` run applies it automatically as a full physical substitute
    /// for the BC + G-model drag (see `calculate_drag_coefficient`) — no `--use-*`
    /// gate flag needed, unlike BC5D's `--use-bc-segments`.
    drag_table: RefCell<Option<crate::drag::DragTable>>,
}

// Unit system for conversions
#[derive(Debug, Clone, Copy, PartialEq)]
enum UnitSystem {
    Imperial,
    Metric,
}

impl UnitSystem {
    fn from_str(s: &str) -> Self {
        match s.to_lowercase().as_str() {
            "metric" => UnitSystem::Metric,
            _ => UnitSystem::Imperial,
        }
    }
}

// Output format
#[derive(Debug, Clone, Copy, PartialEq)]
enum OutputFormat {
    Table,
    Json,
    Csv,
}

impl OutputFormat {
    fn from_str(s: &str) -> Self {
        match s.to_lowercase().as_str() {
            "json" => OutputFormat::Json,
            "csv" => OutputFormat::Csv,
            _ => OutputFormat::Table,
        }
    }
}

/// SMOA (a.k.a. IPHY) per MIL — the crate's locked MBA-724 dial-constant ratio
/// (`adjustment::adjustment_factor(Smoa) / adjustment_factor(Mil)` == 3.6 exact).
/// Mirrors native `main.rs`'s `smoa_per_mil()` helper so the WASM terminal's SMOA/IPHY
/// figures agree with the native CLI bit-for-bit (MBA-1355).
fn smoa_per_mil() -> f64 {
    crate::adjustment::adjustment_factor(crate::adjustment::ClickBase::Smoa)
        / crate::adjustment::adjustment_factor(crate::adjustment::ClickBase::Mil)
}

/// How the mover Ring table column (trajectory's `--target-speed`) turns its raw mil
/// angle into a display value for the active `--adjustment-unit` (MBA-1355), mirroring
/// native `main.rs`'s `RingUnit`: every unit except Clicks is a constant multiply on the
/// mil angle; Clicks instead rounds to a whole click count via a resolved `ClickValue`
/// (the elevation graduation — Ring isn't cleanly an elevation or windage axis, so it
/// reuses elevation, same choice the native CLI's PDF dope card Drop column makes).
#[derive(Debug, Clone, Copy)]
enum RingDisplayUnit {
    Factor(f64, &'static str),
    Clicks(crate::adjustment::ClickValue),
}

/// Parse a `--powder-temp-curve` "TEMP:VEL,..." value into sorted SI
/// `(temperature_c, velocity_m_s)` points — ONE parser shared by the trajectory and
/// lead command handlers so their validation cannot drift (review fix M2: the two
/// inline copies had already drifted from native `parse_powder_temp_curve` by
/// accepting duplicate temperatures, which make the interpolation order-dependent).
/// Validation mirrors the native parser: TEMP:VELOCITY shape, positive velocity,
/// at least 2 points, and no duplicate temperatures after sorting.
fn parse_powder_temp_curve_str(
    curve_str: &str,
    units: UnitSystem,
) -> Result<Vec<(f64, f64)>, JsValue> {
    let mut pts: Vec<(f64, f64)> = Vec::new();
    for raw in curve_str.split(',') {
        let part = raw.trim();
        if part.is_empty() {
            continue;
        }
        let (t_str, v_str) = part
            .split_once(':')
            .ok_or_else(|| JsValue::from_str("--powder-temp-curve point must be TEMP:VELOCITY"))?;
        let t: f64 = t_str
            .trim()
            .parse()
            .map_err(|_| JsValue::from_str("Invalid temperature in --powder-temp-curve"))?;
        let v: f64 = v_str
            .trim()
            .parse()
            .map_err(|_| JsValue::from_str("Invalid velocity in --powder-temp-curve"))?;
        if !(v > 0.0) {
            return Err(JsValue::from_str(
                "--powder-temp-curve velocity must be positive",
            ));
        }
        let (t_c, v_ms) = match units {
            UnitSystem::Imperial => ((t - 32.0) * 5.0 / 9.0, v * 0.3048),
            UnitSystem::Metric => (t, v),
        };
        pts.push((t_c, v_ms));
    }
    if pts.len() < 2 {
        return Err(JsValue::from_str(
            "--powder-temp-curve needs at least 2 TEMP:VELOCITY points",
        ));
    }
    pts.sort_by(|a, b| a.0.partial_cmp(&b.0).unwrap_or(std::cmp::Ordering::Equal));
    for w in pts.windows(2) {
        if (w[0].0 - w[1].0).abs() < f64::EPSILON {
            return Err(JsValue::from_str(
                "--powder-temp-curve has duplicate temperatures",
            ));
        }
    }
    Ok(pts)
}

/// Self-describing units/axes metadata for [`format_trajectory_json`]'s `-o json` output
/// (MBA-1315), additive: appended as a third top-level key alongside the pre-existing
/// `trajectory`/`summary` keys, which are unchanged. The WASM `-o json` fields already carry
/// their unit in the key name (`range_yards`, `drop_inches`, `drift_inches`, ...), so this
/// block's `units` restates those labels generically (matching the native CLI legacy JSON's
/// `legend.units`, MBA-1315) and its `axes` states the sign convention those field names don't
/// spell out on their own.
///
/// Sign conventions verified against `crate::wind::wind_vector`'s documented McCoy frame
/// (x downrange, y up, z right) and the native CLI's crosswind recon (MBA-1315): `drop` is
/// LOS-relative (`los_height - position.y`), positive when the bullet is below the line of
/// sight; `drift` is `position.z` directly, positive to the shooter's right, identical in
/// sign and source to the native CLI legacy JSON's `x`.
fn trajectory_json_legend(units: UnitSystem, target_drops: bool) -> serde_json::Value {
    let (distance, drop, drift, velocity, energy) = match units {
        UnitSystem::Imperial => ("yd", "in", "in", "fps", "ft-lb"),
        UnitSystem::Metric => ("m", "cm", "cm", "m/s", "J"),
    };
    // MBA-1403: with --drops-reference target the drop values are target-plane
    // referenced, so the legend must say so; the default (LOS) text stays
    // byte-identical to the historical legend.
    let drop_axis = if target_drops {
        "vertical miss in the target plane (--drops-reference target): the \
         LOS-perpendicular drop scaled by 1/cos(shooting angle); positive means the \
         bullet is below the aim point."
    } else {
        "vertical miss from the line of sight; positive means the bullet is below \
                     the line of sight (has fallen below the aim point). Not the same reference \
                     as the native CLI legacy JSON's world-frame `y`."
    };
    serde_json::json!({
        "units": {
            "range": distance,
            "drop": drop,
            "drift": drift,
            "velocity": velocity,
            "energy": energy
        },
        "axes": {
            "range": "downrange distance from the muzzle; zero at the muzzle, always increasing.",
            "drop": drop_axis,
            "drift": "lateral miss from the line of sight; positive means to the shooter's \
                      right (e.g. a crosswind FROM the left, --wind-direction 270, drifts it \
                      positive; FROM the right, --wind-direction 90, drifts it negative). Same \
                      sign and source as the native CLI legacy JSON's `x`."
        }
    })
}

/// Map the WASM terminal's session unit system onto the engine-side
/// [`crate::cli_api::UnitSystem`] shared by the truing and WEZ cores (MBA-1343).
#[cfg(any(feature = "wasm-truing", feature = "wasm-monte-carlo"))]
fn engine_units(units: UnitSystem) -> crate::cli_api::UnitSystem {
    match units {
        UnitSystem::Imperial => crate::cli_api::UnitSystem::Imperial,
        UnitSystem::Metric => crate::cli_api::UnitSystem::Metric,
    }
}

/// Fetch the value token for the value-taking flag at `args[i]`, or error when the
/// command line ends right after the flag. Mirrors native clap's "a value is
/// required" failure; the hand-rolled parsers previously skipped such a dangling
/// flag silently, which corrupted fits (a dangling `--observed` silently fell
/// back to single-observation truing — MBA-1343 review).
fn require_value<'a>(args: &[&'a str], i: usize) -> Result<&'a str, JsValue> {
    if i + 1 < args.len() {
        Ok(args[i + 1])
    } else {
        Err(JsValue::from_str(&format!(
            "Error: a value is required for '{}'",
            args[i]
        )))
    }
}

/// Parse a numeric argument value, naming the flag it came from (MBA-1361).
///
/// The house convention elsewhere in this file is a per-flag `.parse().map_err(...)` with a
/// hand-written message; this is the same thing factored out, for handlers with enough
/// numeric flags that repeating it would be the larger risk.
#[cfg(any(feature = "wasm-bc-convert", feature = "wasm-reticle"))]
fn parse_f64_arg(value: &str, flag: &str) -> Result<f64, JsValue> {
    value
        .trim()
        .parse::<f64>()
        .map_err(|_| JsValue::from_str(&format!("Invalid value '{value}' for {flag}")))
}

/// MBA-1356: pairing-requirement text for `--cd-scale` without a loaded drag table, shared by
/// every WASM terminal command that accepts it (trajectory/zero/monte-carlo). Mirrors the
/// native CLI's `resolve_cd_scale` text — except the WASM terminal has no `--bc-adjustment`
/// flag on ANY surface (unlike native, where `trajectory` has one), so unlike native's
/// text this never suggests it (0.28.1 sweep: surface-accurate suggestions only).
const CD_SCALE_REQUIRES_DRAG_TABLE: &str = "--cd-scale requires --drag-table";

/// MBA-1356: nudge for a `--cd-scale` far outside the documented typical truing range
/// (0.90-1.10), mirroring the native CLI's `cd_scale_range_warning` (src/main.rs) text exactly.
/// `None` inside `[0.5, 2.0]` — the engine's own gate (`require_positive` in
/// `validate_for_solve`) already covers finite && > 0. The trailing `\n\n` matches the shape of
/// the BC5D coercion warning (MBA-1386, bcdd213) since both are prepended, table-only, ahead of
/// the run's normal output.
fn cd_scale_range_warning(value: f64) -> Option<String> {
    if (0.5..=2.0).contains(&value) {
        None
    } else {
        Some(format!(
            "warning: --cd-scale {value} is far outside the typical truing range (0.90-1.10)\n\n"
        ))
    }
}

/// `"{n} points, Mach {lo:.2}-{hi:.2}"` summary of a DSF table's points — mirrors native
/// `main.rs`'s `dsf_table_summary` exactly (byte-identical wording), so the WASM
/// terminal's "DSF table active (...)" note reads the same as the native CLI's
/// (MBA-1411). Kept as a local copy since the native version is private to the binary
/// crate. `points` empty reports Mach 0.00-0.00 rather than panicking.
fn dsf_table_summary(points: &[DsfPoint]) -> String {
    let lo = points.first().map(|p| p.mach).unwrap_or(0.0);
    let hi = points.last().map(|p| p.mach).unwrap_or(0.0);
    format!("{} points, Mach {:.2}-{:.2}", points.len(), lo, hi)
}

/// Parse every `--dsf-point MACH:DSF` occurrence into a validated [`DsfTable`] (MBA-1411:
/// WASM has no saved-profile storage, so the DSF table is a per-call argument, mirroring
/// the MBA-1343 per-call pattern used by `true-velocity`'s multi-`--observed` and
/// `monte-carlo --wez`). `None` when no `--dsf-point` flags were given — the caller then
/// skips `apply_dsf` entirely, an exact no-op. Bounds/cap validation (0 < mach < 1.2,
/// 0.5 < dsf < 2.0, <= 6 points) is NOT reimplemented here — `DsfTable::from_points`'s
/// error strings ARE the user-facing errors, identical to the native `dsf`/saved-profile
/// paths.
fn parse_dsf_points(raw: &[String]) -> Result<Option<DsfTable>, JsValue> {
    if raw.is_empty() {
        return Ok(None);
    }
    let mut points = Vec::with_capacity(raw.len());
    for s in raw {
        let parts: Vec<&str> = s.split(':').collect();
        if parts.len() != 2 {
            return Err(JsValue::from_str(&format!(
                "--dsf-point expects MACH:DSF (e.g. 0.95:1.08), got '{}'",
                s
            )));
        }
        let mach: f64 = parts[0]
            .trim()
            .parse()
            .map_err(|_| JsValue::from_str(&format!("--dsf-point: invalid MACH in '{}'", s)))?;
        let dsf: f64 = parts[1]
            .trim()
            .parse()
            .map_err(|_| JsValue::from_str(&format!("--dsf-point: invalid DSF in '{}'", s)))?;
        points.push(DsfPoint { mach, dsf });
    }
    DsfTable::from_points(points)
        .map(Some)
        .map_err(|e| JsValue::from_str(&e))
}

/// Local mirror of the native CLI's `MonteCarloOutput` modes for the WEZ path
/// (MBA-1343 Phase C). The WASM `-o` spellings map onto these in
/// `run_monte_carlo_wez`.
#[cfg(feature = "wasm-monte-carlo")]
enum WezOutputMode {
    Summary,
    Statistics,
    Full,
}

/// Dominant-bucket label shared by the WEZ summary-table and statistics-CSV
/// renderers — replicates the native CLI's `wez_dominant_label` (main.rs) exactly.
#[cfg(feature = "wasm-monte-carlo")]
fn wez_dominant_label(row: &crate::wez::WezRow) -> String {
    if row.attribution_unavailable {
        "n/a".to_string()
    } else {
        row.dominant_error_source
            .map(|b| b.to_string())
            .unwrap_or_else(|| "none".to_string())
    }
}

/// Meters -> user distance units (native `UnitConverter::distance_from_metric`).
#[cfg(any(feature = "wasm-monte-carlo", feature = "wasm-truing"))]
fn distance_from_metric(val: f64, units: UnitSystem) -> f64 {
    match units {
        UnitSystem::Metric => val,
        UnitSystem::Imperial => val / 0.9144, // meters to yards
    }
}

/// m/s -> user wind units (native `UnitConverter::wind_from_metric`).
#[cfg(feature = "wasm-monte-carlo")]
fn wind_from_metric(val: f64, units: UnitSystem) -> f64 {
    match units {
        UnitSystem::Metric => val,
        UnitSystem::Imperial => val / 0.44704, // m/s to mph
    }
}

/// `-o full`: the entire [`crate::wez::WezResult`] as pretty JSON — replicates the
/// native `print_wez_full` (the 0.25.0 JSON contract) byte-for-byte, including the
/// trailing newline native's `println!` emits.
#[cfg(feature = "wasm-monte-carlo")]
fn format_wez_full(result: &crate::wez::WezResult) -> Result<String, JsValue> {
    let json = serde_json::to_string_pretty(result)
        .map_err(|e| JsValue::from_str(&format!("Error serializing JSON: {e}")))?;
    Ok(format!("{json}\n"))
}

/// `-o statistics`: one CSV row per range step — replicates the native
/// `print_wez_statistics` byte-for-byte.
#[cfg(feature = "wasm-monte-carlo")]
fn format_wez_statistics(result: &crate::wez::WezResult, units: UnitSystem) -> String {
    let mut out = String::new();
    out.push_str("range,p_hit,dominant_error_source,wind_call_share,mv_sd_share,other_share\n");
    for row in &result.rows {
        out.push_str(&format!(
            "{:.2},{:.4},{},{:.4},{:.4},{:.4}\n",
            distance_from_metric(row.range_m, units),
            row.p_hit,
            wez_dominant_label(row),
            row.wind_call_share,
            row.mv_sd_share,
            row.other_share
        ));
    }
    out
}

/// Default `-o summary`: the human-readable sweep table — replicates the native
/// `print_wez_summary` byte-for-byte.
#[cfg(feature = "wasm-monte-carlo")]
fn format_wez_summary(result: &crate::wez::WezResult, units: UnitSystem) -> String {
    let dist_unit = match units {
        UnitSystem::Imperial => "yd",
        UnitSystem::Metric => "m",
    };
    let wind_unit = match units {
        UnitSystem::Imperial => "mph",
        UnitSystem::Metric => "m/s",
    };
    let mut out = String::new();
    out.push_str(&format!(
        "WEZ sweep: {} sims/step, wind call {:.2} {wind_unit} + wind std {:.2} {wind_unit} (quadrature) = {:.2} {wind_unit} effective\n",
        result.num_sims_per_step,
        wind_from_metric(result.wind_call_error_mps, units),
        wind_from_metric(result.wind_speed_std_mps, units),
        wind_from_metric(result.combined_wind_speed_std_mps, units),
    ));
    out.push_str("┌────────────┬──────────┬───────────────┬───────────┬───────────┬───────────┐\n");
    out.push_str(&format!(
        "│ Range ({dist_unit:>3}) │  P(hit)  │ Dominant      │ Wind call │  MV SD    │ Other/grp │\n"
    ));
    out.push_str("├────────────┼──────────┼───────────────┼───────────┼───────────┼───────────┤\n");
    for row in &result.rows {
        out.push_str(&format!(
            "│ {:>10.1} │ {:>7.1}% │ {:<13} │ {:>8.1}% │ {:>8.1}% │ {:>8.1}% │\n",
            distance_from_metric(row.range_m, units),
            row.p_hit * 100.0,
            wez_dominant_label(row),
            row.wind_call_share * 100.0,
            row.mv_sd_share * 100.0,
            row.other_share * 100.0,
        ));
    }
    out.push_str("└────────────┴──────────┴───────────────┴───────────┴───────────┴───────────┘\n");
    out
}

/// Render a multi-observation truing report as table / JSON / CSV — replicates the
/// native CLI's `display_multi_truing_result` (main.rs) byte-for-byte so terminal
/// parity can be tested against the native binary (MBA-1343 Phase C).
#[cfg(feature = "wasm-truing")]
fn format_multi_truing_result(
    report: &crate::truing::MultiTruingReport,
    drop_unit: crate::truing::DropUnit,
    units: UnitSystem,
    chrono_fps: Option<f64>,
    output: OutputFormat,
) -> String {
    let vel_unit = match units {
        UnitSystem::Imperial => "fps",
        UnitSystem::Metric => "m/s",
    };
    let range_unit = match units {
        UnitSystem::Imperial => "yd",
        UnitSystem::Metric => "m",
    };
    let drop_label = drop_unit.label();
    let mv_display = match units {
        UnitSystem::Imperial => report.fitted_mv_fps,
        UnitSystem::Metric => report.fitted_mv_fps * 0.3048,
    };
    let range_display = |range_yd: f64| match units {
        UnitSystem::Imperial => range_yd,
        UnitSystem::Metric => range_yd * 0.9144,
    };
    // Chrono comparison (chrono_fps is already in fps).
    let (adj_display, adj_pct) = match chrono_fps {
        Some(c) => {
            let adj_fps = report.fitted_mv_fps - c;
            let adj_disp = match units {
                UnitSystem::Imperial => adj_fps,
                UnitSystem::Metric => adj_fps * 0.3048,
            };
            let pct = if c != 0.0 { adj_fps / c * 100.0 } else { 0.0 };
            (Some(adj_disp), Some(pct))
        }
        None => (None, None),
    };

    // MBA-1405 Task 2: MV-calibration window (90-100% of the downward Mach 1.2
    // crossing) — same additive JSON fields and table lines as the native CLI's
    // `display_multi_truing_result`. The native out-of-window WARNING is a stderr
    // diagnostic with no WASM equivalent (this terminal has no stderr channel and
    // never reproduces native's stderr text — see the "Fitting N observations..."
    // progress line, also absent here), so it is deliberately not mirrored.
    let mv_window = crate::truing::mv_calibration_window(report.mach_1_2_distance_m);

    let mut out = String::new();
    match output {
        OutputFormat::Json => {
            let obs_json: Vec<serde_json::Value> = report
                .observations
                .iter()
                .enumerate()
                .map(|(i, o)| {
                    serde_json::json!({
                        format!("range_{range_unit}"): range_display(o.range_yd),
                        format!("observed_drop_{drop_label}"): o.drop,
                        format!("predicted_drop_{drop_label}"): report.predicted[i],
                        format!("residual_{drop_label}"): report.residuals[i],
                    })
                })
                .collect();

            let mut json_output = serde_json::json!({
                "mode": if report.bc_fitted { "joint_mv_bc" } else { "mv_only" },
                "fitted_muzzle_velocity": mv_display,
                "velocity_unit": vel_unit,
                "bc_fitted": report.bc_fitted,
                "fitted_bc": report.fitted_bc,
                "input_bc": report.bc_input,
                "observations": obs_json,
                format!("rms_residual_{drop_label}"): report.rms,
                "iterations": report.iterations,
                "converged": report.converged,
                "bc_sensitivity_ratio": report.sensitivity_ratio,
                "condition_number": if report.condition_number.is_finite() {
                    serde_json::json!(report.condition_number)
                } else {
                    serde_json::Value::Null
                },
                "quality": report.quality,
                "legend": {
                    "units": {
                        "range": range_unit,
                        "drop": drop_label,
                        "velocity": vel_unit,
                    },
                },
            });
            if !report.reason.is_empty() {
                json_output["bc_hold_reason"] = serde_json::json!(report.reason);
            }
            if let Some(adj) = adj_display {
                json_output["velocity_adjustment"] = serde_json::json!(adj);
            }
            if let Some(pct) = adj_pct {
                json_output["adjustment_percent"] = serde_json::json!(pct);
            }
            // MBA-1405 Task 2: additive-only fields (meters, unit-invariant); null when
            // the trajectory never crosses Mach 1.2 — no note text ever accompanies
            // these in JSON (purity rule), matching the native CLI's JSON exactly.
            json_output["mv_window_start_m"] = match mv_window {
                Some((lo_m, _)) => serde_json::json!(lo_m),
                None => serde_json::Value::Null,
            };
            json_output["mv_window_end_m"] = match mv_window {
                Some((_, hi_m)) => serde_json::json!(hi_m),
                None => serde_json::Value::Null,
            };
            // Native prints a serialization error to stderr and leaves stdout empty;
            // the returned string mirrors stdout exactly either way.
            if let Ok(s) = serde_json::to_string_pretty(&json_output) {
                out.push_str(&s);
                out.push('\n');
            }
        }
        OutputFormat::Csv => {
            out.push_str(&format!(
                "range_{range_unit},observed_drop_{drop_label},predicted_drop_{drop_label},residual_{drop_label}\n"
            ));
            for (i, o) in report.observations.iter().enumerate() {
                out.push_str(&format!(
                    "{:.1},{:.4},{:.4},{:+.4}\n",
                    range_display(o.range_yd),
                    o.drop,
                    report.predicted[i],
                    report.residuals[i]
                ));
            }
            out.push('\n');
            out.push_str(&format!(
                "fitted_muzzle_velocity_{vel_unit},bc_fitted,fitted_bc,input_bc,rms_residual_{drop_label},iterations,converged,bc_sensitivity_ratio,condition_number\n"
            ));
            out.push_str(&format!(
                "{:.1},{},{:.4},{:.4},{:.4},{},{},{:.4},{}\n",
                mv_display,
                report.bc_fitted,
                report.fitted_bc,
                report.bc_input,
                report.rms,
                report.iterations,
                report.converged,
                report.sensitivity_ratio,
                if report.condition_number.is_finite() {
                    format!("{:.1}", report.condition_number)
                } else {
                    "inf".to_string()
                },
            ));
        }
        OutputFormat::Table => {
            out.push('\n');
            out.push_str("=== VELOCITY + BC TRUING (multi-observation) ===\n");
            out.push('\n');
            out.push_str(&format!(
                "  Fitted muzzle velocity: {:>9.1} {}\n",
                mv_display, vel_unit
            ));
            if report.bc_fitted {
                out.push_str(&format!(
                    "  Fitted BC:              {:>9.4}  (input {:.4})\n",
                    report.fitted_bc, report.bc_input
                ));
            } else {
                out.push_str(&format!(
                    "  BC:                     {:>9.4}  (held; not fitted)\n",
                    report.fitted_bc
                ));
            }
            if let Some(adj) = adj_display {
                out.push_str(&format!(
                    "  Adjustment from chrono: {:>+9.1} {}\n",
                    adj, vel_unit
                ));
                if let Some(pct) = adj_pct {
                    out.push_str(&format!("  Adjustment percentage:  {:>+9.2}%\n", pct));
                }
            }
            out.push('\n');
            out.push_str(&format!(
                "  {:>10}  {:>14}  {:>14}  {:>12}\n",
                format!("Range ({range_unit})"),
                format!("Observed ({drop_label})"),
                format!("Predicted ({drop_label})"),
                format!("Resid ({drop_label})"),
            ));
            out.push_str(&format!("  {}\n", "-".repeat(56)));
            for (i, o) in report.observations.iter().enumerate() {
                out.push_str(&format!(
                    "  {:>10.1}  {:>14.3}  {:>14.3}  {:>+12.3}\n",
                    range_display(o.range_yd),
                    o.drop,
                    report.predicted[i],
                    report.residuals[i]
                ));
            }
            out.push_str(&format!("  {}\n", "-".repeat(56)));
            out.push_str(&format!(
                "  RMS residual: {:.3} {}   |   iterations: {}{}\n",
                report.rms,
                drop_label,
                report.iterations,
                if report.converged {
                    ""
                } else {
                    " (not fully converged)"
                }
            ));
            out.push('\n');
            out.push_str(&format!("  {}\n", report.quality));
            if !report.reason.is_empty() {
                out.push_str(&format!("  Note: {}\n", report.reason));
            }
            out.push_str(&format!(
                "  Diagnostics: BC sensitivity ratio {:.4}, conditioning {}\n",
                report.sensitivity_ratio,
                if report.condition_number.is_finite() {
                    format!("{:.0}", report.condition_number)
                } else {
                    "inf".to_string()
                }
            ));
            // MBA-1405 Task 2: MV-calibration window / no-window note, table only —
            // mirrors the native CLI's `display_multi_truing_result` exactly.
            match mv_window {
                Some((lo_m, hi_m)) => {
                    let lo = distance_from_metric(lo_m, units);
                    let hi = distance_from_metric(hi_m, units);
                    out.push_str(&format!(
                        "  MV-calibration window: {lo:.1}-{hi:.1} {range_unit} (90-100% of the Mach 1.2 distance)\n"
                    ));
                }
                None if report.muzzle_mach >= 1.2 => {
                    let max_display = distance_from_metric(report.window_solved_range_m, units);
                    out.push_str(&format!(
                        "  note: no MV window: trajectory is supersonic through {max_display:.1} \
                         {range_unit}; MV is identifiable at any range\n"
                    ));
                }
                None => {
                    out.push_str(
                        "  note: no MV window: trajectory never reaches Mach 1.2; calibrate \
                         muzzle velocity with a chronograph, then collect DSF points\n",
                    );
                }
            }
            out.push_str("  for optimal observation ranges run: ballistics plan-truing\n");
            out.push('\n');
        }
    }
    out
}

/// Render a single-observation truing result as table / JSON / CSV — replicates the
/// native CLI's `display_true_velocity_result` (main.rs) byte-for-byte.
#[cfg(feature = "wasm-truing")]
#[allow(
    clippy::too_many_arguments,
    reason = "flat arguments mirror the native display_true_velocity_result signature"
)]
fn format_true_velocity_result(
    effective_vel: f64,
    vel_unit: &str,
    velocity_adjustment: Option<f64>,
    adjustment_percent: Option<f64>,
    confidence: &str,
    iterations: i32,
    final_error_mil: f64,
    calculated_drop_mil: f64,
    measured_drop: f64,
    units: UnitSystem,
    output: OutputFormat,
    used_bc_table: bool,
) -> Result<String, JsValue> {
    let mut out = String::new();
    match output {
        OutputFormat::Json => {
            let mut json_output = serde_json::json!({
                "effective_velocity": effective_vel,
                "velocity_unit": vel_unit,
                "confidence": confidence,
                "iterations": iterations,
                "final_error_mil": final_error_mil,
                "calculated_drop_mil": calculated_drop_mil,
                "measured_drop_mil": measured_drop,
                "used_bc_table": used_bc_table,
            });
            if let Some(adj) = velocity_adjustment {
                let adj_display = match units {
                    UnitSystem::Imperial => adj,
                    UnitSystem::Metric => adj * 0.3048,
                };
                json_output["velocity_adjustment"] = serde_json::json!(adj_display);
            }
            if let Some(pct) = adjustment_percent {
                json_output["adjustment_percent"] = serde_json::json!(pct);
            }
            let s = serde_json::to_string_pretty(&json_output)
                .map_err(|e| JsValue::from_str(&format!("Error serializing JSON: {e}")))?;
            out.push_str(&s);
            out.push('\n');
        }
        OutputFormat::Csv => {
            out.push_str("effective_velocity,unit,adjustment,adjustment_pct,confidence,iterations,final_error_mil,calculated_drop_mil,used_bc_table\n");
            out.push_str(&format!(
                "{:.1},{},{},{},{},{},{:.4},{:.2},{}\n",
                effective_vel,
                vel_unit,
                velocity_adjustment
                    .map(|v| {
                        let adj = match units {
                            UnitSystem::Imperial => v,
                            UnitSystem::Metric => v * 0.3048,
                        };
                        format!("{:.1}", adj)
                    })
                    .unwrap_or_default(),
                adjustment_percent
                    .map(|v| format!("{:.2}", v))
                    .unwrap_or_default(),
                confidence,
                iterations,
                final_error_mil,
                calculated_drop_mil,
                used_bc_table,
            ));
        }
        OutputFormat::Table => {
            out.push('\n');
            out.push_str("╔════════════════════════════════════════════════════════════╗\n");
            out.push_str("║           VELOCITY TRUING RESULTS                          ║\n");
            out.push_str("╠════════════════════════════════════════════════════════════╣\n");
            out.push_str(&format!(
                "║  Effective Muzzle Velocity: {:>8.1} {:>4}                 ║\n",
                effective_vel, vel_unit
            ));
            if let Some(adj) = velocity_adjustment {
                let adj_display = match units {
                    UnitSystem::Imperial => adj,
                    UnitSystem::Metric => adj * 0.3048,
                };
                out.push_str(&format!(
                    "║  Adjustment from Chrono:    {:>+8.1} {:>4}                 ║\n",
                    adj_display, vel_unit
                ));
                if let Some(pct) = adjustment_percent {
                    out.push_str(&format!(
                        "║  Adjustment Percentage:     {:>+8.2}%                      ║\n",
                        pct
                    ));
                }
            }
            out.push_str("╠════════════════════════════════════════════════════════════╣\n");
            out.push_str(&format!(
                "║  Confidence:                {:>8}                        ║\n",
                confidence
            ));
            out.push_str(&format!(
                "║  Iterations:                {:>8}                        ║\n",
                iterations
            ));
            out.push_str(&format!(
                "║  Final Error:               {:>8.4} MIL                  ║\n",
                final_error_mil
            ));
            out.push_str(&format!(
                "║  Calculated Drop:           {:>8.2} MIL                  ║\n",
                calculated_drop_mil
            ));
            out.push_str(&format!(
                "║  Measured Drop:             {:>8.2} MIL                  ║\n",
                measured_drop
            ));
            if used_bc_table {
                out.push_str("╠════════════════════════════════════════════════════════════╣\n");
                out.push_str("║  BC5D Table:                     Yes                       ║\n");
            }
            out.push_str("╚════════════════════════════════════════════════════════════╝\n");
            out.push('\n');
        }
    }
    Ok(out)
}

#[wasm_bindgen]
impl WasmBallistics {
    #[wasm_bindgen(constructor)]
    pub fn new() -> Self {
        WasmBallistics {
            bc5d_table: RefCell::new(None),
            drag_table: RefCell::new(None),
        }
    }

    /// Load a BC5D correction table from the raw bytes of a `bc5d_<caliber>.bin`
    /// file. The host (browser `fetch()` or Node `fs`/`fetch`) is responsible
    /// for retrieving the file — WASM has no filesystem or network — and passes
    /// the bytes here.
    ///
    /// Once loaded, any `trajectory` run that includes `--use-bc-segments` will
    /// apply velocity-dependent BC segments synthesized from this table. Load a
    /// table matching the bullet's caliber (e.g. `bc5d_308.bin` for a .308).
    ///
    /// Returns a short human-readable summary of the loaded table. Replaces any
    /// previously loaded table.
    #[wasm_bindgen(js_name = loadBc5dTable)]
    pub fn load_bc5d_table(&self, bytes: &[u8]) -> Result<String, JsValue> {
        let table = Bc5dTable::from_bytes(bytes)
            .map_err(|e| JsValue::from_str(&format!("Failed to parse BC5D table: {}", e)))?;
        let summary = format!(
            "Loaded BC5D table: caliber {:.3}\", {} cells, api_version {}",
            table.caliber(),
            table.total_cells(),
            table.api_version()
        );
        *self.bc5d_table.borrow_mut() = Some(table);
        Ok(summary)
    }

    /// Report whether a BC5D table is currently loaded.
    #[wasm_bindgen(js_name = hasBc5dTable)]
    pub fn has_bc5d_table(&self) -> bool {
        self.bc5d_table.borrow().is_some()
    }

    /// Load a custom Mach:Cd drag table (MBA-1328) — a measured or manufacturer-published
    /// drag curve (Hornady CDM data, a Lapua/Doppler-radar-derived deck, or your own) — from
    /// the raw bytes of a CSV file. The host (browser `fetch()` or Node `fs`/`fetch`) is
    /// responsible for retrieving the file — WASM has no filesystem or network — and passes
    /// the bytes here, mirroring [`Self::load_bc5d_table`].
    ///
    /// The bytes must be valid UTF-8 CSV text; parsing is delegated to
    /// [`crate::drag::DragTable::from_csv_str`] — the SAME parser native `--drag-table`
    /// uses — so the accepted format is identical: two columns `mach,cd` per line, blank
    /// lines and `#` comments ignored, a single leading textual header row tolerated, Mach
    /// strictly ascending with at least 2 points, Cd finite and > 0.
    ///
    /// Once loaded, EVERY subsequent `trajectory`, `zero`, `lead`, and `monte-carlo` run
    /// applies the table automatically — no `--use-*` gate flag is needed (unlike a loaded
    /// BC5D table, which only takes effect with `--use-bc-segments`). A loaded table is a
    /// full physical substitute for the G-model + BC (see `calculate_drag_coefficient`):
    /// `-b`/`--bc` may still be supplied but is ignored for drag once a table is active
    /// (matching the native `--drag-table` CLI semantics documented in CLI_USAGE.md).
    ///
    /// Returns a short human-readable summary of the loaded table (point count + Mach
    /// range). Replaces any previously loaded table.
    ///
    /// MBA-1409: also accepts `.drg` vendor drag-curve text (the same format the native
    /// `--drag-table` CLI accepts by `.drg` file extension) as a fallback. WASM has no
    /// filesystem and thus no extension to dispatch on, so the bytes are tried as CSV first
    /// (exactly as before this change); only on CSV failure, if the text
    /// [`crate::drag_file::looks_like_drg`], it is retried through
    /// [`crate::drag_file::parse_drg`]. If both fail, the returned error names both formats.
    #[wasm_bindgen(js_name = loadDragTable)]
    pub fn load_drag_table(&self, bytes: &[u8]) -> Result<String, JsValue> {
        let text = std::str::from_utf8(bytes).map_err(|e| {
            JsValue::from_str(&format!("Drag table bytes are not valid UTF-8: {}", e))
        })?;
        let table = match crate::drag::DragTable::from_csv_str(text) {
            Ok(t) => t,
            Err(csv_err) => {
                if !crate::drag_file::looks_like_drg(text) {
                    return Err(JsValue::from_str(&format!(
                        "Failed to parse drag table as CSV ({csv_err}); text does not look like \
                         a .drg file either"
                    )));
                }
                match crate::drag_file::parse_drg(text) {
                    Ok(curve) => {
                        let (mach, cd): (Vec<f64>, Vec<f64>) = curve.points.into_iter().unzip();
                        crate::drag::DragTable::try_new(mach, cd).map_err(|e| {
                            JsValue::from_str(&format!("Failed to parse drag table: {}", e))
                        })?
                    }
                    Err(drg_err) => {
                        return Err(JsValue::from_str(&format!(
                            "Failed to parse drag table as CSV ({csv_err}) or as .drg ({drg_err})"
                        )));
                    }
                }
            }
        };
        let summary = format!(
            "Loaded drag table: {} points, Mach {:.3}-{:.3}",
            table.mach_values.len(),
            table.mach_values.first().copied().unwrap_or(0.0),
            table.mach_values.last().copied().unwrap_or(0.0),
        );
        *self.drag_table.borrow_mut() = Some(table);
        Ok(summary)
    }

    /// Report whether a custom drag table is currently loaded.
    #[wasm_bindgen(js_name = hasDragTable)]
    pub fn has_drag_table(&self) -> bool {
        self.drag_table.borrow().is_some()
    }

    /// Unload any custom drag table previously installed via [`Self::load_drag_table`],
    /// reverting every subsequent `trajectory`, `zero`, `lead`, and `monte-carlo` run to the
    /// standard G-model + BC drag (the `-b`/`--bc` value with the selected G1/G7 curve).
    ///
    /// The inverse of `loadDragTable`. It lets a single engine instance alternate between a
    /// measured-curve (CDM) solve and a plain G7-BC solve without constructing a second
    /// instance: `load → solve CDM → clear → solve G7`, with the G7 half uncontaminated —
    /// the same load/clear pattern `clearWindSegments` provides for segmented wind.
    ///
    /// Returns `true` if a table was loaded (and is now cleared), `false` if none was loaded
    /// (a harmless no-op). Idempotent.
    #[wasm_bindgen(js_name = clearDragTable)]
    pub fn clear_drag_table(&self) -> bool {
        self.drag_table.borrow_mut().take().is_some()
    }

    /// Run a command and return the output
    #[wasm_bindgen(js_name = runCommand)]
    pub fn run_command(&self, command: &str) -> Result<String, JsValue> {
        // Handle quoted arguments properly
        let mut args: Vec<String> = Vec::new();
        let mut current_arg = String::new();
        let mut in_quotes = false;
        let mut quote_char = ' ';

        for c in command.chars() {
            if !in_quotes && (c == '\'' || c == '"') {
                in_quotes = true;
                quote_char = c;
            } else if in_quotes && c == quote_char {
                in_quotes = false;
                quote_char = ' ';
            } else if !in_quotes && c.is_whitespace() {
                if !current_arg.is_empty() {
                    args.push(current_arg.clone());
                    current_arg.clear();
                }
            } else {
                current_arg.push(c);
            }
        }

        if !current_arg.is_empty() {
            args.push(current_arg);
        }

        let args: Vec<&str> = args.iter().map(|s| s.as_str()).collect();

        if args.is_empty() {
            return Ok(self.show_help());
        }

        // Skip "ballistics" if present
        let args = if !args.is_empty() && (args[0] == "ballistics" || args[0] == "./ballistics") {
            &args[1..]
        } else {
            &args[..]
        };

        if args.is_empty() || args[0] == "help" || args[0] == "--help" || args[0] == "-h" {
            return Ok(self.show_help());
        }

        // Parse global unit system first
        let mut units = UnitSystem::Imperial;
        for i in 0..args.len() {
            if args[i] == "--units" || args[i] == "-u" {
                if i + 1 < args.len() {
                    units = UnitSystem::from_str(args[i + 1]);
                }
                break;
            }
        }

        // MBA-1289: `--units <system>` may appear anywhere — including BEFORE the command
        // word, the order the help text advertises. Units were already parsed from the
        // full list above, so strip the flag and its value here; otherwise the dispatch
        // below would read `--units` as the command and fail with "Unknown command".
        let mut stripped: Vec<&str> = Vec::with_capacity(args.len());
        let mut i = 0;
        while i < args.len() {
            if args[i] == "--units" || args[i] == "-u" {
                i += 2; // skip the flag and its value (a dangling flag skips harmlessly)
            } else {
                stripped.push(args[i]);
                i += 1;
            }
        }
        let args = stripped;
        if args.is_empty() {
            return Ok(self.show_help());
        }

        // Route to appropriate command handler
        match args[0] {
            "version" => Ok(format!(
                "Ballistics Engine v{}\nWASM Build\n",
                env!("CARGO_PKG_VERSION")
            )),
            "trajectory" => self.handle_trajectory_command(&args[1..], units),
            #[cfg(feature = "wasm-zero")]
            "zero" => self.handle_zero_command(&args[1..], units),
            #[cfg(feature = "wasm-monte-carlo")]
            "monte-carlo" | "montecarlo" => self.handle_monte_carlo_command(&args[1..], units),
            #[cfg(feature = "wasm-truing")]
            "true-velocity" => self.handle_true_velocity_command(&args[1..], units),
            #[cfg(feature = "wasm-truing")]
            "true-wind" => self.handle_true_wind_command(&args[1..], units),
            #[cfg(feature = "wasm-bc-convert")]
            "bc-convert" => self.handle_bc_convert_command(&args[1..], units),
            #[cfg(feature = "wasm-estimate-bc")]
            "estimate-bc" => self.handle_estimate_bc_command(&args[1..], units),
            #[cfg(feature = "wasm-lead")]
            "lead" => self.handle_lead_command(&args[1..], units),
            #[cfg(feature = "wasm-powder")]
            "powder" => self.handle_powder_command(&args[1..], units),
            #[cfg(feature = "wasm-recoil")]
            "recoil" => self.handle_recoil_command(&args[1..], units),
            #[cfg(feature = "wasm-drag-curve")]
            "drag-curve" => Self::handle_drag_curve_command(&args[1..]),
            #[cfg(feature = "wasm-reticle")]
            "reticle" => Self::handle_reticle_command(&args[1..]),
            #[cfg(feature = "wasm-power-factor")]
            "power-factor" => self.handle_power_factor_command(&args[1..], units),
            _ => Ok(format!(
                "Error: Unknown command '{}'\n\n{}",
                args[0],
                self.show_help()
            )),
        }
    }

    fn handle_trajectory_command(
        &self,
        args: &[&str],
        units: UnitSystem,
    ) -> Result<String, JsValue> {
        // Default values based on unit system
        let (default_velocity, default_mass, default_diameter, default_temp, default_pressure) =
            match units {
                UnitSystem::Imperial => (2700.0, 168.0, 0.308, 59.0, 29.92),
                UnitSystem::Metric => (823.0, 10.9, 7.82, 15.0, 1013.25),
            };

        // Initialize all parameters with defaults
        let mut velocity = default_velocity;
        let mut angle = 0.0;
        let mut bc = 0.475;
        // MBA-1365: which standard atmosphere `bc` is referenced to. `Icao` is a no-op —
        // applied exactly once, in `TrajectorySolver::new`, byte-identical to today when
        // this flag is never passed.
        let mut bc_reference_standard = BcReferenceStandard::Icao;
        let mut mass = default_mass;
        let mut diameter = default_diameter;
        let mut drag_model = "G1";
        // MBA-1356: whole-curve drag scale for a custom drag table (see cd_scale_range_warning
        // / CD_SCALE_REQUIRES_DRAG_TABLE above). None until parsed; resolved against
        // self.drag_table once the arg-parse loop is done.
        let mut cd_scale: Option<f64> = None;
        let mut max_range = if units == UnitSystem::Imperial {
            1000.0
        } else {
            914.4
        };
        let mut time_step = 0.001;
        let mut wind_speed = 0.0;
        // f64 is required: `wind_direction.to_radians()` below needs a known receiver
        // type (method resolution can't infer it from the field assignment alone).
        let mut wind_direction: f64 = 0.0;
        // MBA-1367/1368: clock provenance + entry frame for every wind direction.
        let mut wind_direction_was_clock = false;
        let mut wind_ref = crate::wind::WindReference::Shooter;
        // Vertical wind (mph imperial / m/s metric); positive = updraft (raises POI).
        let mut wind_vertical: f64 = 0.0;
        // Raw "SPEED:ANGLE:UNTIL" strings; every --wind-segment occurrence is collected
        // (the parse loop visits all args, so repeats accumulate here).
        let mut wind_segment_strs: Vec<String> = Vec::new();
        // Raw "VMIN:VMAX:BC" strings from every --bc-segment occurrence (manual
        // velocity-keyed BC segments; take precedence over a loaded BC5D table).
        let mut bc_segment_strs: Vec<String> = Vec::new();
        // Raw "MACH:DSF" strings from every --dsf-point occurrence (MBA-1411: per-call
        // DSF table — WASM has no saved-profile storage to carry one).
        let mut dsf_point_strs: Vec<String> = Vec::new();
        let mut temperature = default_temp;
        let mut pressure = default_pressure;
        // MBA-1397: whether `pressure`/`zero_pressure` are absolute station pressure or a
        // sea-level-corrected altimeter setting (QNH) needing reduction before use.
        let mut pressure_type = PressureReferenceMode::Absolute;
        let mut zero_pressure_type: Option<PressureReferenceMode> = None;
        let mut humidity = 50.0;
        let mut altitude = 0.0;
        // MBA-1366: density altitude (feet imperial / meters metric), supersedes
        // altitude/pressure/pressure_type when given -- see the `--density-altitude` parse arm
        // below and the native CLI's `--density-altitude` doc comment for the full precedence.
        let mut density_altitude: Option<f64> = None;
        // Unlike native's clap `Option<f64>`, `pressure`/`pressure_type` above are plain values
        // with no way to tell "explicitly passed" from "left at default" -- track it explicitly
        // (same pattern as `adjustment_unit_supplied` below) so the density-altitude-supersedes
        // warning can fire only when the caller actually passed one of them.
        let mut pressure_supplied = false;
        let mut pressure_type_supplied = false;
        let mut temperature_supplied = false;
        let mut output_format = OutputFormat::Table;
        let mut full = false;
        // MBA-1433: select the CSV *document shape*. Native picks between its two CSV forms
        // with --full (absent = the `metric,value,unit` summary, present = the point table);
        // here --full only sets sampling density, so without a separate flag the summary form
        // — and therefore every summary field, zero_angle_degrees included — is unreachable
        // from the browser. A new flag rather than a re-use of --full: repointing --full at
        // the document shape would change what an existing `trajectory -o csv` invocation
        // emits, and the contract is that those stay byte-identical.
        let mut csv_summary = false;
        // MBA-1427: per-point effective drag coefficient in -o json (the WASM half of
        // MBA-1423, which shipped native-only — and whose requester runs this build).
        let mut with_drag_coefficient = false;
        // MBA-1337 p3: native --plot parity. None = no chart; Some(style) appends the
        // two terminal charts after the table, exactly like the native CLI.
        let mut plot: Option<crate::terminal_plot::CanvasStyle> = None;
        let mut auto_zero: Option<f64> = None;
        let mut sight_height = if units == UnitSystem::Imperial {
            2.0
        } else {
            50.0
        }; // inches or mm
        let mut muzzle_height = if units == UnitSystem::Imperial {
            60.0
        } else {
            1500.0
        }; // inches or mm (standing)
        let mut target_height = 0.0; // inches or mm (ground level)

        // Advanced physics flags
        let mut enable_magnus = false;
        let mut enable_coriolis = false;
        let mut use_euler = false;
        let mut use_rk4_fixed = false; // Use fixed-step RK4 instead of adaptive RK45
        let mut enable_spin_drift = false;
        let mut enable_wind_shear = false;
        let mut sample_trajectory = false;
        let mut sample_interval = 10.0;
        let mut enable_pitch_damping = false;
        let mut enable_precession = false;
        let mut use_bc_segments = false;
        let mut use_powder_sensitivity = false;
        // Bero-feedback (0.23.0): let a tester keep a full-range trajectory without abusing
        // --muzzle-height to defeat ground truncation (see the muzzle-height sanity warning
        // below — that abuse silently thins the density the whole flight sees).
        let mut ignore_ground_impact = false;
        // Bero-feedback (0.23.0): surface the velocity-keyed BC ladder actually applied
        // (manual --bc-segment or BC5D-synthesized), since the WASM has no stderr the way
        // the native CLI's --print-bc-segments does.
        let mut print_bc_segments = false;
        // Mover ring (MBA-1325): mph imperial / m/s metric, same convention as `lead
        // --target-speed`. 0.0 (default) disables the per-point Ring column/fields.
        let mut target_speed: f64 = 0.0;
        // Angular unit for the ring TABLE column (review fix M3) — native trajectory
        // already exposes --adjustment-unit (PDF dope card), so the WASM surface honors
        // it too. Only the table reads it; CSV keeps ring_mil and JSON keeps
        // mover_ring_m/mover_ring_mil (unit-in-the-name contract).
        let mut adjustment_unit = "mil";
        // MBA-1414: tracks whether --adjustment-unit was actually typed on this call.
        // Unlike native's clap `default_value` (where an explicit `mil` is
        // indistinguishable from never passing the flag, so native skips warning on mil),
        // this manual parser can tell "flag present" exactly regardless of value — so the
        // no-target-speed warning below keys off presence alone.
        let mut adjustment_unit_supplied = false;
        // MBA-1355: turret click graduations for `--adjustment-unit clicks`. Only
        // elevation is ever consumed (the Ring column, like the native PDF dope card's
        // Drop column, reuses the elevation graduation) — windage is parsed/validated
        // for CLI-flag parity with native trajectory but is otherwise inert here (WASM's
        // trajectory table has no PDF dope card / windage-driven column).
        let mut elevation_click_value: Option<&str> = None;
        let mut windage_click_value: Option<&str> = None;

        // Additional parameters
        let mut twist_rate: Option<f64> = None;
        let mut twist_right = true;
        let mut latitude: Option<f64> = None;
        let mut shot_direction: Option<f64> = None; // compass bearing, degrees, 0=N (Coriolis)
        let mut shooting_angle = 0.0;
        let mut cant_angle_deg = 0.0;
        let mut powder_temp_sensitivity = if units == UnitSystem::Imperial {
            1.0
        } else {
            0.3048 / (5.0 / 9.0)
        };
        let mut powder_temp = if units == UnitSystem::Imperial {
            crate::constants::DEFAULT_POWDER_REFERENCE_TEMP_F
        } else {
            crate::constants::DEFAULT_POWDER_REFERENCE_TEMP_C
        };
        // Optional measured powder-temperature -> velocity curve ("TEMP:VEL,..."),
        // parsed after unit resolution. Supersedes the linear sensitivity model.
        let mut powder_temp_curve_str: Option<String> = None;
        // Track whether --powder-temp was explicitly given. When a curve is present it
        // becomes the powder temperature the curve is interpolated at (decoupled from the
        // air temperature); when not given, the curve falls back to the air temperature.
        let mut powder_temp_provided = false;

        // Zero-day condition overrides. When --auto-zero is used, these let the zero
        // ANGLE be solved under the conditions the rifle was actually zeroed in (a
        // different day: air temperature, pressure, humidity, altitude, and — via the
        // caller's own powder-temp/velocity table — muzzle velocity), while the
        // trajectory itself runs under the current shot-day conditions. Omitting all zero-day
        // flags reuses the shot-day values exactly; coupled powder fallbacks are resolved below.
        let mut zero_velocity: Option<f64> = None;
        let mut zero_temperature: Option<f64> = None;
        let mut zero_pressure: Option<f64> = None;
        let mut zero_humidity: Option<f64> = None;
        let mut zero_altitude: Option<f64> = None;
        // MBA-1426 item 4: the zero-day density altitude, mirroring native's
        // --zero-density-altitude (MBA-1422). Supersedes --zero-altitude and
        // --zero-pressure/--zero-pressure-type for the zero solve only.
        let mut zero_density_altitude: Option<f64> = None;
        let mut zero_powder_temp: Option<f64> = None;
        // MBA-1359: deliberate POI offset at the zero range (inches imperial / cm metric;
        // Kestrel ZH/ZO semantics — positive = impacts high / right). Mirrors native's
        // --zero-poi-up/--zero-poi-right; only meaningful together with --auto-zero.
        let mut zero_poi_up: Option<f64> = None;
        let mut zero_poi_right: Option<f64> = None;
        // MBA-1396: lateral sight-to-bore mount offset (inches imperial / mm metric,
        // positive = sight RIGHT of bore). Mirrors native's --sight-offset.
        let mut sight_offset: Option<f64> = None;
        // MBA-1403: sampled-drop reference toggle; false = LOS (the historical default),
        // true = target plane. Mirrors native's --drops-reference {los|target}.
        let mut drops_reference_target = false;
        // MBA-1358: scope tracking correction factors (dial-unit outputs ÷ CF exactly
        // once; raw inches never). 1.0 = no correction, byte-identical. Elevation
        // corrects the auto-zero banner's MOA/mrad; windage corrects the mover Ring
        // dial outputs.
        let mut elevation_cf: f64 = 1.0;
        let mut windage_cf: f64 = 1.0;

        // Parse arguments
        let mut i = 0;
        while i < args.len() {
            match args[i] {
                "-v" | "--velocity" => {
                    if i + 1 < args.len() {
                        velocity = args[i + 1]
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid velocity"))?;
                        i += 1;
                    }
                }
                "-a" | "--angle" => {
                    if i + 1 < args.len() {
                        angle = args[i + 1]
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid angle"))?;
                        i += 1;
                    }
                }
                "-b" | "--bc" => {
                    if i + 1 < args.len() {
                        bc = args[i + 1]
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid BC"))?;
                        i += 1;
                    }
                }
                "--bc-reference" => {
                    if i + 1 < args.len() {
                        bc_reference_standard = parse_bc_reference_arg(args[i + 1])?;
                        i += 1;
                    }
                }
                "-m" | "--mass" => {
                    if i + 1 < args.len() {
                        mass = args[i + 1]
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid mass"))?;
                        i += 1;
                    }
                }
                "-d" | "--diameter" => {
                    if i + 1 < args.len() {
                        diameter = args[i + 1]
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid diameter"))?;
                        i += 1;
                    }
                }
                "--drag-model" => {
                    if i + 1 < args.len() {
                        drag_model = args[i + 1];
                        i += 1;
                    }
                }
                "--cd-scale" => {
                    if i + 1 < args.len() {
                        cd_scale = Some(
                            args[i + 1]
                                .parse()
                                .map_err(|_| JsValue::from_str("Invalid cd-scale"))?,
                        );
                        i += 1;
                    }
                }
                "--max-range" => {
                    if i + 1 < args.len() {
                        max_range = args[i + 1]
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid max range"))?;
                        i += 1;
                    }
                }
                "--time-step" => {
                    if i + 1 < args.len() {
                        time_step = args[i + 1]
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid time step"))?;
                        i += 1;
                    }
                }
                "--wind-speed" => {
                    if i + 1 < args.len() {
                        wind_speed = args[i + 1]
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid wind speed"))?;
                        i += 1;
                    }
                }
                "--wind-direction" => {
                    if i + 1 < args.len() {
                        // MBA-1367: the shared helper accepts degrees (unchanged) plus
                        // the marked clock forms (3oc, 10h30, 10:30).
                        let parsed = crate::wind::parse_wind_direction_standalone(args[i + 1])
                            .map_err(|e| JsValue::from_str(&format!("Error: {e}")))?;
                        wind_direction = parsed.degrees;
                        wind_direction_was_clock = parsed.was_clock;
                        i += 1;
                    }
                }
                "--wind-ref" => {
                    // MBA-1368 (require_value pattern for new arms per the MBA-1343
                    // hardening direction — the neighboring legacy arms are raw i+1).
                    let value = require_value(args, i)?;
                    wind_ref = crate::wind::WindReference::parse(value)
                        .map_err(|e| JsValue::from_str(&format!("Error: {e}")))?;
                    i += 1;
                }
                "--wind-vertical" => {
                    if i + 1 < args.len() {
                        wind_vertical = args[i + 1]
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid wind vertical"))?;
                        i += 1;
                    }
                }
                "--wind-segment" => {
                    if i + 1 < args.len() {
                        wind_segment_strs.push(args[i + 1].to_string());
                        i += 1;
                    }
                }
                "--bc-segment" => {
                    if i + 1 < args.len() {
                        bc_segment_strs.push(args[i + 1].to_string());
                        i += 1;
                    }
                }
                "--dsf-point" => {
                    if i + 1 < args.len() {
                        dsf_point_strs.push(args[i + 1].to_string());
                        i += 1;
                    }
                }
                "--temperature" => {
                    if i + 1 < args.len() {
                        temperature = args[i + 1]
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid temperature"))?;
                        temperature_supplied = true;
                        i += 1;
                    }
                }
                "--pressure" => {
                    if i + 1 < args.len() {
                        pressure = args[i + 1]
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid pressure"))?;
                        pressure_supplied = true;
                        i += 1;
                    }
                }
                "--pressure-type" => {
                    if i + 1 < args.len() {
                        pressure_type = parse_pressure_type_arg(args[i + 1])?;
                        pressure_type_supplied = true;
                        i += 1;
                    }
                }
                "--humidity" => {
                    if i + 1 < args.len() {
                        humidity = args[i + 1]
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid humidity"))?;
                        i += 1;
                    }
                }
                "--altitude" => {
                    if i + 1 < args.len() {
                        altitude = args[i + 1]
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid altitude"))?;
                        i += 1;
                    }
                }
                "--density-altitude" => {
                    if i + 1 < args.len() {
                        density_altitude = Some(
                            args[i + 1]
                                .parse()
                                .map_err(|_| JsValue::from_str("Invalid density altitude"))?,
                        );
                        i += 1;
                    }
                }
                "-o" | "--output" => {
                    if i + 1 < args.len() {
                        output_format = OutputFormat::from_str(args[i + 1]);
                        i += 1;
                    }
                }
                "--plot" => {
                    // clap parity (num_args 0..=1, default_missing_value "braille"):
                    // bare --plot before another flag = braille; an explicit next
                    // token is the style value and anything but braille/ascii is a
                    // hard error, exactly like the native CLI.
                    plot = Some(crate::terminal_plot::CanvasStyle::Braille);
                    if i + 1 < args.len() && !args[i + 1].starts_with('-') {
                        match args[i + 1] {
                            "braille" => i += 1,
                            "ascii" => {
                                plot = Some(crate::terminal_plot::CanvasStyle::Ascii);
                                i += 1;
                            }
                            other => {
                                return Err(JsValue::from_str(&format!(
                                    "Invalid value '{other}' for --plot (expected braille or ascii)"
                                )));
                            }
                        }
                    }
                }
                "--full" => full = true,
                "--csv-summary" => csv_summary = true,
                "--with-drag-coefficient" => with_drag_coefficient = true,
                "--auto-zero" | "-z" => {
                    if i + 1 < args.len() {
                        auto_zero = Some(
                            args[i + 1]
                                .parse()
                                .map_err(|_| JsValue::from_str("Invalid zero distance"))?,
                        );
                        i += 1;
                    }
                }
                "--sight-height" => {
                    if i + 1 < args.len() {
                        sight_height = args[i + 1]
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid sight height"))?;
                        i += 1;
                    }
                }
                // MBA-1339: --bore-height is the native CLI's name for this same parameter,
                // now on identical inches/mm units — accept both names on both surfaces.
                "--muzzle-height" | "--bore-height" => {
                    if i + 1 < args.len() {
                        muzzle_height = args[i + 1]
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid muzzle height"))?;
                        i += 1;
                    }
                }
                "--target-height" => {
                    if i + 1 < args.len() {
                        target_height = args[i + 1]
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid target height"))?;
                        i += 1;
                    }
                }
                "--enable-magnus" => enable_magnus = true,
                "--enable-coriolis" => enable_coriolis = true,
                "--use-euler" => use_euler = true,
                "--use-rk4-fixed" => use_rk4_fixed = true,
                "--enable-spin-drift" => enable_spin_drift = true,
                "--enable-wind-shear" => enable_wind_shear = true,
                "--sample-trajectory" => sample_trajectory = true,
                "--sample-interval" => {
                    if i + 1 < args.len() {
                        sample_interval = args[i + 1]
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid sample interval"))?;
                        i += 1;
                    }
                }
                "--enable-pitch-damping" => enable_pitch_damping = true,
                "--enable-precession" => enable_precession = true,
                "--use-bc-segments" => use_bc_segments = true,
                "--use-powder-sensitivity" => use_powder_sensitivity = true,
                "--ignore-ground-impact" => ignore_ground_impact = true,
                "--print-bc-segments" => print_bc_segments = true,
                "--target-speed" => {
                    if i + 1 < args.len() {
                        target_speed = args[i + 1]
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid target speed"))?;
                        // Same bound the native flags enforce via f64_range(0.0, 300.0)
                        // (review fix M1) — reject, never silently clamp.
                        if !(0.0..=300.0).contains(&target_speed) {
                            return Err(JsValue::from_str(&format!(
                                "--target-speed must be between 0 and 300 (mph/m/s), got {}",
                                target_speed
                            )));
                        }
                        i += 1;
                    }
                }
                "--adjustment-unit" => {
                    if i + 1 < args.len() {
                        adjustment_unit = args[i + 1];
                        adjustment_unit_supplied = true;
                        i += 1;
                    }
                }
                "--elevation-click-value" => {
                    if i + 1 < args.len() {
                        elevation_click_value = Some(args[i + 1]);
                        i += 1;
                    }
                }
                "--windage-click-value" => {
                    if i + 1 < args.len() {
                        windage_click_value = Some(args[i + 1]);
                        i += 1;
                    }
                }
                "--twist-rate" => {
                    if i + 1 < args.len() {
                        twist_rate = Some(
                            args[i + 1]
                                .parse()
                                .map_err(|_| JsValue::from_str("Invalid twist rate"))?,
                        );
                        i += 1;
                    }
                }
                "--twist-right" => {
                    if i + 1 < args.len() {
                        twist_right = args[i + 1]
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid twist direction"))?;
                        i += 1;
                    }
                }
                "--latitude" => {
                    if i + 1 < args.len() {
                        latitude = Some(
                            args[i + 1]
                                .parse()
                                .map_err(|_| JsValue::from_str("Invalid latitude"))?,
                        );
                        i += 1;
                    }
                }
                "--shot-direction" => {
                    if i + 1 < args.len() {
                        shot_direction = Some(
                            args[i + 1]
                                .parse()
                                .map_err(|_| JsValue::from_str("Invalid shot-direction"))?,
                        );
                        i += 1;
                    }
                }
                "--shooting-angle" => {
                    if i + 1 < args.len() {
                        shooting_angle = args[i + 1]
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid shooting angle"))?;
                        i += 1;
                    }
                }
                "--cant" | "--cant-angle" => {
                    if i + 1 < args.len() {
                        cant_angle_deg = args[i + 1]
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid cant angle"))?;
                        i += 1;
                    }
                }
                "--powder-temp-sensitivity" => {
                    if i + 1 < args.len() {
                        powder_temp_sensitivity = args[i + 1]
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid powder temp sensitivity"))?;
                        i += 1;
                    }
                }
                "--powder-temp" => {
                    if i + 1 < args.len() {
                        powder_temp = args[i + 1]
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid powder temp"))?;
                        powder_temp_provided = true;
                        i += 1;
                    }
                }
                "--powder-temp-curve" => {
                    if i + 1 < args.len() {
                        powder_temp_curve_str = Some(args[i + 1].to_string());
                        i += 1;
                    }
                }
                "--zero-velocity" => {
                    if i + 1 < args.len() {
                        zero_velocity = Some(
                            args[i + 1]
                                .parse()
                                .map_err(|_| JsValue::from_str("Invalid zero velocity"))?,
                        );
                        i += 1;
                    }
                }
                "--zero-temperature" => {
                    if i + 1 < args.len() {
                        zero_temperature = Some(
                            args[i + 1]
                                .parse()
                                .map_err(|_| JsValue::from_str("Invalid zero temperature"))?,
                        );
                        i += 1;
                    }
                }
                "--zero-pressure" => {
                    if i + 1 < args.len() {
                        zero_pressure = Some(
                            args[i + 1]
                                .parse()
                                .map_err(|_| JsValue::from_str("Invalid zero pressure"))?,
                        );
                        i += 1;
                    }
                }
                "--zero-pressure-type" => {
                    if i + 1 < args.len() {
                        zero_pressure_type = Some(parse_pressure_type_arg(args[i + 1])?);
                        i += 1;
                    }
                }
                "--zero-humidity" => {
                    if i + 1 < args.len() {
                        zero_humidity = Some(
                            args[i + 1]
                                .parse()
                                .map_err(|_| JsValue::from_str("Invalid zero humidity"))?,
                        );
                        i += 1;
                    }
                }
                "--zero-density-altitude" => {
                    if i + 1 < args.len() {
                        zero_density_altitude = Some(
                            args[i + 1]
                                .parse()
                                .map_err(|_| JsValue::from_str("Invalid zero-density-altitude"))?,
                        );
                        i += 1;
                    }
                }
                "--zero-altitude" => {
                    if i + 1 < args.len() {
                        zero_altitude = Some(
                            args[i + 1]
                                .parse()
                                .map_err(|_| JsValue::from_str("Invalid zero altitude"))?,
                        );
                        i += 1;
                    }
                }
                "--zero-powder-temp" => {
                    if i + 1 < args.len() {
                        zero_powder_temp = Some(
                            args[i + 1]
                                .parse()
                                .map_err(|_| JsValue::from_str("Invalid zero powder temp"))?,
                        );
                        i += 1;
                    }
                }
                // MBA-1359: new arms follow the require_value hardening contract (MBA-1343)
                // — a dangling flag is an error, never a silent skip.
                "--zero-poi-up" => {
                    zero_poi_up = Some(
                        require_value(args, i)?
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid zero POI up offset"))?,
                    );
                    i += 1;
                }
                "--zero-poi-right" => {
                    zero_poi_right = Some(
                        require_value(args, i)?
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid zero POI right offset"))?,
                    );
                    i += 1;
                }
                "--sight-offset" => {
                    sight_offset = Some(
                        require_value(args, i)?
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid sight offset"))?,
                    );
                    i += 1;
                }
                // MBA-1403: sampled-drop reference toggle (los | target).
                "--drops-reference" => {
                    drops_reference_target = match require_value(args, i)? {
                        "los" => false,
                        "target" => true,
                        other => {
                            return Err(JsValue::from_str(&format!(
                                "Invalid drops reference '{}': expected 'los' or 'target'",
                                other
                            )))
                        }
                    };
                    i += 1;
                }
                // MBA-1358: scope tracking correction factors, same accepted band as the
                // native CLI (strictly between 0.5 and 1.5, shared bound).
                "--elevation-cf" => {
                    elevation_cf = require_value(args, i)?
                        .parse()
                        .map_err(|_| JsValue::from_str("Invalid elevation CF"))?;
                    if !crate::adjustment::tracking_cf_in_range(elevation_cf) {
                        return Err(JsValue::from_str(
                            "--elevation-cf must be a tracking correction factor strictly \
                             between 0.5 and 1.5",
                        ));
                    }
                    i += 1;
                }
                "--windage-cf" => {
                    windage_cf = require_value(args, i)?
                        .parse()
                        .map_err(|_| JsValue::from_str("Invalid windage CF"))?;
                    if !crate::adjustment::tracking_cf_in_range(windage_cf) {
                        return Err(JsValue::from_str(
                            "--windage-cf must be a tracking correction factor strictly \
                             between 0.5 and 1.5",
                        ));
                    }
                    i += 1;
                }
                // --units/-u (+ its value) is consumed globally in run_command, which
                // pre-scans it to set the unit system before dispatch. Skip it here so
                // it isn't rejected as an unknown flag (this is what blocked metric input).
                "--units" | "-u" => {
                    i += 1;
                }
                // Reject unrecognized flags instead of silently ignoring them, so a
                // typo or a flag that isn't wired into this WASM surface is caught
                // immediately rather than looking like a no-op. (The native CLI's clap
                // parser already does this; the hand-rolled WASM parser did not.)
                other if other.starts_with('-') => {
                    return Err(JsValue::from_str(&format!("Unknown flag: {}", other)));
                }
                _ => {}
            }
            i += 1;
        }

        // MBA-1433: --csv-summary changes the shape of a CSV document and has no meaning for
        // the other two formats. Refuse it rather than accept-and-ignore, which is how the
        // caller who reported the missing zero angle came to believe the field was absent
        // from the build rather than from the format they asked for.
        if csv_summary && !matches!(output_format, OutputFormat::Csv) {
            return Err(JsValue::from_str(
                "--csv-summary applies only to -o csv (the table and JSON forms already \
                 carry their summary)",
            ));
        }

        // MBA-1411: validate the per-call DSF table (if any) before doing any solve work —
        // dimensionless (Mach/DSF ratio), so no unit conversion is needed.
        let dsf_table = parse_dsf_points(&dsf_point_strs)?;

        // Build inputs with unit conversions
        let mut inputs = InternalBallisticInputs::default();

        // Convert units to metric (internal representation)
        match units {
            UnitSystem::Imperial => {
                inputs.muzzle_velocity = velocity * 0.3048; // fps to m/s
                inputs.bullet_mass = mass * crate::constants::GRAINS_TO_KG; // grains to kg
                inputs.bullet_diameter = diameter * 0.0254; // inches to meters
                inputs.sight_height = sight_height * 0.0254; // inches to meters
                inputs.muzzle_height = muzzle_height * 0.0254; // inches to meters
                inputs.target_height = target_height * 0.0254; // inches to meters
            }
            UnitSystem::Metric => {
                inputs.muzzle_velocity = velocity; // already m/s
                inputs.bullet_mass = mass * 0.001; // grams to kg
                inputs.bullet_diameter = diameter * 0.001; // mm to meters
                inputs.sight_height = sight_height * 0.001; // mm to meters
                inputs.muzzle_height = muzzle_height * 0.001; // mm to meters
                inputs.target_height = target_height * 0.001; // mm to meters
            }
        }

        // MBA-1359: deliberate POI offset at the zero range — inches (imperial) or
        // centimeters (metric) at the flag, meters on the inputs, matching native.
        if let Some(v) = zero_poi_up {
            inputs.zero_poi_vertical_m = match units {
                UnitSystem::Imperial => v * 0.0254, // inches to meters
                UnitSystem::Metric => v * 0.01,     // centimeters to meters
            };
        }
        if let Some(v) = zero_poi_right {
            inputs.zero_poi_horizontal_m = match units {
                UnitSystem::Imperial => v * 0.0254, // inches to meters
                UnitSystem::Metric => v * 0.01,     // centimeters to meters
            };
        }
        // MBA-1396: lateral sight-mount offset — same in/mm units as --sight-height.
        if let Some(v) = sight_offset {
            inputs.sight_offset_lateral_m = match units {
                UnitSystem::Imperial => v * 0.0254, // inches to meters
                UnitSystem::Metric => v * 0.001,    // millimeters to meters
            };
        }
        // MBA-1135: mass-based length estimate (mirrors CLI/FFI), replacing the mass-blind
        // 4.5-caliber heuristic. WASM otherwise left it at the struct default regardless of the
        // supplied caliber/weight, skewing the Miller Sg / Litz spin drift / Magnus.
        inputs.bullet_length =
            crate::stability::estimate_bullet_length_m(inputs.bullet_diameter, inputs.bullet_mass);
        if inputs.bullet_length <= 0.0 {
            inputs.bullet_length = inputs.bullet_diameter * 4.5;
        }

        inputs.bc_value = bc;
        inputs.bc_reference_standard = bc_reference_standard;
        let drag_model_parsed = DragModel::from_str(drag_model)
            .ok_or_else(|| JsValue::from_str("Invalid drag model"))?;
        inputs.bc_type = drag_model_parsed;
        // Custom drag table (MBA-1328): a table loaded via loadDragTable() is a full physical
        // substitute for the BC + G-model (see calculate_drag_coefficient) — apply it
        // unconditionally when present, mirroring native --drag-table (main.rs
        // load_drag_table_or_exit). Unlike a loaded BC5D table it needs no --use-* gate flag.
        if let Some(table) = self.drag_table.borrow().as_ref() {
            inputs.custom_drag_table = Some(table.clone());
        }
        // MBA-1356: --cd-scale requires a loaded drag table, mirroring the native CLI's
        // --cd-scale/--drag-table pairing requirement. Validate before any solve.
        if let Some(scale) = cd_scale {
            if self.drag_table.borrow().is_none() {
                return Err(JsValue::from_str(CD_SCALE_REQUIRES_DRAG_TABLE));
            }
            inputs.cd_scale = scale;
        }
        let cd_scale_warning = cd_scale.and_then(cd_scale_range_warning);
        // MBA-1365: --bc-reference army-standard-metro has no effect once a custom drag
        // table replaces the BC-based retardation model entirely. The browser terminal has
        // no visible stderr (MBA-1414 precedent), so this rides the same pre-table warning
        // text block as `cd_scale_warning` instead of an `eprintln!`.
        let bc_reference_warning = inputs
            .bc_reference_standard_inert_warning()
            .map(|w| format!("{w}\n\n"));
        inputs.muzzle_angle = angle * std::f64::consts::PI / 180.0; // degrees to radians
        inputs.shooting_angle = shooting_angle * std::f64::consts::PI / 180.0;
        inputs.cant_angle = cant_angle_deg * std::f64::consts::PI / 180.0;
        inputs.ground_threshold = if ignore_ground_impact {
            f64::NEG_INFINITY
        } else {
            0.0
        };

        // Bero-feedback (0.23.0): trajectory altitude feeds air density (thinning it over a
        // long flight), so a tester using --muzzle-height to defeat ground truncation instead
        // of --ignore-ground-impact silently flies through unrealistically thin air. Warn
        // (don't clamp) once the bore sits implausibly high — matches the native CLI threshold.
        let muzzle_height_warning = if inputs.muzzle_height > 1000.0 {
            let muzzle_unit_label = match units {
                UnitSystem::Imperial => "in",
                UnitSystem::Metric => "mm",
            };
            Some(format!(
                "WARNING: --muzzle-height {muzzle_height}{muzzle_unit_label} puts the bore \
                 {:.0} m above ground. Trajectory altitude feeds air density, so this thins \
                 the air over the whole flight (a 25 km 'muzzle height' flies in ~2% density). \
                 If you meant site elevation use --altitude; to defeat ground truncation use \
                 --ignore-ground-impact.\n\n",
                inputs.muzzle_height
            ))
        } else {
            None
        };

        // Set advanced physics flags. enable_advanced_effects remains the umbrella
        // flag, but Magnus and Coriolis are now gated independently so enabling one
        // does not silently enable the other.
        if enable_magnus || enable_coriolis {
            inputs.enable_advanced_effects = true;
        }
        inputs.enable_magnus = enable_magnus;
        inputs.enable_coriolis = enable_coriolis;
        // Set integration method: Euler < RK4 fixed < RK45 adaptive (default)
        if use_euler {
            inputs.use_rk4 = false;
            inputs.use_adaptive_rk45 = false;
        } else if use_rk4_fixed {
            inputs.use_rk4 = true;
            inputs.use_adaptive_rk45 = false; // Fixed-step RK4
        } else {
            inputs.use_rk4 = true;
            inputs.use_adaptive_rk45 = true; // Default: adaptive RK45
        }
        inputs.use_enhanced_spin_drift = enable_spin_drift;
        inputs.enable_wind_shear = enable_wind_shear;
        inputs.enable_trajectory_sampling = sample_trajectory;
        inputs.sample_interval = sample_interval;
        // MBA-1403: sampled-drop reference. Los (the default) is byte-identical to the
        // historical output; Target scales sampled drop by 1/cos(shooting angle) inside
        // the engine's shared sampling helper and relabels the table/CSV drop column.
        inputs.drops_reference = if drops_reference_target {
            crate::cli_api::DropsReference::Target
        } else {
            crate::cli_api::DropsReference::Los
        };
        inputs.enable_pitch_damping = enable_pitch_damping;
        inputs.enable_precession_nutation = enable_precession;
        inputs.use_bc_segments = use_bc_segments;
        inputs.use_powder_sensitivity = use_powder_sensitivity;

        // Velocity-keyed BC segments, in priority order:
        //   1. manual --bc-segment "VMIN:VMAX:BC" pairs (explicit user input)
        //   2. a BC5D table loaded via loadBc5dTable() + --use-bc-segments
        // Velocities are in the command's display units (fps imperial, m/s metric);
        // the solver compares against fps, so convert.
        let vel_to_fps = match units {
            UnitSystem::Imperial => 1.0,
            UnitSystem::Metric => 3.280_839_895,
        };
        let mut manual_bc_segments: Vec<crate::BCSegmentData> = Vec::new();
        for s in &bc_segment_strs {
            let parts: Vec<&str> = s.split(':').collect();
            if parts.len() != 3 {
                return Err(JsValue::from_str(&format!(
                    "--bc-segment expects VMIN:VMAX:BC (e.g. 1500:1800:0.243), got '{}'",
                    s
                )));
            }
            let vmin: f64 = parts[0].trim().parse().map_err(|_| {
                JsValue::from_str(&format!("--bc-segment: invalid VMIN in '{}'", s))
            })?;
            let vmax: f64 = parts[1].trim().parse().map_err(|_| {
                JsValue::from_str(&format!("--bc-segment: invalid VMAX in '{}'", s))
            })?;
            let bcv: f64 = parts[2]
                .trim()
                .parse()
                .map_err(|_| JsValue::from_str(&format!("--bc-segment: invalid BC in '{}'", s)))?;
            if !(vmin < vmax) {
                return Err(JsValue::from_str(&format!(
                    "--bc-segment: VMIN must be < VMAX in '{}'",
                    s
                )));
            }
            if bcv <= 0.0 {
                return Err(JsValue::from_str(&format!(
                    "--bc-segment: BC must be > 0 in '{}'",
                    s
                )));
            }
            manual_bc_segments.push(crate::BCSegmentData {
                velocity_min: vmin * vel_to_fps,
                velocity_max: vmax * vel_to_fps,
                bc_value: bcv,
            });
        }

        let mut bc5d_coercion_warning: Option<String> = None;
        if !manual_bc_segments.is_empty() {
            // Manual segments win; imply --use-bc-segments so they're applied.
            inputs.bc_segments_data = Some(manual_bc_segments);
            inputs.use_bc_segments = true;
        } else if use_bc_segments {
            // BC5D offline correction: synthesize velocity-dependent BC segments
            // from a loaded table. The table's native units are grains + fps.
            if let Some(table) = self.bc5d_table.borrow().as_ref() {
                // The loaded table must be for THIS bullet's caliber. loadBc5dTable takes
                // raw bytes, so nothing before this point ties the table's content to the
                // shot; a foreign table would still return a full plausible ladder and
                // silently bias every row (see Bc5dTable::ensure_caliber_matches), so a
                // mismatch is a hard error rather than a quietly uncorrected solve.
                table
                    .ensure_caliber_matches(inputs.bullet_diameter / 0.0254)
                    .map_err(|e| JsValue::from_str(&e.to_string()))?;
                let (weight_grains, muzzle_fps) = match units {
                    UnitSystem::Imperial => (mass, velocity),
                    UnitSystem::Metric => (mass * GRAINS_PER_GRAM, velocity * 3.280839895),
                };
                // MBA-1386: generate_segment_schedule types anything non-G7 as G1
                // (bc_table_5d.rs); surface the coercion like the native aux paths do.
                if !drag_model.eq_ignore_ascii_case("g1") && !drag_model.eq_ignore_ascii_case("g7")
                {
                    bc5d_coercion_warning = Some(format!(
                        "warning: BC5D correction tables support G1/G7 only; treating drag \
                         model '{}' as G1\n\n",
                        drag_model.to_uppercase()
                    ));
                }
                if let Some(schedule) =
                    table.generate_segment_schedule(bc, drag_model, weight_grains, muzzle_fps)
                {
                    inputs.bc_segments_data = Some(schedule.segments);
                    inputs.bc_value = schedule.fallback_bc;
                }
            }
        }

        // Set additional parameters
        let explicit_twist_inches = twist_rate.map(|rate| match units {
            UnitSystem::Imperial => rate,
            UnitSystem::Metric => rate / 25.4,
        });
        inputs.twist_rate = crate::stability::resolve_twist_inches(
            explicit_twist_inches,
            inputs.bullet_diameter,
            inputs.bullet_mass,
            inputs.muzzle_velocity,
        );
        inputs.is_twist_right = twist_right;
        if let Some(lat) = latitude {
            inputs.latitude = Some(lat);
        }
        inputs.shot_azimuth = shot_direction.map(|d| d.to_radians()).unwrap_or(0.0);
        inputs.powder_temp_sensitivity = match units {
            UnitSystem::Imperial => powder_temp_sensitivity * 0.3048 / (5.0 / 9.0),
            UnitSystem::Metric => powder_temp_sensitivity,
        };
        inputs.powder_temp = match units {
            UnitSystem::Imperial => (powder_temp - 32.0) * 5.0 / 9.0,
            UnitSystem::Metric => powder_temp,
        };
        // When --powder-temp was explicitly given, it becomes the POWDER temperature the
        // curve is interpolated at (decoupled from --temperature / air density). When not
        // given, powder_curve_temp_c stays None so the curve falls back to the air temp.
        inputs.powder_curve_temp_c = if powder_temp_provided {
            Some(inputs.powder_temp)
        } else {
            None
        };
        // Parse the optional powder-temperature -> velocity curve into SI points
        // (shared parser — see parse_powder_temp_curve_str).
        if let Some(curve_str) = &powder_temp_curve_str {
            inputs.powder_temp_curve = Some(parse_powder_temp_curve_str(curve_str, units)?);
        }

        // Set wind conditions
        let mut wind = WindConditions::default();
        match units {
            UnitSystem::Imperial => {
                wind.speed = wind_speed * 0.44704; // mph to m/s
                wind.vertical_speed = wind_vertical * 0.44704; // mph to m/s
            }
            UnitSystem::Metric => {
                wind.speed = wind_speed; // already m/s
                wind.vertical_speed = wind_vertical; // already m/s
            }
        }
        // MBA-1368: a compass bearing becomes shooter-relative HERE — before this
        // WindConditions is built, so the zero solve and the flight both inherit the
        // converted value. Shooter mode leaves the entered degrees untouched
        // (bit-identical). Clock positions are shooter-relative by definition and are
        // rejected in compass mode; an absent --shot-direction is a hard error (never
        // a silent treat-as-shooter-relative).
        if wind_ref == crate::wind::WindReference::Compass {
            if wind_direction_was_clock {
                return Err(JsValue::from_str(
                    "Error: clock positions are shooter-relative by definition; use                      degrees with --wind-ref compass",
                ));
            }
            let Some(azimuth) = shot_direction else {
                return Err(JsValue::from_str(
                    "Error: --wind-ref compass requires --shot-direction (earth-fixed                      wind bearings are re-referenced against the shot azimuth)",
                ));
            };
            wind_direction =
                crate::wind::compass_bearing_to_shooter_relative_deg(wind_direction, azimuth);
        }
        // WindConditions.direction is RADIANS (0=North, PI/2=East); --wind-direction is degrees.
        // Convert (matches native CLI); previously a 90-degree crosswind was fed as 90 radians.
        wind.direction = wind_direction.to_radians();

        // Set atmospheric conditions
        let mut atmosphere = AtmosphericConditions::default();
        match units {
            UnitSystem::Imperial => {
                atmosphere.temperature = (temperature - 32.0) * 5.0 / 9.0; // F to C
                atmosphere.pressure = pressure * 33.863886666667; // inHg to hPa
                atmosphere.altitude = altitude * 0.3048; // feet to meters
            }
            UnitSystem::Metric => {
                atmosphere.temperature = temperature;
                atmosphere.pressure = pressure;
                atmosphere.altitude = altitude;
            }
        }
        atmosphere.humidity = humidity;
        inputs.temperature = atmosphere.temperature;
        inputs.pressure = atmosphere.pressure;
        inputs.humidity = (humidity / 100.0).clamp(0.0, 1.0);
        inputs.altitude = atmosphere.altitude;

        // MBA-1366: --density-altitude supersedes altitude/pressure/pressure-type entirely,
        // back-solving an ISA-equivalent atmosphere (NOT the direct-density bypass) exactly
        // like the native CLI's --density-altitude. An explicit --temperature still wins over
        // the ISA-at-density-altitude default; the FAA-rule DA is honored either way (see
        // `atmosphere::resolve_atmosphere_for_density_altitude`'s doc comment).
        let mut density_altitude_active = false;
        let mut density_altitude_warning: Option<String> = None;
        if let Some(da) = density_altitude {
            let da_m = match units {
                UnitSystem::Imperial => da * 0.3048,
                UnitSystem::Metric => da,
            };
            let explicit_temp_c = temperature_supplied.then_some(atmosphere.temperature);
            let (da_altitude_m, da_temp_c, da_pressure_hpa) =
                crate::atmosphere::resolve_atmosphere_for_density_altitude(da_m, explicit_temp_c);
            atmosphere.temperature = da_temp_c;
            atmosphere.pressure = da_pressure_hpa;
            atmosphere.altitude = da_altitude_m;
            inputs.temperature = da_temp_c;
            inputs.pressure = da_pressure_hpa;
            inputs.altitude = da_altitude_m;
            density_altitude_active = true;
            // The pressure just derived from density altitude IS absolute station pressure, so
            // the declared mode no longer describes it. Native does the same reset (main.rs's
            // `final_pressure_type` becomes `Absolute` in its density-altitude arm). Without
            // this, `--density-altitude X --pressure-type qnh --auto-zero Y` leaves the stale
            // `Qnh` mode for the zero-day solve below to inherit, which reduces an already
            // absolute pressure a second time (~7% error at 2000 ft DA) — shot day correct,
            // zero day silently wrong.
            pressure_type = PressureReferenceMode::Absolute;
            if pressure_supplied || pressure_type_supplied {
                // MBA-1414 precedent: the browser terminal has no visible stderr, so this rides
                // the table-only warning block instead of an eprintln!.
                density_altitude_warning = Some(
                    "note: --density-altitude supersedes --pressure/--pressure-type (station \
                     pressure is derived from density altitude instead)\n\n"
                        .to_string(),
                );
            }
        }

        // Handle auto-zero if specified
        // MBA-1418: declared alongside its sibling warnings rather than inside the auto-zero
        // block, because the output assembly that emits it is at this scope.
        let mut zero_pressure_type_notice: Option<&'static str> = None;
        let mut zero_info = String::new();
        // MBA-1402 parity: native emits the solved zero angle on its JSON and CSV surfaces too,
        // not only in the human banner. The browser build shipped it in text alone, which an
        // external consumer parsing the WASM JSON reported as a divergence from native.
        let mut solved_zero_angle_deg: Option<f64> = None;
        if let Some(zero_distance) = auto_zero {
            let zero_distance_m = match units {
                UnitSystem::Imperial => zero_distance * 0.9144, // yards to meters
                UnitSystem::Metric => zero_distance,
            };

            // Build the condition set the zero ANGLE is solved under. It starts from the
            // shot-day inputs/atmosphere and is overridden only by whichever --zero-*
            // flags the caller supplied, so a rifle zeroed on a different day (different
            // air density and/or muzzle velocity) is modeled correctly while the
            // trajectory below still runs under the current shot-day conditions.
            let mut zero_inputs = inputs.clone();
            // The zero is torn on a LEVEL range: shot-day slope and cant belong to
            // the SHOT, not the zero geometry. The native CLI's zero_inputs literal
            // never carries them (both default to 0); this clone must strip them or
            // an inclined shot (--shooting-angle) makes the zero root-find
            // unbracketable — and where it does converge, it bakes the incline into
            // the zero, which is the wrong physics (Bero's PRS report).
            zero_inputs.shooting_angle = 0.0;
            zero_inputs.cant_angle = 0.0;
            // Fix-half of MBA-1384: the native CLI zero solve never carries
            // Coriolis — its zero_inputs literal ends in Default::default()
            // (enable_coriolis=false, latitude=None, shot_azimuth=0), while this
            // clone runs after the shot's Coriolis fields are set. Strip them so
            // the terminal and the CLI agree on the rifle zero. Zero-day opt-in
            // flags (--zero-latitude/--zero-azimuth) are the deferred feature
            // half of MBA-1384.
            zero_inputs.enable_coriolis = false;
            zero_inputs.latitude = None;
            zero_inputs.shot_azimuth = 0.0;
            let mut zero_atmosphere = atmosphere.clone();
            let mut zero_day_overridden = false;
            if let Some(zv) = zero_velocity {
                zero_inputs.muzzle_velocity = match units {
                    UnitSystem::Imperial => zv * 0.3048, // fps to m/s
                    UnitSystem::Metric => zv,
                };
                // An explicit zero-day velocity takes precedence: disable both velocity
                // adjustment models for the zero solve so neither changes the supplied value.
                // (zero_inputs is a clone of inputs, which may carry the shot-day models.)
                zero_inputs.powder_temp_curve = None;
                zero_inputs.use_powder_sensitivity = false;
                zero_day_overridden = true;
            }
            if let Some(zt) = zero_temperature {
                let t_c = match units {
                    UnitSystem::Imperial => (zt - 32.0) * 5.0 / 9.0, // F to C
                    UnitSystem::Metric => zt,
                };
                zero_atmosphere.temperature = t_c;
                zero_inputs.temperature = t_c;
                zero_day_overridden = true;
            }
            if let Some(zp) = zero_pressure {
                let p_hpa = match units {
                    UnitSystem::Imperial => zp * 33.863886666667, // inHg to hPa
                    UnitSystem::Metric => zp,
                };
                zero_atmosphere.pressure = p_hpa;
                zero_inputs.pressure = p_hpa;
                zero_day_overridden = true;
            }
            if let Some(zh) = zero_humidity {
                zero_atmosphere.humidity = zh;
                zero_inputs.humidity = (zh / 100.0).clamp(0.0, 1.0);
                zero_day_overridden = true;
            }
            if let Some(za) = zero_altitude {
                let a_m = match units {
                    UnitSystem::Imperial => za * 0.3048, // feet to meters
                    UnitSystem::Metric => za,
                };
                zero_atmosphere.altitude = a_m;
                zero_inputs.altitude = a_m;
                zero_day_overridden = true;
            }
            // MBA-1426 item 4 / MBA-1422: a zero-day density altitude supersedes the zero-day
            // altitude and pressure above — an ISA-equivalent station atmosphere is back-solved
            // from it, exactly as native does. An explicit --zero-temperature still wins over
            // the ISA temperature (the resolver re-solves pressure around it so the requested
            // DA is reproduced), which is why the converted zero-day temperature is passed in.
            if let Some(zda) = zero_density_altitude {
                let da_m = match units {
                    UnitSystem::Imperial => zda * 0.3048, // feet to meters
                    UnitSystem::Metric => zda,
                };
                let explicit_zero_temp_c = zero_temperature.map(|t| match units {
                    UnitSystem::Imperial => (t - 32.0) * 5.0 / 9.0,
                    UnitSystem::Metric => t,
                });
                let (da_altitude_m, da_temp_c, da_pressure_hpa) =
                    crate::atmosphere::resolve_atmosphere_for_density_altitude(
                        da_m,
                        explicit_zero_temp_c,
                    );
                zero_atmosphere.temperature = da_temp_c;
                zero_inputs.temperature = da_temp_c;
                zero_atmosphere.pressure = da_pressure_hpa;
                zero_inputs.pressure = da_pressure_hpa;
                zero_atmosphere.altitude = da_altitude_m;
                zero_inputs.altitude = da_altitude_m;
                zero_day_overridden = true;
            }

            // An explicit zero-day powder temperature wins. Otherwise an explicit zero-day air
            // temperature retains the established "powder follows zero-day air" behavior. With
            // neither override, keep the cloned shot-day powder temperature so a no-override
            // zero solve reproduces the flight conditions exactly.
            if let Some(zpt) = zero_powder_temp {
                zero_inputs.powder_curve_temp_c = Some(match units {
                    UnitSystem::Imperial => (zpt - 32.0) * 5.0 / 9.0,
                    UnitSystem::Metric => zpt,
                });
                zero_day_overridden = true;
            } else if zero_temperature.is_some() {
                zero_inputs.powder_curve_temp_c = None;
            }

            // MBA-1397: an explicit --zero-pressure-type wins; otherwise the zero day shares
            // the shot day's mode (mirrors "omitting all --zero-* flags reuses the shot-day
            // values" for the numeric fields above).
            //
            // Whole-branch review (I2), mirroring native: with --density-altitude and no
            // --zero-pressure, the zero day inherits the DA-derived station pressure, which is
            // already absolute. An explicit --zero-pressure-type qnh would reduce it a second
            // time. The mode has no value of its own to describe, so it cannot apply.
            //
            // MBA-1418: native prints a warning when this forcing happens. The browser terminal
            // has no visible stderr, so the notice is spliced into the output text instead --
            // the same convention the --cd-scale range warning and the inert --bc-reference
            // warning already use here. Silently forcing Absolute is the MBA-1414 class (a flag
            // that does nothing without saying so) that 0.29.0 spent its effort closing.
            let zero_pressure_type_resolved = match (
                zero_pressure_type,
                density_altitude_active || zero_density_altitude.is_some(),
                zero_pressure,
            ) {
                (Some(mode), true, None) => {
                    if mode != PressureReferenceMode::Absolute {
                        // MBA-1422 parity: name whichever flag actually supplied the zero-day
                        // pressure — a zero-day DA takes precedence over an inherited shot-day
                        // one, so it gets the blame line.
                        zero_pressure_type_notice = Some(if zero_density_altitude.is_some() {
                            "warning: --zero-pressure-type is ignored because --zero-density-altitude supplies the zero-day station pressure directly; pass --zero-pressure to declare a zero-day pressure of your own\n\n"
                        } else {
                            "warning: --zero-pressure-type is ignored because --density-altitude supplies the zero-day station pressure directly; pass --zero-pressure to declare a zero-day pressure of your own\n\n"
                        });
                    }
                    PressureReferenceMode::Absolute
                }
                (Some(mode), _, _) => mode,
                (None, _, _) => pressure_type,
            };
            let zero_target_height = zero_inputs.muzzle_height + zero_inputs.sight_height; // Zero crosses the line of sight (matches CLI)
            let zero_solve_result = match zero_pressure_type_resolved {
                PressureReferenceMode::Absolute => calculate_zero_angle_with_conditions(
                    zero_inputs.clone(),
                    zero_distance_m,
                    zero_target_height,
                    wind.clone(),
                    zero_atmosphere.clone(),
                ),
                PressureReferenceMode::Qnh => {
                    let (resolved_temp_c, resolved_pressure_hpa) =
                        resolve_station_conditions_with_pressure_mode(
                            zero_atmosphere.temperature,
                            zero_atmosphere.pressure,
                            zero_atmosphere.altitude,
                            PressureReferenceMode::Qnh,
                        );
                    let mut resolved_zero_atmosphere = zero_atmosphere.clone();
                    resolved_zero_atmosphere.temperature = resolved_temp_c;
                    resolved_zero_atmosphere.pressure = resolved_pressure_hpa;
                    calculate_zero_angle_with_resolved_conditions(
                        zero_inputs.clone(),
                        zero_distance_m,
                        zero_target_height,
                        wind.clone(),
                        resolved_zero_atmosphere,
                    )
                }
            };
            match zero_solve_result {
                Ok(zero_angle) => {
                    inputs.muzzle_angle = zero_angle;
                    // MBA-1359: the returned angle already carries the vertical POI bias
                    // (zero_inputs is a clone of `inputs`, so it carried the offsets into
                    // the solve); the horizontal bias is an azimuth term the angle copy
                    // cannot carry — apply it to the flight inputs here, exactly as
                    // calculate_and_set_zero_angle applies it to its own solver. Exact
                    // no-op when the offset is 0.0.
                    inputs.azimuth_angle += inputs.windage_zero_bias_rad(zero_distance_m);
                    let degrees_adjustment = zero_angle * 180.0 / std::f64::consts::PI;
                    solved_zero_angle_deg = Some(degrees_adjustment);
                    // MBA-1358: the banner's MOA/mrad are dial-unit outputs — divided
                    // by the elevation CF via the shared, host-tested helper (/1.0
                    // exact). The degrees echo above is a bore angle, not a dial value:
                    // unscaled.
                    let (moa_adjustment, mrad_adjustment) =
                        crate::adjustment::zero_banner_dial_values(
                            degrees_adjustment,
                            zero_angle,
                            elevation_cf,
                        );
                    // MBA-1402: the solved zero angle in degrees was missing here (native
                    // `trajectory`'s equivalent auto-zero echo had no degrees field at all
                    // until this same ticket; this banner already had MOA/mrad).
                    zero_info = format!(
                        "Rifle zeroed at {} {}{} (Adjustment: {:.4}\u{b0} / {:.2} MOA / {:.2} mrad up)\n\n",
                        zero_distance,
                        if units == UnitSystem::Imperial {
                            "yards"
                        } else {
                            "meters"
                        },
                        if zero_day_overridden {
                            " under supplied zero-day conditions"
                        } else {
                            ""
                        },
                        degrees_adjustment,
                        moa_adjustment,
                        mrad_adjustment
                    );
                }
                Err(e) => {
                    return Ok(format!("Error calculating zero: {}\n\nTry a shorter zero distance or check your ballistic parameters.", e));
                }
            }
        }

        // Create solver and calculate. MBA-1397: Absolute is byte-identical to today
        // (unchanged constructor); Qnh reduces the declared altimeter setting to station
        // pressure and uses the Authoritative constructor so it is never re-interpreted
        // through the legacy default-sentinel heuristic. MBA-1366: density altitude is
        // ALREADY fully resolved above (`resolve_atmosphere_for_density_altitude`) and must
        // use the Authoritative constructor unconditionally too — routing it through the
        // Absolute branch's legacy `TrajectorySolver::new` would re-derive it through that
        // same default-sentinel heuristic a second time, risking a misfire exactly like the
        // QNH case above (see the comment where `density_altitude_active` is set).
        let mut solver = if density_altitude_active {
            TrajectorySolver::new_with_resolved_station_atmosphere(inputs.clone(), wind, atmosphere)
        } else {
            match pressure_type {
                PressureReferenceMode::Absolute => {
                    TrajectorySolver::new(inputs.clone(), wind, atmosphere)
                }
                PressureReferenceMode::Qnh => {
                    let (resolved_temp_c, resolved_pressure_hpa) =
                        resolve_station_conditions_with_pressure_mode(
                            atmosphere.temperature,
                            atmosphere.pressure,
                            atmosphere.altitude,
                            PressureReferenceMode::Qnh,
                        );
                    let mut resolved_atmosphere = atmosphere.clone();
                    resolved_atmosphere.temperature = resolved_temp_c;
                    resolved_atmosphere.pressure = resolved_pressure_hpa;
                    TrajectorySolver::new_with_resolved_station_atmosphere(
                        inputs.clone(),
                        wind,
                        resolved_atmosphere,
                    )
                }
            }
        };
        let max_range_m = match units {
            UnitSystem::Imperial => max_range * 0.9144, // yards to meters
            UnitSystem::Metric => max_range,
        };
        solver.set_max_range(max_range_m);
        solver.set_time_step(time_step);

        // Downrange-segmented wind overrides the scalar wind when present.
        if !wind_segment_strs.is_empty() {
            if enable_wind_shear {
                return Err(JsValue::from_str(
                    "--wind-segment cannot be combined with --enable-wind-shear \
                     (downrange segments + altitude shear is not yet a defined model)",
                ));
            }
            let imperial = matches!(units, UnitSystem::Imperial);
            let mut segments = Vec::with_capacity(wind_segment_strs.len());
            for s in &wind_segment_strs {
                // MBA-1368: in compass mode every segment angle is an earth-fixed
                // bearing too; clock forms stay rejected there (shooter-relative by
                // definition). Shooter mode is byte-identical to the plain parser.
                let (mut seg, was_clock) =
                    crate::wind::parse_wind_segment_str_detailed(s, imperial)
                        .map_err(|err| JsValue::from_str(&err))?;
                if wind_ref == crate::wind::WindReference::Compass {
                    if was_clock {
                        return Err(JsValue::from_str(
                            "Error: clock positions are shooter-relative by definition;                              use degrees with --wind-ref compass",
                        ));
                    }
                    let Some(azimuth) = shot_direction else {
                        return Err(JsValue::from_str(
                            "Error: --wind-ref compass requires --shot-direction                              (earth-fixed wind bearings are re-referenced against the                              shot azimuth)",
                        ));
                    };
                    seg.angle_deg = crate::wind::compass_bearing_to_shooter_relative_deg(
                        seg.angle_deg,
                        azimuth,
                    );
                }
                segments.push(seg);
            }
            solver.set_wind_segments(segments);
        }

        // Mover ring (MBA-1325): --target-speed uses the same mph (imperial) / m/s
        // (metric) convention as --wind-speed / `lead --target-speed`. 0 disables the
        // per-point Ring column/field in every output format below (additive).
        let target_speed_mps = match units {
            UnitSystem::Imperial => target_speed * 0.44704, // mph to m/s
            UnitSystem::Metric => target_speed,
        };
        // MBA-1414: the unit reaches only the Ring column here, and that column exists
        // only for a nonzero --target-speed. The browser terminal has no PDF dope card
        // (the native CLI's other consumer of the unit) and no stderr, so this rides the
        // table-only warning block below with the rest of the human-readable text.
        let adjustment_unit_noop_warning: Option<&str> =
            if adjustment_unit_supplied && target_speed <= 0.0 {
                Some(
                    "warning: --adjustment-unit only affects the mover Ring column; \
                     add --target-speed to see it\n",
                )
            } else {
                None
            };
        // Validate --adjustment-unit like handle_lead_command does; only the ring
        // table column consumes it on this command. MBA-1355: smoa/iphy join
        // mil/moa as constant-factor units; clicks needs a resolved elevation click
        // graduation (--elevation-click-value or nothing else — WASM has no --profile),
        // mirroring native's resolve_click_values/reject_clicks_out_of_scope split
        // (trajectory is one of the two commands where clicks actually resolves).
        let adjustment_unit_lower = adjustment_unit.to_lowercase();
        let ring_unit = match adjustment_unit_lower.as_str() {
            "mil" => RingDisplayUnit::Factor(1.0, "mil"),
            "moa" => RingDisplayUnit::Factor(
                crate::moving_target::MOA_PER_UNIT_RATIO / crate::moving_target::MIL_PER_UNIT_RATIO,
                "moa",
            ),
            // SMOA/IPHY are numerically identical (exact inches-per-hundred-yards); only
            // the header/cell text differs, so they get their own labels but share the
            // ratio, matching native's Ring(smoa)/Ring(iphy) treatment.
            "smoa" => RingDisplayUnit::Factor(smoa_per_mil(), "smoa"),
            "iphy" => RingDisplayUnit::Factor(smoa_per_mil(), "iphy"),
            "clicks" => {
                let elev_str = elevation_click_value.ok_or_else(|| {
                    JsValue::from_str(
                        "--adjustment-unit clicks requires a turret elevation graduation: pass \
                         --elevation-click-value <SIZE><UNIT> (e.g. 0.25moa or 0.1mil)",
                    )
                })?;
                let elevation = crate::adjustment::parse_click_value(elev_str)
                    .map_err(|e| JsValue::from_str(&e))?;
                // Windage is validated for CLI-flag parity with native (a typo'd
                // --windage-click-value still errors here, same as native trajectory)
                // but is otherwise inert — the Ring column always uses elevation.
                if let Some(w) = windage_click_value {
                    crate::adjustment::parse_click_value(w).map_err(|e| JsValue::from_str(&e))?;
                }
                RingDisplayUnit::Clicks(elevation)
            }
            _ => {
                return Err(JsValue::from_str(&format!(
                    "Invalid --adjustment-unit '{}' (expected mil, moa, smoa, iphy, or clicks)",
                    adjustment_unit
                )));
            }
        };

        match solver.solve() {
            Ok(mut result) => {
                // MBA-1411: apply the per-call DSF table (if any), IN PLACE, before any
                // output format below reads `result` — mirrors native main.rs's single
                // post-solve `apply_dsf` site (drop-only: velocity/energy/TOF/windage and
                // sampled_points' non-drop fields are untouched; see apply_dsf's doc
                // comment for the invariant). Must run identically ahead of every format,
                // including the Ring column (mover_ring, below), which keys off
                // `result.points`' downrange position/time only — untouched by apply_dsf.
                if let Some(table) = dsf_table.as_ref() {
                    apply_dsf(&mut result, table);
                }
                // MBA-1403: target-plane drops reference for the formatters. None (the
                // default LOS mode) leaves every format byte-identical; validate_for_solve
                // has already rejected target mode at |shooting angle| >= 90 degrees, so
                // the cosine is strictly positive here.
                let target_drops_cos = if drops_reference_target {
                    Some(inputs.shooting_angle.cos())
                } else {
                    None
                };
                let output = match output_format {
                    OutputFormat::Table => self.format_trajectory_table(
                        &result,
                        auto_zero,
                        units,
                        full,
                        inputs.muzzle_height + inputs.sight_height,
                        target_speed_mps,
                        ring_unit,
                        target_drops_cos,
                        windage_cf,
                    ),
                    OutputFormat::Json => self.format_trajectory_json(
                        &result,
                        units,
                        inputs.muzzle_height + inputs.sight_height,
                        target_speed_mps,
                        solved_zero_angle_deg,
                        with_drag_coefficient,
                        target_drops_cos,
                        windage_cf,
                    ),
                    // MBA-1433: two CSV forms, as native has — the point table by default
                    // (unchanged), the `metric,value,unit` summary under --csv-summary.
                    OutputFormat::Csv if csv_summary => {
                        Self::format_trajectory_csv_summary(&result, units, solved_zero_angle_deg)
                    }
                    OutputFormat::Csv => self.format_trajectory_csv(
                        &result,
                        units,
                        full,
                        inputs.muzzle_height + inputs.sight_height,
                        target_speed_mps,
                        target_drops_cos,
                        windage_cf,
                    ),
                };
                // JSON/CSV must stay pure machine output: the human-readable "Rifle zeroed
                // at ..." banner is table-only, exactly like the bc-segments and warning
                // blocks below. Prepending it to a JSON/CSV payload makes it unparseable.
                let mut combined = if matches!(output_format, OutputFormat::Table) {
                    // MBA-1386/MBA-1356: table-only, like every human-readable block here —
                    // neither warning may contaminate JSON/CSV payloads.
                    format!(
                        "{}{}{}{}{}{}{}{}",
                        cd_scale_warning.as_deref().unwrap_or(""),
                        bc_reference_warning.as_deref().unwrap_or(""),
                        density_altitude_warning.as_deref().unwrap_or(""),
                        // MBA-1418: native prints this to stderr; the browser terminal has none,
                        // so it rides the same table-only block as its siblings.
                        zero_pressure_type_notice.unwrap_or(""),
                        bc5d_coercion_warning.as_deref().unwrap_or(""),
                        adjustment_unit_noop_warning.unwrap_or(""),
                        zero_info,
                        output
                    )
                } else {
                    output
                };
                // Human-readable append only for the table view: tacking text after a
                // JSON/CSV payload would break any downstream parser of those formats.
                if print_bc_segments && matches!(output_format, OutputFormat::Table) {
                    combined.push_str(&self.format_bc_segments_report(&inputs, units));
                }
                // MBA-1411: table-output-only note that a per-call DSF table was applied —
                // the Drop column above already reflects it (`apply_dsf`, called before
                // this match arm's formatting, corrects every output format identically).
                // JSON/CSV get no equivalent text or top-level field (purity rule, matching
                // native main.rs's saved-profile note).
                if let Some(table) = dsf_table.as_ref() {
                    if matches!(output_format, OutputFormat::Table) {
                        combined.push_str(&format!(
                            "\nDSF table active ({})\n",
                            dsf_table_summary(table.points())
                        ));
                    }
                }
                // MBA-1395: equivalent horizontal range (BDC shoot-to) for inclined
                // shots — table-only, pipe-free, and appended AFTER the row block, so it
                // sits outside the ballistics.rs terminal chart parser's row format
                // (the parser stops at "Max Range:"). Emitted only when a look angle is
                // set AND --auto-zero solved a zero; ill-defined cases (target inside
                // the zero range, non-positive correction) print nothing, and flat
                // shots are byte-identical.
                if inputs.shooting_angle != 0.0 && matches!(output_format, OutputFormat::Table) {
                    if let Some(zero_distance) = auto_zero {
                        let zero_distance_m = match units {
                            UnitSystem::Imperial => zero_distance * 0.9144,
                            UnitSystem::Metric => zero_distance,
                        };
                        if let Some(ehr_m) =
                            solver.equivalent_horizontal_range(result.max_range, zero_distance_m)
                        {
                            let (ehr_display, ehr_unit) = match units {
                                UnitSystem::Imperial => (ehr_m / 0.9144, "yd"),
                                UnitSystem::Metric => (ehr_m, "m"),
                            };
                            combined.push_str(&format!(
                                "\nEquivalent horizontal range: {:.0} {} (shoot-to for BDC)\n",
                                ehr_display, ehr_unit
                            ));
                        }
                    }
                }
                // MBA-1337 p3: table-only chart append, mirroring the native CLI's
                // --plot block (72x12 cells; drop then lateral drift vs range). JSON
                // and CSV stay pure machine output.
                if let Some(style) = plot {
                    if matches!(output_format, OutputFormat::Table) && !result.points.is_empty() {
                        let (dist_div, range_unit) = match units {
                            UnitSystem::Imperial => (0.9144, "yd"),
                            UnitSystem::Metric => (1.0, "m"),
                        };
                        let drop_label = format!("drop ({})", range_unit);
                        let drop_points: Vec<(f64, f64)> = result
                            .points
                            .iter()
                            .map(|p| (p.position.x / dist_div, p.position.y / dist_div))
                            .collect();
                        combined.push_str("\nDrop vs Range:\n");
                        combined.push_str(&crate::terminal_plot::render_chart(
                            &[(drop_label.as_str(), drop_points.as_slice())],
                            72,
                            12,
                            style,
                        ));
                        combined.push('\n');

                        let drift_label = format!("drift ({})", range_unit);
                        let drift_points: Vec<(f64, f64)> = result
                            .points
                            .iter()
                            .map(|p| (p.position.x / dist_div, p.position.z / dist_div))
                            .collect();
                        combined.push_str("\nLateral Drift vs Range:\n");
                        combined.push_str(&crate::terminal_plot::render_chart(
                            &[(drift_label.as_str(), drift_points.as_slice())],
                            72,
                            12,
                            style,
                        ));
                        combined.push('\n');

                        // Velocity and energy panels (MBA-1394): same treatment,
                        // reusing result.points' raw per-step velocity_magnitude/
                        // kinetic_energy (McCoy SI values). Conversion factors match
                        // this handler's own CSV/JSON velocity/energy columns
                        // (3.28084 m/s->fps, 0.737562149 J->ft-lb; e.g. the
                        // "energy_ftlb" JSON field and the CSV "Energy(ft-lb)"
                        // column elsewhere in this file) so labels always follow
                        // --units the same way the rest of this command does.
                        let (vel_mul, vel_unit_label, energy_mul, energy_unit_label) = match units {
                            UnitSystem::Imperial => (3.28084, "fps", 0.737562149, "ft-lb"),
                            UnitSystem::Metric => (1.0, "m/s", 1.0, "J"),
                        };

                        let velocity_label = format!("velocity ({})", vel_unit_label);
                        let velocity_points: Vec<(f64, f64)> = result
                            .points
                            .iter()
                            .map(|p| (p.position.x / dist_div, p.velocity_magnitude * vel_mul))
                            .collect();
                        combined.push_str("\nVelocity vs Range:\n");
                        combined.push_str(&crate::terminal_plot::render_chart(
                            &[(velocity_label.as_str(), velocity_points.as_slice())],
                            72,
                            12,
                            style,
                        ));
                        combined.push('\n');

                        let energy_label = format!("energy ({})", energy_unit_label);
                        let energy_points: Vec<(f64, f64)> = result
                            .points
                            .iter()
                            .map(|p| (p.position.x / dist_div, p.kinetic_energy * energy_mul))
                            .collect();
                        combined.push_str("\nEnergy vs Range:\n");
                        combined.push_str(&crate::terminal_plot::render_chart(
                            &[(energy_label.as_str(), energy_points.as_slice())],
                            72,
                            12,
                            style,
                        ));
                        combined.push('\n');
                    }
                }
                if let Some(warning) = &muzzle_height_warning {
                    if matches!(output_format, OutputFormat::Table) {
                        combined = format!("{}{}", warning, combined);
                    }
                }
                Ok(combined)
            }
            Err(e) => {
                let mut combined = format!("Error: {}", e);
                // MBA-1386 (0.28.1 sweep): the Ok arm above prepends bc5d_coercion_warning
                // (table-only, like every other human-readable block here); the Err arm was
                // dropping it entirely instead of carrying it the same way.
                if let Some(warning) = &bc5d_coercion_warning {
                    if matches!(output_format, OutputFormat::Table) {
                        combined = format!("{}{}", warning, combined);
                    }
                }
                if let Some(warning) = &muzzle_height_warning {
                    combined = format!("{}{}", warning, combined);
                }
                Ok(combined)
            }
        }
    }

    /// Bero-feedback (0.23.0) `--print-bc-segments`: report the velocity-keyed BC ladder
    /// actually applied to this run (manual `--bc-segment` entries or a BC5D-synthesized
    /// schedule), or a one-line note when none are active. `BCSegmentData` velocities are
    /// always stored in fps (see the parse-time conversion in `handle_trajectory_command`),
    /// so this converts to the command's display units and derives a standard-atmosphere
    /// Mach span alongside them.
    fn format_bc_segments_report(
        &self,
        inputs: &InternalBallisticInputs,
        units: UnitSystem,
    ) -> String {
        match inputs.bc_segments_data.as_ref().filter(|s| !s.is_empty()) {
            Some(segments) => {
                let (fps_to_display, unit_label) = match units {
                    UnitSystem::Imperial => (1.0, "fps"),
                    UnitSystem::Metric => (0.3048, "m/s"),
                };
                let mut block = String::from("\nBC Segments (active)\n=====================\n");
                for seg in segments {
                    let mach_min = seg.velocity_min * 0.3048 / crate::constants::SPEED_OF_SOUND_MPS;
                    let mach_max = seg.velocity_max * 0.3048 / crate::constants::SPEED_OF_SOUND_MPS;
                    block.push_str(&format!(
                        "  {:.1}-{:.1} {} (Mach {:.2}-{:.2}): BC {:.5}\n",
                        seg.velocity_min * fps_to_display,
                        seg.velocity_max * fps_to_display,
                        unit_label,
                        mach_min,
                        mach_max,
                        seg.bc_value,
                    ));
                }
                block
            }
            None => "\nNo BC segments active for this run.\n".to_string(),
        }
    }

    #[cfg(feature = "wasm-zero")]
    fn handle_zero_command(&self, args: &[&str], units: UnitSystem) -> Result<String, JsValue> {
        // Default values
        let (default_velocity, default_mass, default_diameter) = match units {
            UnitSystem::Imperial => (2700.0, 168.0, 0.308),
            UnitSystem::Metric => (823.0, 10.9, 7.82),
        };

        let mut velocity = default_velocity;
        let mut bc = 0.475;
        let mut bc_reference_standard = BcReferenceStandard::Icao;
        let mut mass = default_mass;
        let mut diameter = default_diameter;
        let mut target_distance = if units == UnitSystem::Imperial {
            100.0
        } else {
            100.0
        };
        let mut sight_height = if units == UnitSystem::Imperial {
            2.0
        } else {
            50.0
        };
        // Heights above GROUND (--muzzle-height / --target-height) do NOT change the zero ANGLE —
        // for a same-elevation target they cancel — so they are intentionally not parsed here
        // (silently ignored by the catch-all arm below). The SIGHT height IS honored: the zero
        // targets the line-of-sight height at the zero distance (see the calculate_zero call).
        let mut drag_model = "G1";
        // MBA-1356: whole-curve drag scale for a custom drag table. None until parsed;
        // resolved against self.drag_table once the arg-parse loop is done.
        let mut cd_scale: Option<f64> = None;
        // MBA-1358: elevation tracking CF — the zero banners' MOA/mrad are dial-unit
        // outputs and are divided by it (/1.0 exact, byte-identical without the flag).
        let mut elevation_cf: f64 = 1.0;
        // MBA-1402: inverse mode — solve the zero RANGE a stored bore angle (degrees)
        // produces, instead of the angle a target distance produces. Mutually exclusive
        // with an explicit --target-distance (checked after parsing, once we know whether
        // --target-distance was actually given rather than left at its default).
        let mut from_angle: Option<f64> = None;
        let mut target_distance_explicit = false;
        // MBA-1426 items 3+4: the terminal's zero solved BOTH its branches against
        // AtmosphericConditions::default(), silently ignoring nothing — it REJECTED these
        // flags as unknown — while native zero has carried --temperature/--pressure/
        // --pressure-type/--humidity/--altitude since MBA-1397 and --density-altitude since
        // MBA-1422. Parsed as Option so a no-flag run leaves the default objects untouched
        // (byte-identical by construction, the same guarantee lead's env flags documented).
        let mut temperature: Option<f64> = None;
        let mut pressure: Option<f64> = None;
        let mut pressure_type: Option<PressureReferenceMode> = None;
        let mut humidity: Option<f64> = None;
        let mut altitude: Option<f64> = None;
        let mut density_altitude: Option<f64> = None;

        // Parse arguments
        let mut i = 0;
        while i < args.len() {
            match args[i] {
                "-v" | "--velocity" => {
                    if i + 1 < args.len() {
                        velocity = args[i + 1]
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid velocity"))?;
                        i += 1;
                    }
                }
                "-b" | "--bc" => {
                    if i + 1 < args.len() {
                        bc = args[i + 1]
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid BC"))?;
                        i += 1;
                    }
                }
                "--bc-reference" => {
                    if i + 1 < args.len() {
                        bc_reference_standard = parse_bc_reference_arg(args[i + 1])?;
                        i += 1;
                    }
                }
                "-m" | "--mass" => {
                    if i + 1 < args.len() {
                        mass = args[i + 1]
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid mass"))?;
                        i += 1;
                    }
                }
                "-d" | "--diameter" => {
                    if i + 1 < args.len() {
                        diameter = args[i + 1]
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid diameter"))?;
                        i += 1;
                    }
                }
                "--target-distance" => {
                    if i + 1 < args.len() {
                        target_distance = args[i + 1]
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid target distance"))?;
                        target_distance_explicit = true;
                        i += 1;
                    }
                }
                "--sight-height" => {
                    if i + 1 < args.len() {
                        sight_height = args[i + 1]
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid sight height"))?;
                        i += 1;
                    }
                }
                // MBA-1402: inverse mode — a stored bore angle in DEGREES, in place of
                // --target-distance.
                "--from-angle" => {
                    if i + 1 < args.len() {
                        from_angle = Some(
                            args[i + 1]
                                .parse()
                                .map_err(|_| JsValue::from_str("Invalid from-angle"))?,
                        );
                        i += 1;
                    }
                }
                "--drag-model" => {
                    if i + 1 < args.len() {
                        drag_model = args[i + 1];
                        i += 1;
                    }
                }
                "--cd-scale" => {
                    if i + 1 < args.len() {
                        cd_scale = Some(
                            args[i + 1]
                                .parse()
                                .map_err(|_| JsValue::from_str("Invalid cd-scale"))?,
                        );
                        i += 1;
                    }
                }
                // MBA-1358: elevation tracking CF for the dial-unit banner values (new
                // arm — require_value hardening per MBA-1343, unlike the legacy arms).
                "--elevation-cf" => {
                    elevation_cf = require_value(args, i)?
                        .parse()
                        .map_err(|_| JsValue::from_str("Invalid elevation CF"))?;
                    if !crate::adjustment::tracking_cf_in_range(elevation_cf) {
                        return Err(JsValue::from_str(
                            "--elevation-cf must be a tracking correction factor strictly \
                             between 0.5 and 1.5",
                        ));
                    }
                    i += 1;
                }
                // --units/-u (+ its value) is consumed globally in run_command, which
                // pre-scans it to set the unit system before dispatch. Skip it here so
                // it isn't rejected as an unknown flag (this is what blocked metric input).
                "--units" | "-u" => {
                    i += 1;
                }
                "--temperature" => {
                    if i + 1 < args.len() {
                        temperature = Some(
                            args[i + 1]
                                .parse()
                                .map_err(|_| JsValue::from_str("Invalid temperature"))?,
                        );
                        i += 1;
                    }
                }
                "--pressure" => {
                    if i + 1 < args.len() {
                        pressure = Some(
                            args[i + 1]
                                .parse()
                                .map_err(|_| JsValue::from_str("Invalid pressure"))?,
                        );
                        i += 1;
                    }
                }
                "--pressure-type" => {
                    if i + 1 < args.len() {
                        pressure_type = Some(parse_pressure_type_arg(args[i + 1])?);
                        i += 1;
                    }
                }
                "--humidity" => {
                    if i + 1 < args.len() {
                        humidity = Some(
                            args[i + 1]
                                .parse()
                                .map_err(|_| JsValue::from_str("Invalid humidity"))?,
                        );
                        i += 1;
                    }
                }
                "--altitude" => {
                    if i + 1 < args.len() {
                        altitude = Some(
                            args[i + 1]
                                .parse()
                                .map_err(|_| JsValue::from_str("Invalid altitude"))?,
                        );
                        i += 1;
                    }
                }
                "--density-altitude" => {
                    if i + 1 < args.len() {
                        density_altitude = Some(
                            args[i + 1]
                                .parse()
                                .map_err(|_| JsValue::from_str("Invalid density-altitude"))?,
                        );
                        i += 1;
                    }
                }
                // Reject unrecognized flags instead of silently ignoring them, so a
                // typo or a flag that isn't wired into this WASM surface is caught
                // immediately rather than looking like a no-op. (The native CLI's clap
                // parser already does this; the hand-rolled WASM parser did not.)
                other if other.starts_with('-') => {
                    return Err(JsValue::from_str(&format!("Unknown flag: {}", other)));
                }
                _ => {}
            }
            i += 1;
        }

        // Build inputs
        let mut inputs = InternalBallisticInputs::default();

        // Assemble the zero-day atmosphere (MBA-1426 items 3+4). Same conversion and
        // dual-write (condition object + inputs fields) pattern as handle_lead_command.
        let mut atmosphere = AtmosphericConditions::default();
        let mut zero_atmo_notice = String::new();
        if let Some(t) = temperature {
            let t_c = match units {
                UnitSystem::Imperial => (t - 32.0) * 5.0 / 9.0,
                UnitSystem::Metric => t,
            };
            atmosphere.temperature = t_c;
            inputs.temperature = t_c;
        }
        if let Some(p) = pressure {
            let p_hpa = match units {
                UnitSystem::Imperial => p * 33.863886666667, // inHg to hPa
                UnitSystem::Metric => p,
            };
            // The RAW declared pressure is stored; a declared QNH is resolved at the solve
            // sites below via resolve_station_conditions_with_pressure_mode + the
            // *_with_resolved_conditions solvers — NOT pre-reduced here. Review finding: a
            // pre-reduced QNH that lands inside resolve_station_pressure's 1013.25±0.5 hPa
            // legacy-sentinel window would be silently re-derived from altitude by the base
            // solvers, discarding the user's pressure (an ordinary winter high-pressure QNH
            // at a few hundred meters reduces into exactly that window). Native zero routes
            // through the mode-aware resolver unconditionally; this now mirrors it.
            atmosphere.pressure = p_hpa;
            inputs.pressure = p_hpa;
        }
        if let Some(h) = humidity {
            atmosphere.humidity = h; // percent
            inputs.humidity = (h / 100.0).clamp(0.0, 1.0); // fraction
        }
        if let Some(alt) = altitude {
            let a_m = match units {
                UnitSystem::Imperial => alt * 0.3048,
                UnitSystem::Metric => alt,
            };
            atmosphere.altitude = a_m;
            inputs.altitude = a_m;
        }
        // Whether the solves below must run through the mode-aware resolver (Qnh declared
        // with a pressure, and not superseded by --density-altitude). Absolute keeps the
        // base solvers so their legacy-sentinel behavior stays bit-identical to native's
        // Absolute path. A DA-resolved pressure keeps the base path too — native zero does
        // the same, and a DA value recaptured by the ±0.5 hPa sentinel is ISA-adjacent by
        // construction (≤0.05% density), unlike a discarded QNH (~1%).
        let qnh_declared = pressure.is_some()
            && density_altitude.is_none()
            && matches!(pressure_type, Some(PressureReferenceMode::Qnh));

        // --density-altitude supersedes --altitude and --pressure/--pressure-type entirely
        // (MBA-1422 precedence); an explicit --temperature still wins. Notices ride the
        // output text — this surface has no stderr (MBA-1414 convention).
        if let Some(da) = density_altitude {
            if pressure.is_some() || pressure_type.is_some() {
                zero_atmo_notice.push_str(
                    "note: --density-altitude supersedes --pressure/--pressure-type (station pressure is derived from density altitude instead)\n\n",
                );
            }
            let da_m = match units {
                UnitSystem::Imperial => da * 0.3048,
                UnitSystem::Metric => da,
            };
            let explicit_temp_c = temperature.map(|t| match units {
                UnitSystem::Imperial => (t - 32.0) * 5.0 / 9.0,
                UnitSystem::Metric => t,
            });
            let (da_altitude_m, da_temp_c, da_pressure_hpa) =
                crate::atmosphere::resolve_atmosphere_for_density_altitude(da_m, explicit_temp_c);
            atmosphere.temperature = da_temp_c;
            inputs.temperature = da_temp_c;
            atmosphere.pressure = da_pressure_hpa;
            inputs.pressure = da_pressure_hpa;
            atmosphere.altitude = da_altitude_m;
            inputs.altitude = da_altitude_m;
        }

        // Convert units
        match units {
            UnitSystem::Imperial => {
                inputs.muzzle_velocity = velocity * 0.3048;
                inputs.bullet_mass = mass * crate::constants::GRAINS_TO_KG;
                inputs.bullet_diameter = diameter * 0.0254;
                inputs.sight_height = sight_height * 0.0254;
            }
            UnitSystem::Metric => {
                inputs.muzzle_velocity = velocity;
                inputs.bullet_mass = mass * 0.001;
                inputs.bullet_diameter = diameter * 0.001;
                inputs.sight_height = sight_height * 0.001;
            }
        }
        // MBA-1135: mass-based length estimate (mirrors CLI/FFI); replaces the mass-blind
        // 4.5-caliber heuristic. WASM otherwise left it at the struct default.
        inputs.bullet_length =
            crate::stability::estimate_bullet_length_m(inputs.bullet_diameter, inputs.bullet_mass);
        if inputs.bullet_length <= 0.0 {
            inputs.bullet_length = inputs.bullet_diameter * 4.5;
        }

        inputs.bc_value = bc;
        inputs.bc_reference_standard = bc_reference_standard;
        let drag_model_parsed = DragModel::from_str(drag_model)
            .ok_or_else(|| JsValue::from_str("Invalid drag model"))?;
        inputs.bc_type = drag_model_parsed;
        // Custom drag table (MBA-1328): see handle_trajectory_command for the rationale —
        // applied unconditionally, no gate flag, mirrors native --drag-table on `zero`.
        if let Some(table) = self.drag_table.borrow().as_ref() {
            inputs.custom_drag_table = Some(table.clone());
        }
        // MBA-1356: --cd-scale requires a loaded drag table, mirroring the native CLI's
        // --cd-scale/--drag-table pairing requirement. Validate before any solve.
        if let Some(scale) = cd_scale {
            if self.drag_table.borrow().is_none() {
                return Err(JsValue::from_str(CD_SCALE_REQUIRES_DRAG_TABLE));
            }
            inputs.cd_scale = scale;
        }
        let cd_scale_warning = cd_scale.and_then(cd_scale_range_warning);
        // MBA-1365: table-only, same rationale as handle_trajectory_command (no visible
        // stderr in the browser terminal).
        let bc_reference_warning = inputs
            .bc_reference_standard_inert_warning()
            .map(|w| format!("{w}\n\n"));

        // MBA-1402: --from-angle conflicts with an explicitly-given --target-distance —
        // mirrors the native CLI's `conflicts_with`/`required_unless_present` pair.
        if from_angle.is_some() && target_distance_explicit {
            return Err(JsValue::from_str(
                "--from-angle conflicts with --target-distance; give exactly one",
            ));
        }

        // MBA-951: target the line-of-sight height at the zero distance (= sight_height), matching
        // the CLI convention in every zero call. Previously 0.0, which solved a BORE-line zero and
        // ignored sight height entirely (off by the sight-height angle — ~2 MOA at 100 yd).
        let los_height = inputs.sight_height;

        let result = if let Some(angle_deg) = from_angle {
            // MBA-1402, corrected by the Tier 2 review (C2): inverse mode — given a
            // previously solved/stored bore angle (degrees), solve the zero RANGE(S) it
            // produces. NOT the exact inverse of the --target-distance mode below: a bore
            // angle generally implies TWO zero distances (the classic 25/300-yard
            // battle-zero relationship), so both crossings are reported rather than one
            // being silently chosen — see calculate_zero_range_from_angle_with_conditions's
            // doc comment.
            let angle_rad = angle_deg * std::f64::consts::PI / 180.0;
            let from_angle_result = if qnh_declared {
                let (resolved_temp_c, resolved_pressure_hpa) =
                    resolve_station_conditions_with_pressure_mode(
                        atmosphere.temperature,
                        atmosphere.pressure,
                        atmosphere.altitude,
                        PressureReferenceMode::Qnh,
                    );
                let mut resolved_atmosphere = atmosphere.clone();
                resolved_atmosphere.temperature = resolved_temp_c;
                resolved_atmosphere.pressure = resolved_pressure_hpa;
                calculate_zero_range_from_angle_with_resolved_conditions(
                    inputs,
                    angle_rad,
                    los_height,
                    WindConditions::default(),
                    resolved_atmosphere,
                )
            } else {
                calculate_zero_range_from_angle_with_conditions(
                    inputs,
                    angle_rad,
                    los_height,
                    WindConditions::default(),
                    // MBA-1426: was AtmosphericConditions::default() — typed conditions never
                    // reached this solve at all.
                    atmosphere.clone(),
                )
            };
            match from_angle_result {
                Ok(crossings) => {
                    let to_display = |m: f64| match units {
                        UnitSystem::Imperial => m / 0.9144,
                        UnitSystem::Metric => m,
                    };
                    let dist_label = if units == UnitSystem::Imperial {
                        "yards"
                    } else {
                        "meters"
                    };
                    // MBA-1358: dial-unit banner values are divided by the elevation
                    // CF via the shared, host-tested helper (/1.0 exact).
                    let (moa_adjustment, mrad_adjustment) =
                        crate::adjustment::zero_banner_dial_values(
                            angle_deg,
                            angle_rad,
                            elevation_cf,
                        );
                    let near_line = match crossings.near_m {
                        Some(m) => format!(
                            "Near Zero (ascending): {:.1} {}\n",
                            to_display(m),
                            dist_label
                        ),
                        None => "Near Zero: not within the solved range\n".to_string(),
                    };
                    let far_line = match crossings.far_m {
                        Some(m) => format!(
                            "Far Zero (descending): {:.1} {}\n",
                            to_display(m),
                            dist_label
                        ),
                        None => "Far Zero: not within the solved range\n".to_string(),
                    };
                    // MBA-1426 item 5 / MBA-1419: name which root the single zero-range value
                    // refers to, exactly as native's JSON/CSV do — far when present, else near.
                    let primary_line = if crossings.far_m.is_some() {
                        "Primary Crossing: far (the conventional zeroed-at distance)\n"
                    } else {
                        "Primary Crossing: near (the far root lies beyond the solved range)\n"
                    };

                    format!(
                        "{zero_atmo_notice}Zero Range From Angle Results\n\
                         ==============================\n\
                         Input Zero Angle: {:.4}°\n\
                         MOA Adjustment: {:.2} MOA up\n\
                         Mrad Adjustment: {:.2} mrad up\n\
                         {}\
                         {}\
                         {}\
                         Sight Height: {} {}\n",
                        angle_deg,
                        moa_adjustment,
                        mrad_adjustment,
                        near_line,
                        far_line,
                        primary_line,
                        sight_height,
                        if units == UnitSystem::Imperial {
                            "inches"
                        } else {
                            "mm"
                        }
                    )
                }
                Err(e) => format!("Error calculating zero range: {}", e),
            }
        } else {
            let target_distance_m = match units {
                UnitSystem::Imperial => target_distance * 0.9144,
                UnitSystem::Metric => target_distance,
            };
            let zero_result = if qnh_declared {
                let (resolved_temp_c, resolved_pressure_hpa) =
                    resolve_station_conditions_with_pressure_mode(
                        atmosphere.temperature,
                        atmosphere.pressure,
                        atmosphere.altitude,
                        PressureReferenceMode::Qnh,
                    );
                let mut resolved_atmosphere = atmosphere.clone();
                resolved_atmosphere.temperature = resolved_temp_c;
                resolved_atmosphere.pressure = resolved_pressure_hpa;
                calculate_zero_angle_with_resolved_conditions(
                    inputs,
                    target_distance_m,
                    los_height,
                    WindConditions::default(),
                    resolved_atmosphere,
                )
            } else {
                calculate_zero_angle_with_conditions(
                    inputs,
                    target_distance_m,
                    los_height,
                    WindConditions::default(),
                    // MBA-1426: was AtmosphericConditions::default() — typed conditions never
                    // reached this solve at all.
                    atmosphere.clone(),
                )
            };
            match zero_result {
                Ok(zero_angle) => {
                    let zero_degrees = zero_angle * 180.0 / std::f64::consts::PI;
                    // MBA-1358: dial-unit banner values are divided by the elevation
                    // CF via the shared, host-tested helper (/1.0 exact). The degrees
                    // echo is a bore angle, not a dial value: unscaled.
                    let (moa_adjustment, mrad_adjustment) =
                        crate::adjustment::zero_banner_dial_values(
                            zero_degrees,
                            zero_angle,
                            elevation_cf,
                        );

                    format!(
                        "{zero_atmo_notice}Zero Calculation Results\n\
                         ========================\n\
                         Target Distance: {} {}\n\
                         Zero Angle: {:.4}°\n\
                         MOA Adjustment: {:.2} MOA up\n\
                         Mrad Adjustment: {:.2} mrad up\n\
                         Sight Height: {} {}\n",
                        target_distance,
                        if units == UnitSystem::Imperial {
                            "yards"
                        } else {
                            "meters"
                        },
                        zero_degrees,
                        moa_adjustment,
                        mrad_adjustment,
                        sight_height,
                        if units == UnitSystem::Imperial {
                            "inches"
                        } else {
                            "mm"
                        }
                    )
                }
                Err(e) => format!("Error calculating zero: {}", e),
            }
        };
        // MBA-1356: table-only prepend, same pattern as the trajectory/monte-carlo handlers —
        // this command has no JSON/CSV output mode to protect from contamination.
        Ok(format!(
            "{}{}{}",
            cd_scale_warning.as_deref().unwrap_or(""),
            bc_reference_warning.as_deref().unwrap_or(""),
            result
        ))
    }

    #[cfg(feature = "wasm-lead")]
    fn handle_lead_command(&self, args: &[&str], units: UnitSystem) -> Result<String, JsValue> {
        // Default values
        let (default_velocity, default_mass, default_diameter) = match units {
            UnitSystem::Imperial => (2700.0, 168.0, 0.308),
            UnitSystem::Metric => (823.0, 10.9, 7.82),
        };

        let mut velocity = default_velocity;
        let mut bc = 0.475;
        let mut mass = default_mass;
        let mut diameter = default_diameter;
        let mut drag_model = "G1";
        let mut sight_height = if units == UnitSystem::Imperial {
            2.0
        } else {
            50.0
        };
        let mut target_speed: Option<f64> = None;
        let mut target_angle = 90.0;
        let mut range = 500.0;
        let mut adjustment_unit = "mil";
        // MBA-1410: lead's single angular column is windage-like (a horizontal hold), so
        // `--adjustment-unit clicks` resolves through this graduation, mirroring native
        // handle_lead's `--windage-click-value` (WASM has no --profile, so there is no
        // elevation_click fallback here).
        let mut windage_click_value: Option<&str> = None;
        // MBA-1358: windage tracking CF (mover lead is a dialed quantity — dial-unit
        // outputs are divided by it; the linear lead never is). Mirrors native
        // `lead --windage-cf`; lead is a single windage-axis command, so there is no
        // --elevation-cf here (it would be inert — the MBA-1414 class).
        let mut windage_cf: f64 = 1.0;
        let mut lead_output = "table";
        // MBA-1411 (carried from the MBA-1356 review's "WASM lead untrued-curve gap"):
        // this command already applies a loaded custom drag table unconditionally (see
        // the self.drag_table block below) but, unlike trajectory/zero/monte-carlo, never
        // wired up --cd-scale to go with it — a table trued via `trajectory --cd-scale`
        // silently reverted to its untrued curve here. None until parsed; resolved against
        // self.drag_table once the arg-parse loop is done, exactly like handle_trajectory_command.
        let mut cd_scale: Option<f64> = None;
        // Powder temperature plumbing (MBA-1325), identical defaults/parsing to
        // handle_trajectory_command so a curve/sensitivity correction resolves the
        // same muzzle velocity from either command.
        let mut use_powder_sensitivity = false;
        let mut powder_temp_sensitivity = if units == UnitSystem::Imperial {
            1.0
        } else {
            0.3048 / (5.0 / 9.0)
        };
        let mut powder_temp = if units == UnitSystem::Imperial {
            crate::constants::DEFAULT_POWDER_REFERENCE_TEMP_F
        } else {
            crate::constants::DEFAULT_POWDER_REFERENCE_TEMP_C
        };
        let mut powder_temp_curve_str: Option<String> = None;
        // Track whether --powder-temp was explicitly given (mirrors handle_trajectory_command):
        // when a curve is present it becomes the powder temperature the curve is interpolated
        // at (decoupled from the air temperature); when not given, the curve falls back to it.
        let mut powder_temp_provided = false;
        // Environmental conditions (MBA-1325 env-flags addendum): native-lead parity for
        // --temperature/--pressure/--humidity/--altitude/--wind-speed/--wind-direction.
        // Parsed as Option — an ABSENT flag leaves the pre-existing default objects
        // (WindConditions::default(), AtmosphericConditions::default(), BallisticInputs::
        // default()'s env fields) completely untouched, so a no-env-flag run stays
        // byte-identical to the pre-flag build by construction. (A display-unit default
        // like trajectory's 29.92 inHg would NOT: 29.92 x 33.863886666667 = 1013.2075 hPa,
        // whereas this command has always solved at AtmosphericConditions::default()'s
        // 1013.25.) Explicit values convert exactly like handle_trajectory_command's.
        let mut temperature: Option<f64> = None;
        let mut pressure: Option<f64> = None;
        let mut humidity: Option<f64> = None;
        let mut altitude: Option<f64> = None;
        // MBA-1426 item 3: native lead has honored --pressure-type since MBA-1416; the
        // terminal silently lacked it.
        let mut pressure_type: Option<PressureReferenceMode> = None;
        let mut wind_speed: Option<f64> = None;
        let mut wind_direction: Option<f64> = None;

        // Parse arguments
        let mut i = 0;
        while i < args.len() {
            match args[i] {
                "-v" | "--velocity" => {
                    if i + 1 < args.len() {
                        velocity = args[i + 1]
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid velocity"))?;
                        i += 1;
                    }
                }
                "-b" | "--bc" => {
                    if i + 1 < args.len() {
                        bc = args[i + 1]
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid BC"))?;
                        i += 1;
                    }
                }
                "-m" | "--mass" => {
                    if i + 1 < args.len() {
                        mass = args[i + 1]
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid mass"))?;
                        i += 1;
                    }
                }
                "-d" | "--diameter" => {
                    if i + 1 < args.len() {
                        diameter = args[i + 1]
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid diameter"))?;
                        i += 1;
                    }
                }
                "--drag-model" => {
                    if i + 1 < args.len() {
                        drag_model = args[i + 1];
                        i += 1;
                    }
                }
                "--cd-scale" => {
                    if i + 1 < args.len() {
                        cd_scale = Some(
                            args[i + 1]
                                .parse()
                                .map_err(|_| JsValue::from_str("Invalid cd-scale"))?,
                        );
                        i += 1;
                    }
                }
                "--sight-height" => {
                    if i + 1 < args.len() {
                        sight_height = args[i + 1]
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid sight height"))?;
                        i += 1;
                    }
                }
                "--temperature" => {
                    if i + 1 < args.len() {
                        temperature = Some(
                            args[i + 1]
                                .parse()
                                .map_err(|_| JsValue::from_str("Invalid temperature"))?,
                        );
                        i += 1;
                    }
                }
                "--pressure" => {
                    if i + 1 < args.len() {
                        pressure = Some(
                            args[i + 1]
                                .parse()
                                .map_err(|_| JsValue::from_str("Invalid pressure"))?,
                        );
                        i += 1;
                    }
                }
                "--humidity" => {
                    if i + 1 < args.len() {
                        humidity = Some(
                            args[i + 1]
                                .parse()
                                .map_err(|_| JsValue::from_str("Invalid humidity"))?,
                        );
                        i += 1;
                    }
                }
                "--pressure-type" => {
                    if i + 1 < args.len() {
                        pressure_type = Some(parse_pressure_type_arg(args[i + 1])?);
                        i += 1;
                    }
                }
                "--altitude" => {
                    if i + 1 < args.len() {
                        altitude = Some(
                            args[i + 1]
                                .parse()
                                .map_err(|_| JsValue::from_str("Invalid altitude"))?,
                        );
                        i += 1;
                    }
                }
                "--wind-speed" => {
                    if i + 1 < args.len() {
                        wind_speed = Some(
                            args[i + 1]
                                .parse()
                                .map_err(|_| JsValue::from_str("Invalid wind speed"))?,
                        );
                        i += 1;
                    }
                }
                "--wind-direction" => {
                    if i + 1 < args.len() {
                        // MBA-1367: shared degrees+clock helper (same as trajectory's).
                        wind_direction = Some(
                            crate::wind::parse_wind_direction_standalone(args[i + 1])
                                .map_err(|e| JsValue::from_str(&format!("Error: {e}")))?
                                .degrees,
                        );
                        i += 1;
                    }
                }
                "--target-speed" => {
                    if i + 1 < args.len() {
                        let speed: f64 = args[i + 1]
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid target speed"))?;
                        // Same bound native lead enforces via f64_range(0.0, 300.0)
                        // (review fix M1) — reject, never silently clamp.
                        if !(0.0..=300.0).contains(&speed) {
                            return Err(JsValue::from_str(&format!(
                                "--target-speed must be between 0 and 300 (mph/m/s), got {}",
                                speed
                            )));
                        }
                        target_speed = Some(speed);
                        i += 1;
                    }
                }
                "--target-angle" => {
                    if i + 1 < args.len() {
                        target_angle = args[i + 1]
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid target angle"))?;
                        i += 1;
                    }
                }
                "--range" => {
                    if i + 1 < args.len() {
                        range = args[i + 1]
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid range"))?;
                        i += 1;
                    }
                }
                "--use-powder-sensitivity" => use_powder_sensitivity = true,
                "--powder-temp-sensitivity" => {
                    if i + 1 < args.len() {
                        powder_temp_sensitivity = args[i + 1]
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid powder temp sensitivity"))?;
                        i += 1;
                    }
                }
                "--powder-temp" => {
                    if i + 1 < args.len() {
                        powder_temp = args[i + 1]
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid powder temp"))?;
                        powder_temp_provided = true;
                        i += 1;
                    }
                }
                "--powder-temp-curve" => {
                    if i + 1 < args.len() {
                        powder_temp_curve_str = Some(args[i + 1].to_string());
                        i += 1;
                    }
                }
                "--adjustment-unit" => {
                    if i + 1 < args.len() {
                        adjustment_unit = args[i + 1];
                        i += 1;
                    }
                }
                "--windage-click-value" => {
                    if i + 1 < args.len() {
                        windage_click_value = Some(args[i + 1]);
                        i += 1;
                    }
                }
                // MBA-1358: new arm — require_value hardening per MBA-1343, unlike the
                // legacy raw-i+1 arms around it. Same accepted band as native.
                "--windage-cf" => {
                    windage_cf = require_value(args, i)?
                        .parse()
                        .map_err(|_| JsValue::from_str("Invalid windage CF"))?;
                    if !crate::adjustment::tracking_cf_in_range(windage_cf) {
                        return Err(JsValue::from_str(
                            "--windage-cf must be a tracking correction factor strictly \
                             between 0.5 and 1.5",
                        ));
                    }
                    i += 1;
                }
                "-o" | "--output" => {
                    if i + 1 < args.len() {
                        lead_output = args[i + 1];
                        i += 1;
                    }
                }
                // --units/-u (+ its value) is consumed globally in run_command, which
                // pre-scans it to set the unit system before dispatch. Skip it here so
                // it isn't rejected as an unknown flag (this is what blocked metric input).
                "--units" | "-u" => {
                    i += 1;
                }
                // Reject unrecognized flags instead of silently ignoring them, so a
                // typo or a flag that isn't wired into this WASM surface is caught
                // immediately rather than looking like a no-op. (The native CLI's clap
                // parser already does this; the hand-rolled WASM parser did not.)
                other if other.starts_with('-') => {
                    return Err(JsValue::from_str(&format!("Unknown flag: {}", other)));
                }
                _ => {}
            }
            i += 1;
        }

        let target_speed =
            target_speed.ok_or_else(|| JsValue::from_str("--target-speed is required"))?;

        // MBA-1355: smoa/iphy join mil/moa as real display units (mirrors native
        // handle_lead's Smoa|Iphy match arm — sol.lead_mil * smoa_per_mil()). MBA-1410:
        // clicks now resolves too (mirrors native handle_lead's Clicks arm), through
        // --windage-click-value -- lead's single column is windage-like (a horizontal
        // hold), same axis native resolves it against. WASM has no --profile, so there is
        // no elevation_click/profile fallback here, only the explicit flag.
        let adjustment_unit_lower = adjustment_unit.to_lowercase();
        let windage_click: Option<crate::adjustment::ClickValue> = match adjustment_unit_lower
            .as_str()
        {
            "mil" | "moa" | "smoa" | "iphy" => None,
            "clicks" => {
                let w = windage_click_value.ok_or_else(|| {
                    JsValue::from_str(
                        "--adjustment-unit clicks requires a turret click graduation: pass \
                         --windage-click-value <SIZE><UNIT> (e.g. 0.25moa or 0.1mil)",
                    )
                })?;
                Some(crate::adjustment::parse_click_value(w).map_err(|e| JsValue::from_str(&e))?)
            }
            _ => {
                return Err(JsValue::from_str(&format!(
                    "Invalid --adjustment-unit '{}' (expected mil, moa, smoa, iphy, or clicks)",
                    adjustment_unit
                )));
            }
        };

        let lead_output_lower = lead_output.to_lowercase();
        if lead_output_lower != "table" && lead_output_lower != "json" {
            return Err(JsValue::from_str(&format!(
                "Invalid --output '{}' (expected table or json)",
                lead_output
            )));
        }

        // Build inputs (mirrors handle_zero_command's unit conversions)
        let mut inputs = InternalBallisticInputs::default();
        match units {
            UnitSystem::Imperial => {
                inputs.muzzle_velocity = velocity * 0.3048;
                inputs.bullet_mass = mass * crate::constants::GRAINS_TO_KG;
                inputs.bullet_diameter = diameter * 0.0254;
                inputs.sight_height = sight_height * 0.0254;
            }
            UnitSystem::Metric => {
                inputs.muzzle_velocity = velocity;
                inputs.bullet_mass = mass * 0.001;
                inputs.bullet_diameter = diameter * 0.001;
                inputs.sight_height = sight_height * 0.001;
            }
        }
        // MBA-1135: mass-based length estimate (mirrors CLI/FFI); replaces the mass-blind
        // 4.5-caliber heuristic. WASM otherwise left it at the struct default.
        inputs.bullet_length =
            crate::stability::estimate_bullet_length_m(inputs.bullet_diameter, inputs.bullet_mass);
        if inputs.bullet_length <= 0.0 {
            inputs.bullet_length = inputs.bullet_diameter * 4.5;
        }

        inputs.bc_value = bc;
        let drag_model_parsed = DragModel::from_str(drag_model)
            .ok_or_else(|| JsValue::from_str("Invalid drag model"))?;
        inputs.bc_type = drag_model_parsed;
        // Custom drag table (MBA-1328): see handle_trajectory_command for the rationale —
        // applied unconditionally, no gate flag. Native `lead` has no --drag-table flag of
        // its own, but calculate_lead solves through the same TrajectorySolver/BallisticInputs
        // as trajectory/zero, so a loaded table is honored identically here.
        if let Some(table) = self.drag_table.borrow().as_ref() {
            inputs.custom_drag_table = Some(table.clone());
        }
        // MBA-1411: --cd-scale requires a loaded drag table, mirroring the native CLI's
        // --cd-scale/--drag-table pairing requirement and the identical check in
        // handle_trajectory_command/handle_zero_command. Validate before any solve.
        if let Some(scale) = cd_scale {
            if self.drag_table.borrow().is_none() {
                return Err(JsValue::from_str(CD_SCALE_REQUIRES_DRAG_TABLE));
            }
            inputs.cd_scale = scale;
        }
        let cd_scale_warning = cd_scale.and_then(cd_scale_range_warning);

        // Powder temperature (MBA-1325): identical resolution to handle_trajectory_command
        // so a curve/sensitivity muzzle-velocity correction reproduces exactly between the
        // two commands. calculate_lead builds a TrajectorySolver from these inputs, which
        // resolves the correction (see cli_api::TrajectorySolver::new) — no further plumbing
        // needed here.
        inputs.use_powder_sensitivity = use_powder_sensitivity;
        inputs.powder_temp_sensitivity = match units {
            UnitSystem::Imperial => powder_temp_sensitivity * 0.3048 / (5.0 / 9.0),
            UnitSystem::Metric => powder_temp_sensitivity,
        };
        inputs.powder_temp = match units {
            UnitSystem::Imperial => (powder_temp - 32.0) * 5.0 / 9.0,
            UnitSystem::Metric => powder_temp,
        };
        // When --powder-temp was explicitly given, it becomes the POWDER temperature the
        // curve is interpolated at (decoupled from --temperature / air density). When not
        // given, powder_curve_temp_c stays None so the curve falls back to the air temp.
        inputs.powder_curve_temp_c = if powder_temp_provided {
            Some(inputs.powder_temp)
        } else {
            None
        };
        // Parse the optional powder-temperature -> velocity curve into SI points
        // (shared parser — see parse_powder_temp_curve_str).
        if let Some(curve_str) = &powder_temp_curve_str {
            inputs.powder_temp_curve = Some(parse_powder_temp_curve_str(curve_str, units)?);
        }

        // Environmental conditions (MBA-1325 env-flags addendum). Start from the exact
        // objects this command has always solved with and override only what was
        // explicitly flagged — absent flags are structurally byte-identical to the
        // pre-flag build. Each override applies handle_trajectory_command's conversion
        // and mirrors native handle_lead's plumbing: the value lands BOTH on the solver
        // condition object (wind/atmosphere — what the solve consumes) and on the
        // matching BallisticInputs field (native's build_trajectory_components sets
        // both; inputs.humidity takes the documented 0-1 fraction per its field
        // contract, while atmosphere.humidity takes percent — same split as
        // handle_trajectory_command).
        let mut wind = WindConditions::default();
        let mut atmosphere = AtmosphericConditions::default();
        if let Some(t) = temperature {
            let t_c = match units {
                UnitSystem::Imperial => (t - 32.0) * 5.0 / 9.0, // F to C
                UnitSystem::Metric => t,
            };
            atmosphere.temperature = t_c;
            inputs.temperature = t_c;
        }
        if let Some(p) = pressure {
            let p_hpa = match units {
                UnitSystem::Imperial => p * 33.863886666667, // inHg to hPa
                UnitSystem::Metric => p,
            };
            // MBA-1426 item 3: a declared QNH is reduced to station pressure against this
            // command's own --altitude, matching native lead since MBA-1416. The reduction is
            // multiplicative, so it composes cleanly with the unit conversion above.
            let p_hpa = match pressure_type.unwrap_or(PressureReferenceMode::Absolute) {
                PressureReferenceMode::Absolute => p_hpa,
                PressureReferenceMode::Qnh => {
                    let altitude_m = altitude
                        .map(|alt| match units {
                            UnitSystem::Imperial => alt * 0.3048,
                            UnitSystem::Metric => alt,
                        })
                        .unwrap_or(0.0);
                    crate::atmosphere::reduce_qnh_to_station_pressure(p_hpa, altitude_m)
                }
            };
            atmosphere.pressure = p_hpa;
            inputs.pressure = p_hpa;
        }
        if let Some(h) = humidity {
            atmosphere.humidity = h; // percent
            inputs.humidity = (h / 100.0).clamp(0.0, 1.0); // fraction
        }
        if let Some(a) = altitude {
            let a_m = match units {
                UnitSystem::Imperial => a * 0.3048, // feet to meters
                UnitSystem::Metric => a,
            };
            atmosphere.altitude = a_m;
            inputs.altitude = a_m;
        }
        if let Some(w) = wind_speed {
            let w_ms = match units {
                UnitSystem::Imperial => w * 0.44704, // mph to m/s
                UnitSystem::Metric => w,
            };
            wind.speed = w_ms;
            inputs.wind_speed = w_ms;
        }
        if let Some(d) = wind_direction {
            // Degrees, wind-FROM (0=headwind, 90=from right) -> radians, matching
            // handle_trajectory_command and WindConditions' documented convention.
            let d_rad = d.to_radians();
            wind.direction = d_rad;
            inputs.wind_angle = d_rad;
        }

        // --target-speed uses the same mph (imperial) / m/s (metric) convention as
        // --wind-speed in handle_trajectory_command.
        let target_speed_mps = match units {
            UnitSystem::Imperial => target_speed * 0.44704, // mph to m/s
            UnitSystem::Metric => target_speed,
        };
        let range_m = match units {
            UnitSystem::Imperial => range * 0.9144, // yards to meters
            UnitSystem::Metric => range,
        };

        match calculate_lead(
            inputs,
            wind,
            atmosphere,
            target_speed_mps,
            target_angle,
            range_m,
        ) {
            Ok(sol) => {
                let (dist_unit, speed_unit) = match units {
                    UnitSystem::Imperial => ("yd", "mph"),
                    UnitSystem::Metric => ("m", "m/s"),
                };
                let lead_disp = match units {
                    UnitSystem::Imperial => sol.lead_m * 1.09361, // m to yards
                    UnitSystem::Metric => sol.lead_m,
                };
                let intercept_disp = match units {
                    UnitSystem::Imperial => sol.corrected_range_m * 1.09361,
                    UnitSystem::Metric => sol.corrected_range_m,
                };
                // Requested --adjustment-unit is listed first; MIL is always shown second
                // (MBA-1355: SMOA/IPHY join MOA as a requestable primary unit, sharing the
                // native smoa_per_mil() conversion off sol.lead_mil).
                // MBA-1358: mover lead is a dialed quantity — every dial-unit form is
                // divided by the windage CF exactly once here (clicks correct the input
                // angle before quantization); the linear lead_disp above never is.
                // /1.0 is bit-exact, so no-CF output is byte-identical.
                let lead_mil_dial = sol.lead_mil / windage_cf;
                let lead_moa_dial = sol.lead_moa / windage_cf;
                let lead_smoa = sol.lead_mil * smoa_per_mil() / windage_cf;
                // MBA-1410: whole clicks via the resolved windage graduation (validated
                // above -- Some(...) iff adjustment_unit_lower == "clicks").
                let lead_clicks = windage_click
                    .map(|c| crate::adjustment::clicks_for(lead_disp / windage_cf, range, &c));
                let lead_adj_line = match adjustment_unit_lower.as_str() {
                    "moa" => format!("{:.2} MOA / {:.2} MIL", lead_moa_dial, lead_mil_dial),
                    "smoa" => format!("{:.2} SMOA / {:.2} MIL", lead_smoa, lead_mil_dial),
                    "iphy" => format!("{:.2} IPHY / {:.2} MIL", lead_smoa, lead_mil_dial),
                    "clicks" => format!(
                        "{} clicks / {:.2} MIL",
                        lead_clicks.unwrap_or_default(),
                        lead_mil_dial
                    ),
                    _ => format!("{:.2} MIL / {:.2} MOA", lead_mil_dial, lead_moa_dial),
                };

                if lead_output_lower == "json" {
                    let mut payload = serde_json::json!({
                        "target_speed": target_speed,
                        "target_speed_unit": speed_unit,
                        "target_angle_deg": target_angle,
                        "range": range,
                        "distance_unit": dist_unit,
                        "tof_s": sol.time_of_flight_s,
                        "lead": lead_disp,
                        "lead_mil": lead_mil_dial,
                        "lead_moa": lead_moa_dial,
                        "lead_smoa": lead_smoa,
                        "intercept_range": intercept_disp,
                        "iterations": sol.iterations,
                        "adjustment_unit": adjustment_unit_lower,
                    });
                    if let Some(clicks) = lead_clicks {
                        payload["lead_clicks"] = serde_json::json!(clicks);
                    }
                    return Ok(serde_json::to_string_pretty(&payload)
                        .unwrap_or_else(|_| "Error formatting JSON".to_string()));
                }

                // MBA-1411: table-only prepend, same pattern as
                // handle_trajectory_command/handle_zero_command — the JSON branch above
                // already returned, so everything past this point is the table view.
                Ok(format!(
                    "{}Moving-Target Lead\n\
                     ===================\n\
                     Target: {:.1} {} at {:.0}\u{b0} \
                     (0=away, 90=left-to-right, 180=toward, 270=right-to-left;\n\
                     positive lead = hold in direction of travel)\n\n\
                     Range: {:.0} {}\n\
                     Time of Flight: {:.3} s\n\
                     Lead: {:.2} {} ({})\n\
                     Intercept Range: {:.1} {}\n\
                     Iterations: {}\n",
                    cd_scale_warning.as_deref().unwrap_or(""),
                    target_speed,
                    speed_unit,
                    target_angle,
                    range,
                    dist_unit,
                    sol.time_of_flight_s,
                    lead_disp,
                    dist_unit,
                    lead_adj_line,
                    intercept_disp,
                    dist_unit,
                    sol.iterations
                ))
            }
            Err(e) => Err(JsValue::from_str(&format!("Error calculating lead: {}", e))),
        }
    }

    #[cfg(feature = "wasm-monte-carlo")]
    fn handle_monte_carlo_command(
        &self,
        args: &[&str],
        units: UnitSystem,
    ) -> Result<String, JsValue> {
        // Default values
        let (default_velocity, default_mass, default_diameter) = match units {
            UnitSystem::Imperial => (2700.0, 168.0, 0.308),
            UnitSystem::Metric => (823.0, 10.9, 7.82),
        };

        let mut velocity = default_velocity;
        let mut angle = 0.0;
        let mut bc = 0.475;
        let mut bc_reference_standard = BcReferenceStandard::Icao;
        let mut mass = default_mass;
        let mut diameter = default_diameter;
        let mut num_sims = 1000;
        // The two std-dev flags stay unset until parsed: the base (non-WEZ) path keeps
        // this handler's historical defaults (10 fps / 3 m/s velocity std, 2 mph /
        // 0.5 m/s wind std), while the --wez path uses the native CLI's clap defaults
        // (1.0 each, user units) so a WEZ sweep with identical args is byte-identical
        // to the native binary (MBA-1343 Phase C).
        let mut velocity_std: Option<f64> = None;
        let mut angle_std = 0.1;
        let mut bc_std = 0.01;
        let mut wind_speed_std: Option<f64> = None;
        let mut wind_direction_std = 0.0;
        let mut drag_model = "G1";
        // MBA-1356: whole-curve drag scale for a custom drag table. None until parsed;
        // resolved against self.drag_table once the arg-parse loop is done, shared by both
        // the base and --wez dispatch below.
        let mut cd_scale: Option<f64> = None;
        // MBA-1343 Phase C: WEZ (Weapon Employment Zone) sweep mode, mirroring the
        // native `monte-carlo --wez` flag set (MBA-1317). The wez-only flags are kept
        // as Options so using one without --wez can be rejected (native clap's
        // `requires = "wez"`), not silently ignored.
        let mut wez = false;
        let mut target_size: Option<String> = None;
        let mut wind_call_error: Option<f64> = None;
        let mut wez_start: Option<f64> = None;
        let mut wez_end: Option<f64> = None;
        let mut wez_step: Option<f64> = None;
        let mut output = "summary";

        // Parse arguments. Every value-taking flag goes through `require_value`, so a
        // flag dangling at the end of the line is an error, never a silent skip; bare
        // non-flag tokens are rejected like native clap's "unexpected argument".
        let mut i = 0;
        while i < args.len() {
            match args[i] {
                "-v" | "--velocity" => {
                    velocity = require_value(args, i)?
                        .parse()
                        .map_err(|_| JsValue::from_str("Invalid velocity"))?;
                    i += 1;
                }
                "-a" | "--angle" => {
                    angle = require_value(args, i)?
                        .parse()
                        .map_err(|_| JsValue::from_str("Invalid angle"))?;
                    i += 1;
                }
                "-b" | "--bc" => {
                    bc = require_value(args, i)?
                        .parse()
                        .map_err(|_| JsValue::from_str("Invalid BC"))?;
                    i += 1;
                }
                "--bc-reference" => {
                    bc_reference_standard = parse_bc_reference_arg(require_value(args, i)?)?;
                    i += 1;
                }
                "-m" | "--mass" => {
                    mass = require_value(args, i)?
                        .parse()
                        .map_err(|_| JsValue::from_str("Invalid mass"))?;
                    i += 1;
                }
                "-d" | "--diameter" => {
                    diameter = require_value(args, i)?
                        .parse()
                        .map_err(|_| JsValue::from_str("Invalid diameter"))?;
                    i += 1;
                }
                "-n" | "--num-sims" => {
                    num_sims = require_value(args, i)?
                        .parse()
                        .map_err(|_| JsValue::from_str("Invalid number of simulations"))?;
                    i += 1;
                }
                "--velocity-std" => {
                    velocity_std = Some(
                        require_value(args, i)?
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid velocity std"))?,
                    );
                    i += 1;
                }
                "--angle-std" => {
                    angle_std = require_value(args, i)?
                        .parse()
                        .map_err(|_| JsValue::from_str("Invalid angle std"))?;
                    i += 1;
                }
                "--bc-std" => {
                    bc_std = require_value(args, i)?
                        .parse()
                        .map_err(|_| JsValue::from_str("Invalid BC std"))?;
                    i += 1;
                }
                // --wind-std is the native CLI's name for this flag; accept both so a
                // native command line pastes into the terminal unchanged.
                "--wind-speed-std" | "--wind-std" => {
                    wind_speed_std = Some(
                        require_value(args, i)?
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid wind speed std"))?,
                    );
                    i += 1;
                }
                "--wind-direction-std" | "--wind-dir-std" => {
                    wind_direction_std = require_value(args, i)?
                        .parse()
                        .map_err(|_| JsValue::from_str("Invalid wind direction std"))?;
                    i += 1;
                }
                "--drag-model" => {
                    drag_model = require_value(args, i)?;
                    i += 1;
                }
                "--cd-scale" => {
                    cd_scale = Some(
                        require_value(args, i)?
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid cd-scale"))?,
                    );
                    i += 1;
                }
                "--wez" => {
                    wez = true;
                }
                "--target-size" => {
                    target_size = Some(require_value(args, i)?.to_string());
                    i += 1;
                }
                "--wind-call-error" => {
                    wind_call_error = Some(
                        require_value(args, i)?
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid wind call error"))?,
                    );
                    i += 1;
                }
                "--wez-start" => {
                    wez_start = Some(
                        require_value(args, i)?
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid wez start range"))?,
                    );
                    i += 1;
                }
                "--wez-end" => {
                    wez_end = Some(
                        require_value(args, i)?
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid wez end range"))?,
                    );
                    i += 1;
                }
                "--wez-step" => {
                    wez_step = Some(
                        require_value(args, i)?
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid wez step"))?,
                    );
                    i += 1;
                }
                "-o" | "--output" => {
                    output = require_value(args, i)?;
                    i += 1;
                }
                // --units/-u (+ its value) is consumed globally in run_command, which
                // pre-scans it to set the unit system before dispatch. Skip it here so
                // it isn't rejected as an unknown flag (this is what blocked metric input).
                "--units" | "-u" => {
                    i += 1;
                }
                // Reject unrecognized flags instead of silently ignoring them, so a
                // typo or a flag that isn't wired into this WASM surface is caught
                // immediately rather than looking like a no-op. (The native CLI's clap
                // parser already does this; the hand-rolled WASM parser did not.)
                other if other.starts_with('-') => {
                    return Err(JsValue::from_str(&format!("Unknown flag: {}", other)));
                }
                // Bare non-flag tokens are equally errors (native clap: "unexpected
                // argument"): silently ignoring them made e.g. a mistyped flag value
                // look like a successful run (MBA-1343 review).
                other => {
                    return Err(JsValue::from_str(&format!(
                        "Error: unexpected argument '{other}'"
                    )));
                }
            }
            i += 1;
        }

        // MBA-1356: --cd-scale requires a loaded drag table, mirroring the native CLI's
        // --cd-scale/--drag-table pairing requirement. Validate before any solve — shared by
        // both the --wez and base dispatch below, since both read the same self.drag_table.
        if cd_scale.is_some() && self.drag_table.borrow().is_none() {
            return Err(JsValue::from_str(CD_SCALE_REQUIRES_DRAG_TABLE));
        }

        // MBA-1343 Phase C: WEZ sweep mode. Mirrors the native dispatch
        // (Commands::MonteCarlo with `wez: true` in main.rs): convert to metric, run
        // the shared seeded compute (ballistics_engine::wez::compute_wez), and render
        // summary / statistics / full exactly as the native printers do.
        if wez {
            return self.run_monte_carlo_wez(
                units,
                velocity,
                angle,
                bc,
                bc_reference_standard,
                mass,
                diameter,
                num_sims,
                velocity_std,
                angle_std,
                bc_std,
                wind_speed_std,
                wind_direction_std,
                wind_call_error,
                target_size.as_deref(),
                wez_start,
                wez_end,
                wez_step,
                drag_model,
                cd_scale,
                output,
            );
        }
        // The wez-only flags mirror native clap's `requires = "wez"`: using one
        // without --wez is an error, never a silent no-op.
        if target_size.is_some() {
            return Err(JsValue::from_str("--target-size requires --wez"));
        }
        if wind_call_error.is_some() {
            return Err(JsValue::from_str("--wind-call-error requires --wez"));
        }
        if wez_start.is_some() {
            return Err(JsValue::from_str("--wez-start requires --wez"));
        }
        if wez_end.is_some() {
            return Err(JsValue::from_str("--wez-end requires --wez"));
        }
        if wez_step.is_some() {
            return Err(JsValue::from_str("--wez-step requires --wez"));
        }
        // Base monte-carlo has a single (summary) output format on the WASM surface;
        // the statistics/full modes native supports there remain a documented gap.
        match output.to_lowercase().as_str() {
            "summary" | "table" => {}
            other => {
                return Err(JsValue::from_str(&format!(
                    "-o {other} requires --wez in the WASM terminal (base monte-carlo has a single summary output)"
                )));
            }
        }
        // Historical base-path defaults (pre-WEZ behavior, unchanged).
        let velocity_std = velocity_std.unwrap_or(if units == UnitSystem::Imperial {
            10.0
        } else {
            3.0
        });
        let wind_speed_std = wind_speed_std.unwrap_or(if units == UnitSystem::Imperial {
            2.0
        } else {
            0.5
        });

        // Build inputs
        let mut inputs = InternalBallisticInputs::default();

        // Convert units
        match units {
            UnitSystem::Imperial => {
                inputs.muzzle_velocity = velocity * 0.3048;
                inputs.bullet_mass = mass * crate::constants::GRAINS_TO_KG;
                inputs.bullet_diameter = diameter * 0.0254;
            }
            UnitSystem::Metric => {
                inputs.muzzle_velocity = velocity;
                inputs.bullet_mass = mass * 0.001;
                inputs.bullet_diameter = diameter * 0.001;
            }
        }

        // MBA-1135: mass-based length estimate (mirrors CLI/FFI); replaces the mass-blind
        // 4.5-caliber heuristic. WASM otherwise left it at the struct default.
        inputs.bullet_length =
            crate::stability::estimate_bullet_length_m(inputs.bullet_diameter, inputs.bullet_mass);
        if inputs.bullet_length <= 0.0 {
            inputs.bullet_length = inputs.bullet_diameter * 4.5;
        }

        inputs.bc_value = bc;
        inputs.bc_reference_standard = bc_reference_standard;
        // Honor --drag-model (mirrors the trajectory/zero handlers); previously the Monte
        // Carlo path silently always used the G1 default even when G7 was intended.
        let drag_model_parsed = DragModel::from_str(drag_model)
            .ok_or_else(|| JsValue::from_str("Invalid drag model"))?;
        inputs.bc_type = drag_model_parsed;
        // Custom drag table (MBA-1328): see handle_trajectory_command for the rationale —
        // applied unconditionally, no gate flag, mirrors native --drag-table on `monte-carlo`.
        // Note: with a table active, --bc-std dispersion becomes a no-op for drag (the table
        // fixes Cd directly) — same documented caveat as native (CLI_USAGE.md).
        if let Some(table) = self.drag_table.borrow().as_ref() {
            inputs.custom_drag_table = Some(table.clone());
        }
        // MBA-1356: pairing already validated (before any solve, above); just apply. The
        // warning is prepended to the result string below, table-only.
        if let Some(scale) = cd_scale {
            inputs.cd_scale = scale;
        }
        let cd_scale_warning = cd_scale.and_then(cd_scale_range_warning);
        // MBA-1365: table-only, same rationale as handle_trajectory_command.
        let bc_reference_warning = inputs
            .bc_reference_standard_inert_warning()
            .map(|w| format!("{w}\n\n"));
        inputs.muzzle_angle = angle * std::f64::consts::PI / 180.0;
        inputs.muzzle_height = 1.5;
        inputs.ground_threshold = 0.0;

        // Create Monte Carlo parameters
        let params = MonteCarloParams {
            num_simulations: num_sims,
            velocity_std_dev: velocity_std
                * (if units == UnitSystem::Imperial {
                    0.3048
                } else {
                    1.0
                }),
            angle_std_dev: angle_std * std::f64::consts::PI / 180.0,
            bc_std_dev: bc_std,
            wind_speed_std_dev: wind_speed_std
                * (if units == UnitSystem::Imperial {
                    0.44704
                } else {
                    1.0
                }),
            base_wind_speed: 0.0,
            base_wind_direction: 0.0,
            azimuth_std_dev: 0.001,
            target_distance: None,
        };

        let body = match run_monte_carlo_with_direction_std_dev(
            inputs,
            params,
            wind_direction_std * std::f64::consts::PI / 180.0,
        ) {
            Ok(results) => {
                // Calculate statistics
                let mean_range: f64 =
                    results.ranges.iter().sum::<f64>() / results.ranges.len() as f64;
                let mean_velocity: f64 = results.impact_velocities.iter().sum::<f64>()
                    / results.impact_velocities.len() as f64;

                let range_std = {
                    let variance: f64 = results
                        .ranges
                        .iter()
                        .map(|r| (r - mean_range).powi(2))
                        .sum::<f64>()
                        / results.ranges.len() as f64;
                    variance.sqrt()
                };

                let velocity_std = {
                    let variance: f64 = results
                        .impact_velocities
                        .iter()
                        .map(|v| (v - mean_velocity).powi(2))
                        .sum::<f64>()
                        / results.impact_velocities.len() as f64;
                    variance.sqrt()
                };

                // Convert back to display units
                let (range_unit, velocity_unit) = match units {
                    UnitSystem::Imperial => ("yards", "fps"),
                    UnitSystem::Metric => ("meters", "m/s"),
                };

                let display_mean_range = match units {
                    UnitSystem::Imperial => mean_range * 1.09361,
                    UnitSystem::Metric => mean_range,
                };

                let display_range_std = match units {
                    UnitSystem::Imperial => range_std * 1.09361,
                    UnitSystem::Metric => range_std,
                };

                let display_mean_velocity = match units {
                    UnitSystem::Imperial => mean_velocity * 3.28084,
                    UnitSystem::Metric => mean_velocity,
                };

                let display_velocity_std = match units {
                    UnitSystem::Imperial => velocity_std * 3.28084,
                    UnitSystem::Metric => velocity_std,
                };

                format!(
                    "Monte Carlo Simulation Results\n\
                     ==============================\n\
                     Simulations Run: {}\n\n\
                     Range Statistics:\n\
                     - Mean: {:.1} {}\n\
                     - Std Dev: {:.1} {}\n\
                     - Min: {:.1} {}\n\
                     - Max: {:.1} {}\n\n\
                     Impact Velocity Statistics:\n\
                     - Mean: {:.0} {}\n\
                     - Std Dev: {:.0} {}\n\
                     - Min: {:.0} {}\n\
                     - Max: {:.0} {}",
                    num_sims,
                    display_mean_range,
                    range_unit,
                    display_range_std,
                    range_unit,
                    results
                        .ranges
                        .iter()
                        .min_by(|a, b| a.partial_cmp(b).unwrap())
                        .unwrap()
                        * (if units == UnitSystem::Imperial {
                            1.09361
                        } else {
                            1.0
                        }),
                    range_unit,
                    results
                        .ranges
                        .iter()
                        .max_by(|a, b| a.partial_cmp(b).unwrap())
                        .unwrap()
                        * (if units == UnitSystem::Imperial {
                            1.09361
                        } else {
                            1.0
                        }),
                    range_unit,
                    display_mean_velocity,
                    velocity_unit,
                    display_velocity_std,
                    velocity_unit,
                    results
                        .impact_velocities
                        .iter()
                        .min_by(|a, b| a.partial_cmp(b).unwrap())
                        .unwrap()
                        * (if units == UnitSystem::Imperial {
                            3.28084
                        } else {
                            1.0
                        }),
                    velocity_unit,
                    results
                        .impact_velocities
                        .iter()
                        .max_by(|a, b| a.partial_cmp(b).unwrap())
                        .unwrap()
                        * (if units == UnitSystem::Imperial {
                            3.28084
                        } else {
                            1.0
                        }),
                    velocity_unit,
                )
            }
            Err(e) => format!("Error running Monte Carlo simulation: {}", e),
        };
        // MBA-1356: table-only prepend, same pattern as the trajectory handler — this
        // command has no JSON/CSV output mode to protect from contamination.
        Ok(format!(
            "{}{}{}",
            cd_scale_warning.as_deref().unwrap_or(""),
            bc_reference_warning.as_deref().unwrap_or(""),
            body
        ))
    }

    /// Native `monte-carlo --wez` parity path (MBA-1343 Phase C): unit conversions
    /// mirror the native dispatch factor-for-factor, the compute is the shared
    /// per-step-seeded [`crate::wez::compute_wez`] core (deterministic, so outputs are
    /// directly comparable to the native binary), and the three renderers replicate
    /// the native printers byte-for-byte.
    #[allow(
        clippy::too_many_arguments,
        reason = "flat arguments mirror the stable Monte Carlo CLI command shape (MBA-1317)"
    )]
    #[cfg(feature = "wasm-monte-carlo")]
    fn run_monte_carlo_wez(
        &self,
        units: UnitSystem,
        velocity: f64,
        angle: f64,
        bc: f64,
        bc_reference_standard: BcReferenceStandard,
        mass: f64,
        diameter: f64,
        num_sims: usize,
        velocity_std: Option<f64>,
        angle_std: f64,
        bc_std: f64,
        wind_speed_std: Option<f64>,
        wind_direction_std: f64,
        wind_call_error: Option<f64>,
        target_size: Option<&str>,
        wez_start: Option<f64>,
        wez_end: Option<f64>,
        wez_step: Option<f64>,
        drag_model: &str,
        cd_scale: Option<f64>,
        output: &str,
    ) -> Result<String, JsValue> {
        // Native clap defaults: --velocity-std 1.0, --wind-std 1.0, --wind-call-error
        // 0.0, --wez-start 200, --wez-end 1000, --wez-step 100 — all in user units.
        // (The base WASM monte-carlo keeps its own historical std defaults; see
        // handle_monte_carlo_command.)
        let velocity_std = velocity_std.unwrap_or(1.0);
        let wind_speed_std = wind_speed_std.unwrap_or(1.0);
        let wind_call_error = wind_call_error.unwrap_or(0.0);
        let wez_start = wez_start.unwrap_or(200.0);
        let wez_end = wez_end.unwrap_or(1000.0);
        let wez_step = wez_step.unwrap_or(100.0);

        // Native MonteCarloOutput mode names first; the WASM terminal's conventional
        // table/csv/json spellings map onto the same three modes (table -> summary,
        // csv -> statistics, json -> full).
        let output = match output.to_lowercase().as_str() {
            "summary" | "table" => WezOutputMode::Summary,
            "statistics" | "csv" => WezOutputMode::Statistics,
            "full" | "json" => WezOutputMode::Full,
            other => {
                return Err(JsValue::from_str(&format!(
                    "Invalid --output '{other}' (expected summary, statistics, or full; \
                     table/csv/json are accepted aliases)"
                )))
            }
        };

        let target_size_spec = target_size.ok_or_else(|| {
            JsValue::from_str("--target-size is required with --wez (e.g. --target-size 18x30)")
        })?;
        let target_size_parsed = crate::wez::parse_target_size(target_size_spec)
            .map_err(|e| JsValue::from_str(&format!("--target-size: {e}")))?;
        let target_size_metric = target_size_parsed.to_metric(engine_units(units));

        // Unit conversions, mirroring the native dispatch (UnitConverter::*_to_metric).
        let (velocity_metric, mass_metric, diameter_metric) = match units {
            UnitSystem::Imperial => (
                velocity * 0.3048,
                mass * crate::constants::GRAINS_TO_KG,
                diameter * 0.0254,
            ),
            UnitSystem::Metric => (velocity, mass * 0.001, diameter * 0.001),
        };
        let velocity_std_metric = match units {
            UnitSystem::Imperial => velocity_std * 0.3048, // fps to m/s
            UnitSystem::Metric => velocity_std,
        };
        let to_wind = |v: f64| match units {
            UnitSystem::Imperial => v * 0.44704, // mph to m/s
            UnitSystem::Metric => v,
        };
        let to_distance = |v: f64| match units {
            UnitSystem::Imperial => v * 0.9144, // yards to meters
            UnitSystem::Metric => v,
        };

        // Custom drag table (MBA-1328): applied unconditionally when loaded, mirroring
        // native --drag-table on `monte-carlo` (see handle_monte_carlo_command).
        let custom_drag_table = self.drag_table.borrow().as_ref().cloned();

        // --drag-model (a WASM-surface extension; the native `monte-carlo` has no such
        // flag and always sweeps G1). Same validation/message as the base path below.
        let drag_model = DragModel::from_str(drag_model)
            .ok_or_else(|| JsValue::from_str("Invalid drag model"))?;

        // MBA-1356: pairing already validated by the caller (handle_monte_carlo_command,
        // before any solve); just resolve the value and the out-of-range nudge here.
        let cd_scale_warning = cd_scale.and_then(cd_scale_range_warning);
        let cd_scale = cd_scale.unwrap_or(1.0);
        // MBA-1365: table-only, same rationale as handle_trajectory_command. `compute_wez`
        // has no `BallisticInputs` to ask, so check the same two primitives directly.
        let bc_reference_warning = if custom_drag_table.is_some()
            && matches!(
                bc_reference_standard,
                BcReferenceStandard::ArmyStandardMetro
            ) {
            Some(format!("{BC_REFERENCE_STANDARD_INERT_WARNING}\n\n"))
        } else {
            None
        };

        // MBA-1365: `compute_wez` owns its own solve plumbing (no `BcReferenceStandard`
        // field), so apply the one ASM->ICAO multiply here instead — to both the mean and
        // its std dev, linear-equivalent to converting every sampled BC downstream.
        let bc_metric = match bc_reference_standard {
            BcReferenceStandard::Icao => bc,
            BcReferenceStandard::ArmyStandardMetro => bc * crate::constants::ASM_TO_ICAO_BC,
        };
        let bc_std_metric = match bc_reference_standard {
            BcReferenceStandard::Icao => bc_std,
            BcReferenceStandard::ArmyStandardMetro => bc_std * crate::constants::ASM_TO_ICAO_BC,
        };

        // Flags the WASM monte-carlo surface does not (yet) expose keep the native
        // defaults: base wind (--wind-speed / --wind-direction / --wind-vertical) and
        // --cant are all 0.
        let result = crate::wez::compute_wez(
            velocity_metric,
            angle,
            bc_metric,
            mass_metric,
            diameter_metric,
            num_sims,
            velocity_std_metric,
            angle_std,
            bc_std_metric,
            to_wind(wind_speed_std),
            wind_direction_std,
            0.0, // wind_speed
            0.0, // wind_direction
            0.0, // wind_vertical
            to_wind(wind_call_error),
            target_size_metric,
            to_distance(wez_start),
            to_distance(wez_end),
            to_distance(wez_step),
            drag_model,
            custom_drag_table,
            cd_scale,
            0.0, // cant
            0.0, // sight_offset_lateral_m (not exposed on this surface, like cant)
        )
        .map_err(|e| JsValue::from_str(&e.to_string()))?;

        match output {
            // JSON/CSV must stay pure machine output — the cd_scale nudge is table-only,
            // same convention as every other prepended warning in this file.
            WezOutputMode::Full => format_wez_full(&result),
            WezOutputMode::Statistics => Ok(format_wez_statistics(&result, units)),
            WezOutputMode::Summary => Ok(format!(
                "{}{}{}",
                cd_scale_warning.as_deref().unwrap_or(""),
                bc_reference_warning.as_deref().unwrap_or(""),
                format_wez_summary(&result, units)
            )),
        }
    }

    /// `true-velocity` (MBA-1343 Phase C): the native command's local compute paths on
    /// the WASM terminal. Zero `--observed` flags -> the classic single-observation
    /// binary search ([`crate::truing::calculate_true_velocity_local`]); one or more ->
    /// the MBA-1316 joint MV+BC calibration
    /// ([`crate::truing::run_multi_observation_truing_core`]). Unit conversions and all
    /// three output formats mirror the native dispatch/printers byte-for-byte.
    #[cfg(feature = "wasm-truing")]
    fn handle_true_velocity_command(
        &self,
        args: &[&str],
        units: UnitSystem,
    ) -> Result<String, JsValue> {
        use crate::truing::{DragModelArg, DropUnit};

        // Default bullet parameters follow this file's house convention (the native
        // command clap-requires -b/-m/-d instead).
        let (default_mass, default_diameter) = match units {
            UnitSystem::Imperial => (168.0, 0.308),
            UnitSystem::Metric => (10.9, 7.82),
        };

        let mut measured_drop: Option<f64> = None;
        let mut range: Option<f64> = None;
        let mut observed: Vec<String> = Vec::new();
        let mut drop_unit = DropUnit::Mil;
        // MBA-1358: elevation tracking CF — dialed observations are MULTIPLIED by it
        // (scope-dial units -> true angular) before the fit; dial-unit report values
        // are converted back to scope units (÷CF) for display. Mirrors the native
        // command exactly.
        let mut elevation_cf: f64 = 1.0;
        let mut bc = 0.475;
        let mut drag_model = "g1";
        let mut mass = default_mass;
        let mut diameter = default_diameter;
        let mut chrono_velocity: Option<f64> = None;
        let mut chrono_distance: Option<f64> = None;
        let mut zero_distance = 100.0;
        let mut sight_height: Option<f64> = None;
        let mut temperature: Option<f64> = None;
        let mut pressure: Option<f64> = None;
        // MBA-1426 item 3: native true-velocity has honored --pressure-type since MBA-1416.
        let mut pressure_type: Option<PressureReferenceMode> = None;
        let mut humidity = 50.0;
        let mut altitude = 0.0;
        let mut output = "table";

        // Every value-taking flag goes through `require_value`, so a flag dangling at
        // the end of the line is an error, never a silent skip (a dangling --observed
        // used to silently fall back to single-observation truing); bare non-flag
        // tokens are rejected like native clap's "unexpected argument" (a space-
        // separated second observation, e.g. `--observed 600:4.8 700:5.9`, used to
        // silently drop the second point and corrupt the fit — MBA-1343 review).
        let mut i = 0;
        while i < args.len() {
            match args[i] {
                "--measured-drop" => {
                    measured_drop = Some(
                        require_value(args, i)?
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid measured drop"))?,
                    );
                    i += 1;
                }
                "--range" => {
                    range = Some(
                        require_value(args, i)?
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid range"))?,
                    );
                    i += 1;
                }
                "--observed" => {
                    observed.push(require_value(args, i)?.to_string());
                    i += 1;
                }
                "--drop-unit" => {
                    drop_unit = DropUnit::parse(require_value(args, i)?)
                        .map_err(|e| JsValue::from_str(&e))?;
                    i += 1;
                }
                // MBA-1358: same accepted band as the native CLI (shared bound).
                "--elevation-cf" => {
                    elevation_cf = require_value(args, i)?
                        .parse()
                        .map_err(|_| JsValue::from_str("Invalid elevation CF"))?;
                    if !crate::adjustment::tracking_cf_in_range(elevation_cf) {
                        return Err(JsValue::from_str(
                            "--elevation-cf must be a tracking correction factor strictly \
                             between 0.5 and 1.5",
                        ));
                    }
                    i += 1;
                }
                "-b" | "--bc" => {
                    bc = require_value(args, i)?
                        .parse()
                        .map_err(|_| JsValue::from_str("Invalid BC"))?;
                    i += 1;
                }
                "--drag-model" => {
                    drag_model = require_value(args, i)?;
                    i += 1;
                }
                "-m" | "--mass" => {
                    mass = require_value(args, i)?
                        .parse()
                        .map_err(|_| JsValue::from_str("Invalid mass"))?;
                    i += 1;
                }
                "-d" | "--diameter" => {
                    diameter = require_value(args, i)?
                        .parse()
                        .map_err(|_| JsValue::from_str("Invalid diameter"))?;
                    i += 1;
                }
                "--chrono-velocity" => {
                    chrono_velocity = Some(
                        require_value(args, i)?
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid chrono velocity"))?,
                    );
                    i += 1;
                }
                "--chrono-distance" => {
                    chrono_distance = Some(
                        require_value(args, i)?
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid chrono distance"))?,
                    );
                    i += 1;
                }
                "--zero-distance" => {
                    zero_distance = require_value(args, i)?
                        .parse()
                        .map_err(|_| JsValue::from_str("Invalid zero distance"))?;
                    i += 1;
                }
                "--sight-height" => {
                    sight_height = Some(
                        require_value(args, i)?
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid sight height"))?,
                    );
                    i += 1;
                }
                "--temperature" => {
                    temperature = Some(
                        require_value(args, i)?
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid temperature"))?,
                    );
                    i += 1;
                }
                "--pressure" => {
                    pressure = Some(
                        require_value(args, i)?
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid pressure"))?,
                    );
                    i += 1;
                }
                "--humidity" => {
                    humidity = require_value(args, i)?
                        .parse()
                        .map_err(|_| JsValue::from_str("Invalid humidity"))?;
                    i += 1;
                }
                "--pressure-type" => {
                    // This parser is hardened (MBA-1343): every value flag goes through
                    // require_value so a dangling flag errors instead of silently skipping.
                    pressure_type = Some(parse_pressure_type_arg(require_value(args, i)?)?);
                    i += 1;
                }
                "--altitude" => {
                    altitude = require_value(args, i)?
                        .parse()
                        .map_err(|_| JsValue::from_str("Invalid altitude"))?;
                    i += 1;
                }
                "-o" | "--output" => {
                    output = require_value(args, i)?;
                    i += 1;
                }
                // Native's --offline forces the local calculation; the WASM terminal is
                // always local, so accept it as a harmless no-op for command parity.
                "--offline" => {}
                // --units/-u (+ its value) is consumed globally in run_command, which
                // pre-scans it to set the unit system before dispatch. Skip it here so
                // it isn't rejected as an unknown flag.
                "--units" | "-u" => {
                    i += 1;
                }
                // Reject unrecognized flags instead of silently ignoring them (this
                // includes the native online/BC5D flags this surface does not support).
                other if other.starts_with('-') => {
                    return Err(JsValue::from_str(&format!("Unknown flag: {}", other)));
                }
                // Bare non-flag tokens are equally errors (native clap: "unexpected
                // argument").
                other => {
                    return Err(JsValue::from_str(&format!(
                        "Error: unexpected argument '{other}'"
                    )));
                }
            }
            i += 1;
        }

        let measured_drop =
            measured_drop.ok_or_else(|| JsValue::from_str("--measured-drop is required"))?;
        let range = range.ok_or_else(|| JsValue::from_str("--range is required"))?;

        let drag_model_arg = match drag_model.to_lowercase().as_str() {
            "g1" => DragModelArg::G1,
            "g7" => DragModelArg::G7,
            _ => return Err(JsValue::from_str("Invalid drag model (expected G1 or G7)")),
        };

        let output = match output.to_lowercase().as_str() {
            "table" => OutputFormat::Table,
            "json" => OutputFormat::Json,
            "csv" => OutputFormat::Csv,
            other => {
                return Err(JsValue::from_str(&format!(
                    "Invalid --output '{other}' (expected table, json, or csv)"
                )))
            }
        };

        if !(0.0..=100.0).contains(&humidity) {
            return Err(JsValue::from_str("--humidity must be between 0 and 100"));
        }

        // Native clap's f64_range validators for the bullet parameters (same bounds
        // under either unit system). The hand-rolled parser previously accepted any
        // finite (or NaN) value here.
        if !(0.001..=2.0).contains(&bc) {
            return Err(JsValue::from_str(&format!(
                "Error: invalid value '{bc}' for '--bc': must be in range 0.001..=2"
            )));
        }
        if !(0.1..=2000.0).contains(&mass) {
            return Err(JsValue::from_str(&format!(
                "Error: invalid value '{mass}' for '--mass': must be in range 0.1..=2000"
            )));
        }
        if !(0.01..=60.0).contains(&diameter) {
            return Err(JsValue::from_str(&format!(
                "Error: invalid value '{diameter}' for '--diameter': must be in range 0.01..=60"
            )));
        }

        // Resolve temperature/pressure AFTER units are known — replicates the native
        // UnitConverter::resolve_temperature / resolve_pressure defaults and range
        // checks (identical error strings).
        let temperature = match (temperature, units) {
            (None, UnitSystem::Imperial) => 59.0,
            (None, UnitSystem::Metric) => 15.0,
            (Some(v), UnitSystem::Imperial) => {
                if !(-148.0..=392.0).contains(&v) {
                    return Err(JsValue::from_str(&format!(
                        "--temperature {v} F is out of range (expected ~-148..392 F for imperial units)"
                    )));
                }
                v
            }
            (Some(v), UnitSystem::Metric) => {
                if !(-100.0..=200.0).contains(&v) {
                    return Err(JsValue::from_str(&format!(
                        "--temperature {v} C is out of range (expected ~-100..200 C for metric units)"
                    )));
                }
                v
            }
        };
        let pressure = match (pressure, units) {
            (None, UnitSystem::Imperial) => 29.92,
            (None, UnitSystem::Metric) => 1013.25,
            (Some(v), UnitSystem::Imperial) => {
                if !(8.0..=33.0).contains(&v) {
                    return Err(JsValue::from_str(&format!(
                        "--pressure {v} inHg is out of range (expected ~8..33 inHg for imperial units)"
                    )));
                }
                v
            }
            (Some(v), UnitSystem::Metric) => {
                if !(250.0..=1100.0).contains(&v) {
                    return Err(JsValue::from_str(&format!(
                        "--pressure {v} hPa is out of range (expected ~250..1100 hPa for metric units)"
                    )));
                }
                v
            }
        };
        // MBA-1426 item 3: a declared QNH reduces against this command's own --altitude,
        // matching native true-velocity since MBA-1416. Multiplicative, so applying it to the
        // display-unit value composes exactly like native's apply_pressure_mode.
        let pressure = match pressure_type.unwrap_or(PressureReferenceMode::Absolute) {
            PressureReferenceMode::Absolute => pressure,
            PressureReferenceMode::Qnh => {
                let altitude_m = match units {
                    UnitSystem::Imperial => altitude * 0.3048,
                    UnitSystem::Metric => altitude,
                };
                crate::atmosphere::reduce_qnh_to_station_pressure(pressure, altitude_m)
            }
        };

        // Convert to the truing core's internal imperial units — factor-for-factor the
        // native Commands::TrueVelocity dispatch.
        let range_yd = match units {
            UnitSystem::Imperial => range,
            UnitSystem::Metric => range / 0.9144, // meters to yards
        };
        let weight_gr = match units {
            UnitSystem::Imperial => mass,
            UnitSystem::Metric => mass / crate::constants::GRAMS_PER_GRAIN, // grams to grains
        };
        let caliber_in = match units {
            UnitSystem::Imperial => diameter,
            UnitSystem::Metric => diameter / 25.4, // mm to inches
        };
        let chrono_fps = chrono_velocity.map(|v| match units {
            UnitSystem::Imperial => v,
            UnitSystem::Metric => v / 0.3048, // m/s to fps
        });
        let zero_yd = match units {
            UnitSystem::Imperial => zero_distance,
            UnitSystem::Metric => zero_distance / 0.9144,
        };
        let sight_height_default = match units {
            UnitSystem::Imperial => 2.0,
            UnitSystem::Metric => 50.0,
        };
        let sight_height = sight_height.unwrap_or(sight_height_default);
        let sight_in = match units {
            UnitSystem::Imperial => sight_height,
            UnitSystem::Metric => sight_height / 25.4, // mm to inches
        };
        let temp_f = match units {
            UnitSystem::Imperial => temperature,
            UnitSystem::Metric => temperature * 9.0 / 5.0 + 32.0, // C to F
        };
        let press_inhg = match units {
            UnitSystem::Imperial => pressure,
            UnitSystem::Metric => pressure / 33.8639, // hPa to inHg
        };
        let alt_ft = match units {
            UnitSystem::Imperial => altitude,
            UnitSystem::Metric => altitude / 0.3048, // meters to feet
        };

        // No BC5D segment synthesis on this path: native gates it behind
        // --bc-table-dir / --bc-table-auto, which the WASM terminal does not expose
        // (the loaded-BC5D host API only wires into `trajectory --use-bc-segments`).
        let bc_segments: Option<Vec<crate::BCSegmentData>> = None;

        // MBA-1377: correct a downrange chronograph reading back to muzzle velocity. Mirrors
        // the native `Commands::TrueVelocity` dispatch byte-for-byte: pure input-side
        // transform on `chrono_fps` before it reaches any display/comparison path below, with
        // `truing.rs`'s drop-based solves never seeing --chrono-distance.
        if chrono_distance.is_some_and(|d| d != 0.0) && chrono_fps.is_none() {
            return Err(JsValue::from_str(
                "--chrono-distance requires --chrono-velocity",
            ));
        }
        let chrono_fps = match (chrono_fps, chrono_distance) {
            (Some(measured), Some(d)) if d != 0.0 => {
                let screen_distance_m = match units {
                    UnitSystem::Imperial => d * 0.3048, // feet to meters
                    UnitSystem::Metric => d,
                };
                let correction = crate::truing::correct_chrono_velocity_fps(
                    measured,
                    screen_distance_m,
                    bc,
                    drag_model_arg,
                    weight_gr,
                    caliber_in,
                    temp_f,
                    press_inhg,
                    humidity,
                    alt_ft,
                    &bc_segments,
                )
                .map_err(|e| JsValue::from_str(&e.to_string()))?;
                Some(correction.muzzle_velocity_fps)
            }
            _ => chrono_fps,
        };

        // MBA-1358: dialed observations multiply by the elevation CF (scope-dial ->
        // true angular) before the fit (single-observation mode is always MIL =
        // dialed; multi mode is dialed unless --drop-unit in, a tape measurement that
        // never scales). *1.0 is bit-exact.
        let observation_cf = if observed.is_empty() || drop_unit != DropUnit::In {
            elevation_cf
        } else {
            1.0
        };
        let measured_drop = measured_drop * observation_cf;

        if !observed.is_empty() {
            // MBA-1316: one or more --observed impacts -> joint MV+BC calibration via
            // the shared core. Token parsing happens here (the typed core takes
            // parsed observations); the parse and validation errors (e.g. duplicate
            // ranges) carry the native messages verbatim.
            let mut observations: Vec<crate::truing::TruingObservation> =
                Vec::with_capacity(observed.len() + 1);
            observations.push(crate::truing::TruingObservation {
                range_yd,
                drop: measured_drop,
            });
            for token in &observed {
                let mut observation =
                    crate::truing::parse_truing_observation(token, engine_units(units))
                        .map_err(|e| JsValue::from_str(&e))?;
                // MBA-1358: same single scope->true conversion as the primary
                // observation above.
                observation.drop *= observation_cf;
                observations.push(observation);
            }
            let report = crate::truing::run_multi_observation_truing_core(
                &observations,
                drop_unit,
                bc,
                drag_model_arg,
                weight_gr,
                caliber_in,
                zero_yd,
                sight_in,
                temp_f,
                press_inhg,
                humidity,
                alt_ft,
                &bc_segments,
            )
            .map_err(|e| JsValue::from_str(&e.to_string()))?;
            // MBA-1358: dial-unit report values are shown back in scope units (÷CF) via
            // the same shared helper the native CLI uses (/1.0 exact without a CF).
            let display_report = crate::truing::scale_report_dial_values(&report, observation_cf);
            Ok(format_multi_truing_result(
                &display_report,
                drop_unit,
                units,
                chrono_fps,
                output,
            ))
        } else {
            // Classic single-observation velocity truing (drop is always MIL here).
            let result = crate::truing::calculate_true_velocity_local(
                measured_drop,
                range_yd,
                bc,
                drag_model_arg,
                weight_gr,
                caliber_in,
                zero_yd,
                sight_in,
                temp_f,
                press_inhg,
                humidity,
                alt_ft,
                &bc_segments,
            )
            .map_err(|e| JsValue::from_str(&format!("Local calculation failed: {}", e)))?;

            let velocity_adjustment = chrono_fps.map(|c| result.effective_velocity_fps - c);
            let adjustment_percent =
                chrono_fps.map(|c| (result.effective_velocity_fps - c) / c * 100.0);

            let effective_vel = match units {
                UnitSystem::Imperial => result.effective_velocity_fps,
                UnitSystem::Metric => result.effective_velocity_fps * 0.3048,
            };
            let vel_unit = match units {
                UnitSystem::Imperial => "fps",
                UnitSystem::Metric => "m/s",
            };

            format_true_velocity_result(
                effective_vel,
                vel_unit,
                velocity_adjustment,
                adjustment_percent,
                &result.confidence,
                result.iterations,
                // MBA-1358: dial-unit outputs render in scope units (÷CF; the fit
                // consumed the ×CF true values) — mirrors native exactly. /1.0 exact.
                result.final_error_mil / observation_cf,
                result.calculated_drop_mil / observation_cf,
                measured_drop / observation_cf,
                units,
                output,
                false,
            )
        }
    }

    /// `true-wind` (MBA-1392): the native command's wind-call truing on the WASM terminal.
    ///
    /// Back-solves the effective crosswind from one or more observed horizontal misses
    /// ([`crate::truing_wind::solve_wind_truing`]) and renders it through the SHARED
    /// formatter [`crate::truing_wind::format_wind_truing_report`] — the same function the
    /// native CLI prints, so the two surfaces emit identical bytes by construction instead
    /// of via a replicated printer. Unit conversions mirror the native
    /// `Commands::TrueWind` dispatch factor for factor.
    #[cfg(feature = "wasm-truing")]
    fn handle_true_wind_command(
        &self,
        args: &[&str],
        units: UnitSystem,
    ) -> Result<String, JsValue> {
        use crate::truing::{DragModelArg, TruingEarthFrame, TruingTwist};
        use crate::truing_wind::{
            format_wind_truing_report, parse_wind_observation, solve_wind_truing, WindTruingOutput,
            WindTruingRequest, MPH_TO_MPS,
        };

        // Default load follows this file's house convention (the native command
        // clap-requires -v/-b/-m/-d/--twist-rate instead).
        let (default_velocity, default_mass, default_diameter) = match units {
            UnitSystem::Imperial => (2700.0, 168.0, 0.308),
            UnitSystem::Metric => (823.0, 10.9, 7.82),
        };

        let mut miss: Vec<String> = Vec::new();
        let mut velocity = default_velocity;
        let mut bc = 0.475;
        let mut drag_model = "g1";
        let mut mass = default_mass;
        let mut diameter = default_diameter;
        let mut twist_rate: Option<f64> = None;
        let mut twist_right = true;
        let mut latitude: Option<f64> = None;
        let mut shot_direction: Option<f64> = None;
        let mut called_wind: Option<f64> = None;
        let mut zero_distance = 100.0;
        let mut sight_height: Option<f64> = None;
        let mut temperature: Option<f64> = None;
        let mut pressure: Option<f64> = None;
        let mut pressure_type: Option<PressureReferenceMode> = None;
        let mut humidity = 50.0;
        let mut altitude = 0.0;
        let mut output = "table";

        // Every value-taking flag goes through `require_value`, so a flag dangling at the
        // end of the line is an error, never a silent skip. `--twist-right` is the one
        // exception and deliberately so: native clap declares it `num_args = 0..=1`, i.e.
        // its value is genuinely optional, so a bare flag means "right-hand" and a
        // following flag is left for the loop rather than swallowed.
        let mut i = 0;
        while i < args.len() {
            match args[i] {
                "--miss" => {
                    miss.push(require_value(args, i)?.to_string());
                    i += 1;
                }
                "-v" | "--velocity" => {
                    velocity = require_value(args, i)?
                        .parse()
                        .map_err(|_| JsValue::from_str("Invalid velocity"))?;
                    i += 1;
                }
                "-b" | "--bc" => {
                    bc = require_value(args, i)?
                        .parse()
                        .map_err(|_| JsValue::from_str("Invalid BC"))?;
                    i += 1;
                }
                "--drag-model" => {
                    drag_model = require_value(args, i)?;
                    i += 1;
                }
                "-m" | "--mass" => {
                    mass = require_value(args, i)?
                        .parse()
                        .map_err(|_| JsValue::from_str("Invalid mass"))?;
                    i += 1;
                }
                "-d" | "--diameter" => {
                    diameter = require_value(args, i)?
                        .parse()
                        .map_err(|_| JsValue::from_str("Invalid diameter"))?;
                    i += 1;
                }
                "--twist-rate" => {
                    twist_rate = Some(
                        require_value(args, i)?
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid twist rate"))?,
                    );
                    i += 1;
                }
                "--twist-right" => match args.get(i + 1) {
                    Some(value) if !value.starts_with('-') => {
                        twist_right = value.parse().map_err(|_| {
                            JsValue::from_str("--twist-right must be true or false")
                        })?;
                        i += 1;
                    }
                    _ => twist_right = true,
                },
                "--latitude" => {
                    latitude = Some(
                        require_value(args, i)?
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid latitude"))?,
                    );
                    i += 1;
                }
                "--shot-direction" => {
                    shot_direction = Some(
                        require_value(args, i)?
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid shot direction"))?,
                    );
                    i += 1;
                }
                "--called-wind" => {
                    called_wind = Some(
                        require_value(args, i)?
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid called wind"))?,
                    );
                    i += 1;
                }
                "--zero-distance" => {
                    zero_distance = require_value(args, i)?
                        .parse()
                        .map_err(|_| JsValue::from_str("Invalid zero distance"))?;
                    i += 1;
                }
                "--sight-height" => {
                    sight_height = Some(
                        require_value(args, i)?
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid sight height"))?,
                    );
                    i += 1;
                }
                "--temperature" => {
                    temperature = Some(
                        require_value(args, i)?
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid temperature"))?,
                    );
                    i += 1;
                }
                "--pressure" => {
                    pressure = Some(
                        require_value(args, i)?
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid pressure"))?,
                    );
                    i += 1;
                }
                "--pressure-type" => {
                    pressure_type = Some(parse_pressure_type_arg(require_value(args, i)?)?);
                    i += 1;
                }
                "--humidity" => {
                    humidity = require_value(args, i)?
                        .parse()
                        .map_err(|_| JsValue::from_str("Invalid humidity"))?;
                    i += 1;
                }
                "--altitude" => {
                    altitude = require_value(args, i)?
                        .parse()
                        .map_err(|_| JsValue::from_str("Invalid altitude"))?;
                    i += 1;
                }
                "-o" | "--output" => {
                    output = require_value(args, i)?;
                    i += 1;
                }
                // Native's --offline forces the local calculation; this command is local
                // on both surfaces, so accept it as a harmless no-op for parity.
                "--offline" => {}
                // --units/-u (+ its value) is consumed globally in run_command.
                "--units" | "-u" => {
                    i += 1;
                }
                other if other.starts_with('-') => {
                    return Err(JsValue::from_str(&format!("Unknown flag: {}", other)));
                }
                other => {
                    return Err(JsValue::from_str(&format!(
                        "Error: unexpected argument '{other}'"
                    )));
                }
            }
            i += 1;
        }

        if miss.is_empty() {
            return Err(JsValue::from_str(
                "--miss RANGE:RIGHT[:SIGMA] is required (repeatable)",
            ));
        }
        let twist_rate = twist_rate.ok_or_else(|| {
            JsValue::from_str(
                "--twist-rate is required: spin drift is a lateral effect of the same order \
                 as a light wind at long range, so without it the fit would report spin \
                 drift as wind",
            )
        })?;

        let drag_model_arg = match drag_model.to_lowercase().as_str() {
            "g1" => DragModelArg::G1,
            "g7" => DragModelArg::G7,
            _ => return Err(JsValue::from_str("Invalid drag model (expected G1 or G7)")),
        };

        let wind_output = match output.to_lowercase().as_str() {
            "table" => WindTruingOutput::Table,
            "json" => WindTruingOutput::Json,
            "csv" => WindTruingOutput::Csv,
            other => {
                return Err(JsValue::from_str(&format!(
                    "Invalid --output '{other}' (expected table, json, or csv)"
                )))
            }
        };

        if !(0.0..=100.0).contains(&humidity) {
            return Err(JsValue::from_str("--humidity must be between 0 and 100"));
        }
        // Native clap's f64_range validators (same bounds under either unit system).
        if !(0.0..=6000.0).contains(&velocity) {
            return Err(JsValue::from_str(&format!(
                "Error: invalid value '{velocity}' for '--velocity': must be in range 0..=6000"
            )));
        }
        if !(0.001..=2.0).contains(&bc) {
            return Err(JsValue::from_str(&format!(
                "Error: invalid value '{bc}' for '--bc': must be in range 0.001..=2"
            )));
        }
        if !(0.1..=2000.0).contains(&mass) {
            return Err(JsValue::from_str(&format!(
                "Error: invalid value '{mass}' for '--mass': must be in range 0.1..=2000"
            )));
        }
        if !(0.01..=60.0).contains(&diameter) {
            return Err(JsValue::from_str(&format!(
                "Error: invalid value '{diameter}' for '--diameter': must be in range 0.01..=60"
            )));
        }
        if !(0.1..=1000.0).contains(&twist_rate) {
            return Err(JsValue::from_str(&format!(
                "Error: invalid value '{twist_rate}' for '--twist-rate': must be in range 0.1..=1000"
            )));
        }
        if latitude.is_some_and(|v| !(-90.0..=90.0).contains(&v)) {
            return Err(JsValue::from_str(
                "Error: invalid value for '--latitude': must be in range -90..=90",
            ));
        }

        // Resolve temperature/pressure AFTER units are known — replicates the native
        // UnitConverter::resolve_temperature / resolve_pressure defaults and range checks.
        let temperature = match (temperature, units) {
            (None, UnitSystem::Imperial) => 59.0,
            (None, UnitSystem::Metric) => 15.0,
            (Some(v), UnitSystem::Imperial) => {
                if !(-148.0..=392.0).contains(&v) {
                    return Err(JsValue::from_str(&format!(
                        "--temperature {v} F is out of range (expected ~-148..392 F for imperial units)"
                    )));
                }
                v
            }
            (Some(v), UnitSystem::Metric) => {
                if !(-100.0..=200.0).contains(&v) {
                    return Err(JsValue::from_str(&format!(
                        "--temperature {v} C is out of range (expected ~-100..200 C for metric units)"
                    )));
                }
                v
            }
        };
        let pressure = match (pressure, units) {
            (None, UnitSystem::Imperial) => 29.92,
            (None, UnitSystem::Metric) => 1013.25,
            (Some(v), UnitSystem::Imperial) => {
                if !(8.0..=33.0).contains(&v) {
                    return Err(JsValue::from_str(&format!(
                        "--pressure {v} inHg is out of range (expected ~8..33 inHg for imperial units)"
                    )));
                }
                v
            }
            (Some(v), UnitSystem::Metric) => {
                if !(250.0..=1100.0).contains(&v) {
                    return Err(JsValue::from_str(&format!(
                        "--pressure {v} hPa is out of range (expected ~250..1100 hPa for metric units)"
                    )));
                }
                v
            }
        };
        // A declared QNH reduces against this command's own --altitude (MBA-1416).
        let pressure = match pressure_type.unwrap_or(PressureReferenceMode::Absolute) {
            PressureReferenceMode::Absolute => pressure,
            PressureReferenceMode::Qnh => {
                let altitude_m = match units {
                    UnitSystem::Imperial => altitude * 0.3048,
                    UnitSystem::Metric => altitude,
                };
                crate::atmosphere::reduce_qnh_to_station_pressure(pressure, altitude_m)
            }
        };

        // Convert to the truing core's internal imperial units — factor-for-factor the
        // native `Commands::TrueWind` dispatch.
        let velocity_fps = match units {
            UnitSystem::Imperial => velocity,
            UnitSystem::Metric => velocity / 0.3048,
        };
        let weight_gr = match units {
            UnitSystem::Imperial => mass,
            UnitSystem::Metric => mass / crate::constants::GRAMS_PER_GRAIN,
        };
        let caliber_in = match units {
            UnitSystem::Imperial => diameter,
            UnitSystem::Metric => diameter / 25.4,
        };
        let zero_yd = match units {
            UnitSystem::Imperial => zero_distance,
            UnitSystem::Metric => zero_distance / 0.9144,
        };
        let sight_height_default = match units {
            UnitSystem::Imperial => 2.0,
            UnitSystem::Metric => 50.0,
        };
        let sight_height = sight_height.unwrap_or(sight_height_default);
        let sight_in = match units {
            UnitSystem::Imperial => sight_height,
            UnitSystem::Metric => sight_height / 25.4,
        };
        let temp_f = match units {
            UnitSystem::Imperial => temperature,
            UnitSystem::Metric => temperature * 9.0 / 5.0 + 32.0,
        };
        let press_inhg = match units {
            UnitSystem::Imperial => pressure,
            UnitSystem::Metric => pressure / 33.8639,
        };
        let alt_ft = match units {
            UnitSystem::Imperial => altitude,
            UnitSystem::Metric => altitude / 0.3048,
        };
        let twist_in = match units {
            UnitSystem::Imperial => twist_rate,
            UnitSystem::Metric => twist_rate / 25.4, // mm/turn -> inches/turn
        };
        let called_mph = called_wind.map(|v| match units {
            UnitSystem::Imperial => v,
            UnitSystem::Metric => v / MPH_TO_MPS,
        });

        // Coriolis needs BOTH halves; one without the other is a mistake, not a
        // partially-usable input. Same error text as native.
        let earth = match (latitude, shot_direction) {
            (Some(latitude_deg), Some(shot_azimuth_deg)) => Some(TruingEarthFrame {
                latitude_deg,
                shot_azimuth_deg,
            }),
            (None, None) => None,
            (Some(_), None) => {
                return Err(JsValue::from_str(
                    "--latitude also needs --shot-direction before Coriolis can be modelled \
                     (Earth rotation depends on which way downrange points)",
                ))
            }
            (None, Some(_)) => {
                return Err(JsValue::from_str(
                    "--shot-direction also needs --latitude before Coriolis can be modelled",
                ))
            }
        };

        let mut observations = Vec::with_capacity(miss.len());
        for token in &miss {
            observations.push(
                parse_wind_observation(token, engine_units(units))
                    .map_err(|e| JsValue::from_str(&e))?,
            );
        }

        let request = WindTruingRequest {
            observations,
            muzzle_velocity_fps: velocity_fps,
            bc,
            drag_model: drag_model_arg,
            mass_gr: weight_gr,
            diameter_in: caliber_in,
            zero_distance_yd: zero_yd,
            sight_height_in: sight_in,
            temperature_f: temp_f,
            pressure_inhg: press_inhg,
            humidity_pct: humidity,
            altitude_ft: alt_ft,
            twist: TruingTwist {
                rate_in: twist_in,
                right_hand: twist_right,
            },
            earth,
            called_crosswind_mph: called_mph,
        };
        let report = solve_wind_truing(&request).map_err(|e| JsValue::from_str(&e.to_string()))?;
        Ok(format_wind_truing_report(
            &report,
            engine_units(units),
            wind_output,
        ))
    }

    #[cfg(feature = "wasm-estimate-bc")]
    fn handle_estimate_bc_command(
        &self,
        args: &[&str],
        units: UnitSystem,
    ) -> Result<String, JsValue> {
        let (default_velocity, default_mass, default_diameter) = match units {
            UnitSystem::Imperial => (2700.0, 168.0, 0.308),
            UnitSystem::Metric => (823.0, 10.9, 7.82),
        };

        let mut velocity = default_velocity;
        let mut mass = default_mass;
        let mut diameter = default_diameter;
        let mut data_points: Vec<(f64, f64)> = Vec::new();
        let mut vel_points: Vec<(f64, f64)> = Vec::new();
        let mut drag_model_str = String::from("both");
        let mut zero_range: Option<f64> = None;
        let mut sight_height: Option<f64> = None;
        let mut temperature: Option<f64> = None;
        let mut pressure: Option<f64> = None;
        // MBA-1426 item 3: native estimate-bc has honored --pressure-type since MBA-1416.
        let mut pressure_type: Option<PressureReferenceMode> = None;
        let mut humidity: f64 = 50.0;
        let mut altitude: f64 = 0.0;

        // Parse "d,v;d,v;..." pairs, tolerating surrounding quotes/whitespace.
        fn parse_pairs(raw: &str) -> Result<Vec<(f64, f64)>, JsValue> {
            let s = raw.trim().trim_matches('\'').trim_matches('"');
            let mut out = Vec::new();
            for pair in s.split(';') {
                let pair = pair.trim();
                if pair.is_empty() {
                    continue;
                }
                let parts: Vec<&str> = pair.split(',').collect();
                if parts.len() != 2 {
                    return Err(JsValue::from_str(&format!(
                        "Malformed data pair '{}': expected \"distance,value\"",
                        pair
                    )));
                }
                let d: f64 = parts[0].trim().parse().map_err(|_| {
                    JsValue::from_str(&format!("Invalid distance '{}'", parts[0].trim()))
                })?;
                let v: f64 = parts[1].trim().parse().map_err(|_| {
                    JsValue::from_str(&format!("Invalid value '{}'", parts[1].trim()))
                })?;
                out.push((d, v));
            }
            Ok(out)
        }

        // Parse arguments
        let mut i = 0;
        while i < args.len() {
            match args[i] {
                "-v" | "--velocity" => {
                    if i + 1 < args.len() {
                        velocity = args[i + 1]
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid velocity"))?;
                        i += 1;
                    }
                }
                "-m" | "--mass" => {
                    if i + 1 < args.len() {
                        mass = args[i + 1]
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid mass"))?;
                        i += 1;
                    }
                }
                "-d" | "--diameter" => {
                    if i + 1 < args.len() {
                        diameter = args[i + 1]
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid diameter"))?;
                        i += 1;
                    }
                }
                "--data" => {
                    // Drop data: distance,drop pairs.
                    if i + 1 < args.len() {
                        data_points = parse_pairs(args[i + 1])?;
                        i += 1;
                    }
                }
                "--velocity-data" => {
                    // Velocity-retention data: distance,velocity pairs.
                    if i + 1 < args.len() {
                        vel_points = parse_pairs(args[i + 1])?;
                        i += 1;
                    }
                }
                "--drag-model" => {
                    if i + 1 < args.len() {
                        drag_model_str = args[i + 1].to_lowercase();
                        i += 1;
                    }
                }
                "--zero-range" => {
                    if i + 1 < args.len() {
                        zero_range = Some(
                            args[i + 1]
                                .parse()
                                .map_err(|_| JsValue::from_str("Invalid zero-range"))?,
                        );
                        i += 1;
                    }
                }
                "--sight-height" => {
                    if i + 1 < args.len() {
                        sight_height = Some(
                            args[i + 1]
                                .parse()
                                .map_err(|_| JsValue::from_str("Invalid sight-height"))?,
                        );
                        i += 1;
                    }
                }
                "--temperature" => {
                    if i + 1 < args.len() {
                        temperature = Some(
                            args[i + 1]
                                .parse()
                                .map_err(|_| JsValue::from_str("Invalid temperature"))?,
                        );
                        i += 1;
                    }
                }
                "--pressure" => {
                    if i + 1 < args.len() {
                        pressure = Some(
                            args[i + 1]
                                .parse()
                                .map_err(|_| JsValue::from_str("Invalid pressure"))?,
                        );
                        i += 1;
                    }
                }
                "--humidity" => {
                    if i + 1 < args.len() {
                        humidity = args[i + 1]
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid humidity"))?;
                        i += 1;
                    }
                }
                "--pressure-type" => {
                    if i + 1 < args.len() {
                        pressure_type = Some(parse_pressure_type_arg(args[i + 1])?);
                        i += 1;
                    }
                }
                "--altitude" => {
                    if i + 1 < args.len() {
                        altitude = args[i + 1]
                            .parse()
                            .map_err(|_| JsValue::from_str("Invalid altitude"))?;
                        i += 1;
                    }
                }
                // --units/-u (+ its value) is consumed globally in run_command, which
                // pre-scans it to set the unit system before dispatch. Skip it here so
                // it isn't rejected as an unknown flag (this is what blocked metric input).
                "--units" | "-u" => {
                    i += 1;
                }
                // Reject unrecognized flags instead of silently ignoring them, so a
                // typo or a flag that isn't wired into this WASM surface is caught
                // immediately rather than looking like a no-op. (The native CLI's clap
                // parser already does this; the hand-rolled WASM parser did not.)
                other if other.starts_with('-') => {
                    return Err(JsValue::from_str(&format!("Unknown flag: {}", other)));
                }
                _ => {}
            }
            i += 1;
        }

        if data_points.is_empty() && vel_points.is_empty() {
            return Ok("Error: No data provided. Use --data \"dist,drop;...\" and/or \
                 --velocity-data \"dist,vel;...\".\nExample: --data \"300,29.0;500,89.9;700,204.6\""
                .to_string());
        }

        // Select drag models to estimate. `both`/`all` fits G1 + G7; any other recognized
        // family name (MBA-1386 widened DragModel past the scalar G1/G7 pair) fits just
        // that one family, matching the native CLI's `parse_drag_models`.
        let models: Vec<DragModel> = match drag_model_str.as_str() {
            "both" | "all" | "g1,g7" | "g1g7" => vec![DragModel::G1, DragModel::G7],
            other => match DragModel::from_str(other) {
                Some(model) => vec![model],
                None => {
                    return Err(JsValue::from_str(&format!(
                        "Unknown --drag-model '{}'; use g1, g7, both, or a specific drag family \
                         (g2, g5, g6, g8, gi, gs, ra4).",
                        other
                    )))
                }
            },
        };

        // Convert scalar inputs to metric.
        let velocity_mps = match units {
            UnitSystem::Imperial => velocity * 0.3048,
            UnitSystem::Metric => velocity,
        };
        let mass_kg = match units {
            UnitSystem::Imperial => mass * crate::constants::GRAINS_TO_KG,
            UnitSystem::Metric => mass * 0.001,
        };
        let diameter_m = match units {
            UnitSystem::Imperial => diameter * 0.0254,
            UnitSystem::Metric => diameter * 0.001,
        };

        // Atmosphere the data was measured at (defaults = ICAO standard). BC only means
        // something relative to air density, so this must match the dope card's conditions.
        let atmosphere = AtmosphericConditions {
            temperature: temperature
                .map(|t| match units {
                    UnitSystem::Imperial => (t - 32.0) * 5.0 / 9.0,
                    UnitSystem::Metric => t,
                })
                .unwrap_or(15.0),
            // MBA-1426 item 3: the mode applies only when a pressure was actually supplied —
            // the 1013.25 default is sea-level standard by definition (same rule as native
            // estimate-bc since MBA-1416).
            pressure: pressure
                .map(|p| {
                    let p_hpa = match units {
                        UnitSystem::Imperial => p * 33.8639,
                        UnitSystem::Metric => p,
                    };
                    match pressure_type.unwrap_or(PressureReferenceMode::Absolute) {
                        PressureReferenceMode::Absolute => p_hpa,
                        PressureReferenceMode::Qnh => {
                            let altitude_m = match units {
                                UnitSystem::Imperial => altitude * 0.3048,
                                UnitSystem::Metric => altitude,
                            };
                            crate::atmosphere::reduce_qnh_to_station_pressure(p_hpa, altitude_m)
                        }
                    }
                })
                .unwrap_or(1013.25),
            humidity,
            altitude: match units {
                UnitSystem::Imperial => altitude * 0.3048,
                UnitSystem::Metric => altitude,
            },
        };
        let zero_m = zero_range.map(|z| match units {
            UnitSystem::Imperial => z * 0.9144,
            UnitSystem::Metric => z,
        });
        let sight_m = sight_height
            .map(|s| match units {
                UnitSystem::Imperial => s * 0.0254,
                UnitSystem::Metric => s / 1000.0,
            })
            .unwrap_or(0.05);

        // Convert both series to metric (drop -> m, velocity -> m/s; metric drop input is mm).
        let drop_metric: Vec<(f64, f64)> = data_points
            .iter()
            .map(|(dist, drop)| match units {
                UnitSystem::Imperial => (*dist * 0.9144, *drop * 0.0254),
                UnitSystem::Metric => (*dist, *drop * 0.001),
            })
            .collect();
        let vel_metric: Vec<(f64, f64)> = vel_points
            .iter()
            .map(|(dist, v)| match units {
                UnitSystem::Imperial => (*dist * 0.9144, *v * 0.3048),
                UnitSystem::Metric => (*dist, *v),
            })
            .collect();

        // Data bases in a stable order (drop first, then velocity).
        let mut bases: Vec<(BcFitMode, &[(f64, f64)])> = Vec::new();
        if !drop_metric.is_empty() {
            bases.push((BcFitMode::Drop, &drop_metric));
        }
        if !vel_metric.is_empty() {
            bases.push((BcFitMode::Velocity, &vel_metric));
        }

        let (vu, mu, du) = match units {
            UnitSystem::Imperial => ("fps", "grains", "inches"),
            UnitSystem::Metric => ("m/s", "grams", "mm"),
        };
        let mut lines = vec![
            "BC Estimation Results".to_string(),
            "=====================".to_string(),
            format!(
                "Inputs: v={} {}, m={} {}, d={} {}",
                velocity, vu, mass, mu, diameter, du
            ),
            String::new(),
            format!(
                "  {:<6} {:<20} {:>12}   {}",
                "Model", "Fit basis", "Estimated BC", "Fit RMS"
            ),
        ];
        // Guard the common mistake: a zeroed dope card (a point with ~0 drop) fed without
        // --zero-range, which makes the drop fit bore-referenced and returns a wrong BC.
        if zero_m.is_none()
            && drop_metric.iter().any(|(_, dr)| dr.abs() < 0.05)
            && drop_metric.iter().any(|(_, dr)| dr.abs() > 0.25)
        {
            let zd = drop_metric
                .iter()
                .min_by(|a, b| a.1.abs().partial_cmp(&b.1.abs()).unwrap())
                .map(|(d, _)| match units {
                    UnitSystem::Imperial => d / 0.9144,
                    UnitSystem::Metric => *d,
                })
                .unwrap_or(0.0);
            let du2 = if units == UnitSystem::Imperial {
                "yd"
            } else {
                "m"
            };
            lines.insert(
                0,
                format!(
                "⚠ Data looks zeroed near {zd:.0} {du2} but --zero-range not given; drop is being"
            ),
            );
            lines.insert(
                1,
                format!(
                    "  treated as bore-referenced. For a dope card, pass --zero-range {zd:.0}."
                ),
            );
            lines.insert(2, String::new());
        }

        let mut any_unreliable = false;
        for &model in &models {
            for &(mode, pts) in &bases {
                // Zero range only shapes a drop fit; a velocity fit is frame-independent.
                let zr = match mode {
                    BcFitMode::Drop => zero_m,
                    BcFitMode::Velocity => None,
                };
                let est = estimate_bc_fit(
                    velocity_mps,
                    mass_kg,
                    diameter_m,
                    pts,
                    model,
                    mode,
                    atmosphere.clone(),
                    zr,
                    sight_m,
                )
                .map_err(|e| JsValue::from_str(&format!("Error estimating BC: {}", e)))?;
                if est.at_bound {
                    any_unreliable = true;
                }
                let (rms_user, unit) = match mode {
                    BcFitMode::Drop => match units {
                        UnitSystem::Imperial => (est.rms_error / 0.0254, "in"),
                        UnitSystem::Metric => (est.rms_error * 1000.0, "mm"),
                    },
                    BcFitMode::Velocity => match units {
                        UnitSystem::Imperial => (est.rms_error / 0.3048, "fps"),
                        UnitSystem::Metric => (est.rms_error, "m/s"),
                    },
                };
                // 0.28.1 sweep: label every family by its actual name (DragModel's Display
                // is exactly its variant name), not a generic "G?" for anything past G1/G7.
                let model_name = model.to_string();
                let basis = match mode {
                    BcFitMode::Drop => "drop",
                    BcFitMode::Velocity => "velocity",
                };
                lines.push(format!(
                    "  {:<6} {:<20} {:>12.3}   {:>6.2} {:<4}{}",
                    model_name,
                    format!("{} ({} pts)", basis, pts.len()),
                    est.bc,
                    rms_user,
                    unit,
                    if est.at_bound {
                        " ⚠ UNRELIABLE (hit BC limit)"
                    } else {
                        ""
                    }
                ));
            }
        }
        if any_unreliable {
            lines.push(String::new());
            lines.push(
                "⚠ A fit ran to the BC search limit — the data did not determine a real"
                    .to_string(),
            );
            lines.push(
                "  value. Add more/longer-range points and check --zero-range / --temperature."
                    .to_string(),
            );
        }
        Ok(lines.join("\n"))
    }

    fn format_trajectory_table(
        &self,
        result: &crate::cli_api::TrajectoryResult,
        zero_distance: Option<f64>,
        units: UnitSystem,
        full: bool,
        los_height_m: f64,
        target_speed_mps: f64,
        ring_unit: RingDisplayUnit,
        // MBA-1403: None = historical LOS reference (byte-identical); Some(cos of the
        // shooting angle) = target-plane reference — drop values divided by it and the
        // Drop column relabeled "Drop (target)".
        target_drops_cos: Option<f64>,
        // MBA-1358: windage tracking CF for the Ring dial column (mover lead is a
        // dialed quantity, divided by the CF); /1.0 is bit-exact — byte-identical
        // without a CF.
        ring_windage_cf: f64,
    ) -> String {
        // Mover ring (MBA-1325): additive "Ring" column, only when --target-speed > 0.
        let ring_enabled = target_speed_mps > 0.0;
        // MBA-1355: header carries the unit — Ring(mil)/Ring(moa)/Ring(smoa)/Ring(iphy)/
        // Ring(clicks) — matching native's `ring_hdr` convention exactly (CLI_USAGE.md:
        // "the header/column suffix follows the same (mil)/(moa) convention as every
        // other unit — e.g. the mover Ring column reads Ring(clicks)").
        let ring_hdr_unit = match ring_unit {
            RingDisplayUnit::Factor(_, label) => label,
            RingDisplayUnit::Clicks(_) => "clicks",
        };
        let mut output = String::new();
        output.push_str("Trajectory Calculation Results\n");
        output.push_str("==============================\n\n");
        // MBA-1403: the Drop column header carries the active drops reference. The LOS
        // arm keeps the historical header bytes (which the ballistics.rs terminal's
        // chart parser arms on) untouched.
        let drop_hdr = if target_drops_cos.is_some() {
            "Drop (target)"
        } else {
            "Drop"
        };
        if ring_enabled {
            output.push_str(&format!(
                "Range | {} | Drift | Velocity | Energy | Time | Ring({})\n",
                drop_hdr, ring_hdr_unit
            ));
            output.push_str("------|------|-------|----------|--------|------|------\n");
        } else {
            output.push_str(&format!(
                "Range | {} | Drift | Velocity | Energy | Time\n",
                drop_hdr
            ));
            output.push_str("------|------|-------|----------|--------|------\n");
        }

        // Determine sampling interval based on max range and full flag
        let max_range_display = match units {
            UnitSystem::Imperial => result.max_range * 1.09361, // m to yards
            UnitSystem::Metric => result.max_range,
        };

        let sample_interval = if full {
            if max_range_display < 100.0 {
                10.0
            } else {
                25.0
            }
        } else {
            if max_range_display < 500.0 {
                50.0
            } else {
                100.0
            }
        };

        let mut current_range = 0.0;

        // The line of sight sits muzzle_height + sight_height above ground at EVERY
        // cant angle (the scope stays on the fixed LOS; the bore rotates around it).
        // Deriving it from points[0].y + sight_height double-counted the canted
        // bore's vertical rise sh*(1-cos c) — Bero's 90-degree report (MBA-1297):
        // reported drop was true miss + one full sight height.
        let los_height = los_height_m;

        for (idx, point) in result.points.iter().enumerate() {
            // McCoy coordinate system: X=downrange, Y=vertical, Z=lateral
            let range_display = match units {
                UnitSystem::Imperial => point.position.x * 1.09361, // X is downrange (McCoy), m to yards
                UnitSystem::Metric => point.position.x,             // X is downrange (McCoy)
            };

            let is_last_point = idx == result.points.len() - 1;

            // Show point if it's at the sampling interval OR if it's the last point OR if it's the zero distance
            let should_show = range_display >= current_range
                || is_last_point
                || (zero_distance.is_some()
                    && (range_display - zero_distance.unwrap()).abs() < 1.0);

            if should_show {
                // MBA-1403: /1.0 in LOS mode is bit-exact, so the default stays
                // byte-identical; target mode divides by cos(shooting angle).
                let drop = (los_height - point.position.y) / target_drops_cos.unwrap_or(1.0);
                let drift = point.position.z; // Z is lateral (windage, McCoy)
                let velocity = point.velocity_magnitude;

                // Format values based on unit system
                let (range_str, drop_str, drift_str, velocity_str, energy_str) = match units {
                    UnitSystem::Imperial => {
                        let energy_ftlb = 0.5
                            * (result.points[0].kinetic_energy / 0.5)
                            * (velocity / result.points[0].velocity_magnitude).powi(2)
                            * 0.737562149;
                        (
                            format!("{:.0} yd", range_display),
                            format!("{:.1} in", drop * 39.3701),
                            format!("{:.1} in", drift * 39.3701),
                            format!("{:.0} fps", velocity * 3.28084),
                            format!("{:.0} ft-lb", energy_ftlb),
                        )
                    }
                    UnitSystem::Metric => (
                        format!("{:.0} m", range_display),
                        format!("{:.1} cm", drop * 100.0),
                        format!("{:.1} cm", drift * 100.0),
                        format!("{:.0} m/s", velocity),
                        format!("{:.0} J", point.kinetic_energy),
                    ),
                };

                if ring_enabled {
                    let (_, ring_mil) = mover_ring(target_speed_mps, point.time, point.position.x);
                    // MBA-1358: divide the mil angle by the windage CF BEFORE
                    // unit/click conversion, mirroring native run_trajectory's Ring cell.
                    let ring_str = match ring_mil.map(|mil| mil / ring_windage_cf) {
                        Some(mil) => match ring_unit {
                            RingDisplayUnit::Factor(f, label) => {
                                format!("{:.2} {}", mil * f, label)
                            }
                            // clicks_for(drop_yd, range_yd, click) only needs the
                            // drop_yd/range_yd RATIO — passing (mil, 1000.0) reuses it
                            // directly on an already-computed mil angle (ring_mil is
                            // `ring_m / downrange_m * 1000`), same trick native's
                            // RingUnit::Clicks arm uses (main.rs run_trajectory).
                            RingDisplayUnit::Clicks(click) => {
                                format!("{}", crate::adjustment::clicks_for(mil, 1000.0, &click))
                            }
                        },
                        None => "-".to_string(),
                    };
                    output.push_str(&format!(
                        "{:6} | {:6} | {:7} | {:10} | {:8} | {:.3} s | {}\n",
                        range_str,
                        drop_str,
                        drift_str,
                        velocity_str,
                        energy_str,
                        point.time,
                        ring_str
                    ));
                } else {
                    output.push_str(&format!(
                        "{:6} | {:6} | {:7} | {:10} | {:8} | {:.3} s\n",
                        range_str, drop_str, drift_str, velocity_str, energy_str, point.time
                    ));
                }

                if range_display >= current_range {
                    current_range += sample_interval;
                }
            }
        }

        // Add summary
        output.push_str(&format!(
            "\nMax Range: {:.0} {}\n",
            if units == UnitSystem::Imperial {
                result.max_range * 1.09361
            } else {
                result.max_range
            },
            if units == UnitSystem::Imperial {
                "yards"
            } else {
                "meters"
            }
        ));

        // Check termination reason
        if let Some(last_point) = result.points.last() {
            // Debug info about last point
            // McCoy coordinate system: X=downrange, Y=vertical, Z=lateral
            let last_height = last_point.position.y;
            let last_range = last_point.position.x; // X is downrange (McCoy)
            let last_time = last_point.time;

            // Ground threshold is typically around 0.01m (1cm), so if y is close to or below that, it hit ground
            if last_height <= 0.01 {
                output.push_str(&format!(
                    "Bullet struck ground at {:.0} {}\n",
                    if units == UnitSystem::Imperial {
                        last_range * 1.09361
                    } else {
                        last_range
                    },
                    if units == UnitSystem::Imperial {
                        "yards"
                    } else {
                        "meters"
                    }
                ));
            } else if last_time >= 99.0 {
                output.push_str(&format!(
                    "Trajectory timeout at {:.0} {} (time limit reached)\n",
                    if units == UnitSystem::Imperial {
                        last_range * 1.09361
                    } else {
                        last_range
                    },
                    if units == UnitSystem::Imperial {
                        "yards"
                    } else {
                        "meters"
                    }
                ));
            }
        }

        output.push_str(&format!(
            "Max Height: {:.1} {}\n",
            if units == UnitSystem::Imperial {
                result.max_height * 39.3701
            } else {
                result.max_height * 100.0
            },
            if units == UnitSystem::Imperial {
                "inches"
            } else {
                "cm"
            }
        ));
        output.push_str(&format!(
            "Time of Flight: {:.2} seconds\n",
            result.time_of_flight
        ));
        output.push_str(&format!(
            "Impact Velocity: {:.0} {}\n",
            if units == UnitSystem::Imperial {
                result.impact_velocity * 3.28084
            } else {
                result.impact_velocity
            },
            if units == UnitSystem::Imperial {
                "fps"
            } else {
                "m/s"
            }
        ));

        output
    }

    /// MBA-1375's phase-one G1/G7 BC-family converter for the browser terminal.
    ///
    /// This method owns only argv parsing and display-unit conversion. The calculation,
    /// banded-family recommendation, JSON schema, and every output byte come from the shared
    /// `bc_conversion` module, exactly as on the native command surface.
    #[cfg(feature = "wasm-bc-convert")]
    fn handle_bc_convert_command(
        &self,
        args: &[&str],
        units: UnitSystem,
    ) -> Result<String, JsValue> {
        use crate::bc_conversion::{
            analyze_bc_segments, convert_bc_at_mach, convert_bc_at_velocity,
            format_bc_conversion_report, BcConversionFormat, BcConversionReportV1,
        };

        if args.iter().any(|arg| matches!(*arg, "-h" | "--help")) {
            return Ok(self.show_help());
        }

        let duplicate =
            |flag: &str| JsValue::from_str(&format!("{flag} cannot be used multiple times"));
        let parse_bounded = |value: &str, flag: &str, min: f64, max: f64| -> Result<f64, JsValue> {
            let parsed = parse_f64_arg(value, flag)?;
            if !parsed.is_finite() || parsed < min || parsed > max {
                return Err(JsValue::from_str(&format!(
                    "Invalid value '{value}' for {flag}: must be in range {min}..={max}"
                )));
            }
            Ok(parsed)
        };
        let parse_model = |value: &str, flag: &str| -> Result<DragModel, JsValue> {
            match value.to_ascii_lowercase().as_str() {
                "g1" => Ok(DragModel::G1),
                "g7" => Ok(DragModel::G7),
                _ => Err(JsValue::from_str(&format!(
                    "Invalid value '{value}' for {flag} (expected g1 or g7; phase one exposes only these models)"
                ))),
            }
        };

        let mut source_model = None;
        let mut target_model = None;
        let mut bc = None;
        let mut mach = None;
        let mut velocity = None;
        let mut segment_values: Vec<&str> = Vec::new();
        let mut speed_of_sound = None;
        let mut output = BcConversionFormat::Table;
        let mut output_seen = false;

        let mut i = 0;
        while i < args.len() {
            match args[i] {
                "--source-model" => {
                    if source_model.is_some() {
                        return Err(duplicate("--source-model"));
                    }
                    source_model = Some(parse_model(require_value(args, i)?, "--source-model")?);
                    i += 1;
                }
                "--target-model" => {
                    if target_model.is_some() {
                        return Err(duplicate("--target-model"));
                    }
                    target_model = Some(parse_model(require_value(args, i)?, "--target-model")?);
                    i += 1;
                }
                "-b" | "--bc" => {
                    if bc.is_some() {
                        return Err(duplicate("--bc"));
                    }
                    bc = Some(parse_bounded(require_value(args, i)?, "--bc", 0.001, 2.0)?);
                    i += 1;
                }
                "--mach" => {
                    if mach.is_some() {
                        return Err(duplicate("--mach"));
                    }
                    mach = Some(parse_bounded(require_value(args, i)?, "--mach", 0.0, 5.0)?);
                    i += 1;
                }
                "--velocity" => {
                    if velocity.is_some() {
                        return Err(duplicate("--velocity"));
                    }
                    velocity = Some(parse_bounded(
                        require_value(args, i)?,
                        "--velocity",
                        0.001,
                        6000.0,
                    )?);
                    i += 1;
                }
                "--bc-segment" => {
                    segment_values.push(require_value(args, i)?);
                    i += 1;
                }
                "--speed-of-sound" => {
                    if speed_of_sound.is_some() {
                        return Err(duplicate("--speed-of-sound"));
                    }
                    speed_of_sound = Some(parse_bounded(
                        require_value(args, i)?,
                        "--speed-of-sound",
                        0.001,
                        6000.0,
                    )?);
                    i += 1;
                }
                "-o" | "--output" => {
                    if output_seen {
                        return Err(duplicate("--output"));
                    }
                    output_seen = true;
                    output = match require_value(args, i)?.to_ascii_lowercase().as_str() {
                        "table" => BcConversionFormat::Table,
                        "json" => BcConversionFormat::Json,
                        "csv" => BcConversionFormat::Csv,
                        "pdf" => {
                            return Err(JsValue::from_str(
                                "bc-convert has no PDF form; use -o table, -o csv, or -o json",
                            ));
                        }
                        other => {
                            return Err(JsValue::from_str(&format!(
                                "Invalid output format '{other}' for bc-convert (expected table, json, or csv)"
                            )));
                        }
                    };
                    i += 1;
                }
                other => {
                    return Err(JsValue::from_str(&format!(
                        "unexpected bc-convert argument '{other}'"
                    )));
                }
            }
            i += 1;
        }

        let source_model = source_model
            .ok_or_else(|| JsValue::from_str("--source-model is required for bc-convert"))?;
        let target_model = target_model
            .ok_or_else(|| JsValue::from_str("--target-model is required for bc-convert"))?;
        let velocity_to_fps = match units {
            UnitSystem::Imperial => 1.0,
            UnitSystem::Metric => 3.280_839_895,
        };
        let speed_of_sound_fps = speed_of_sound.map_or_else(
            || crate::constants::SPEED_OF_SOUND_MPS / crate::constants::FPS_TO_MPS,
            |value| value * velocity_to_fps,
        );

        let report = match (bc, segment_values.is_empty()) {
            (Some(_), false) => {
                return Err(JsValue::from_str("--bc cannot be used with --bc-segment"));
            }
            (None, true) => {
                return Err(JsValue::from_str(
                    "bc-convert requires exactly one of --bc or --bc-segment",
                ));
            }
            (Some(source_bc), true) => {
                if speed_of_sound.is_some() && mach.is_some() {
                    return Err(JsValue::from_str(
                        "--speed-of-sound cannot be used with --mach",
                    ));
                }
                let result = match (mach, velocity) {
                    (Some(mach), None) => {
                        convert_bc_at_mach(source_bc, source_model, target_model, mach)
                    }
                    (None, Some(velocity)) => convert_bc_at_velocity(
                        source_bc,
                        source_model,
                        target_model,
                        velocity * velocity_to_fps,
                        speed_of_sound_fps,
                    ),
                    _ => {
                        return Err(JsValue::from_str(
                            "scalar conversion requires exactly one of --mach or --velocity",
                        ));
                    }
                }
                .map_err(|error| JsValue::from_str(&error.to_string()))?;
                BcConversionReportV1::Scalar { result }
            }
            (None, false) => {
                if mach.is_some() || velocity.is_some() {
                    return Err(JsValue::from_str(
                        "--bc-segment cannot be used with --mach or --velocity",
                    ));
                }

                let mut segments = Vec::with_capacity(segment_values.len());
                for value in segment_values {
                    let fields: Vec<&str> = value.split(':').collect();
                    if fields.len() != 3 {
                        return Err(JsValue::from_str(&format!(
                            "--bc-segment expects VMIN:VMAX:BC (e.g. 1500:1800:0.243), got '{value}'"
                        )));
                    }
                    let vmin = parse_f64_arg(fields[0].trim(), "--bc-segment VMIN")?;
                    let vmax = parse_f64_arg(fields[1].trim(), "--bc-segment VMAX")?;
                    let segment_bc = parse_f64_arg(fields[2].trim(), "--bc-segment BC")?;
                    if !vmin.is_finite()
                        || !vmax.is_finite()
                        || vmin.partial_cmp(&vmax) != Some(std::cmp::Ordering::Less)
                    {
                        return Err(JsValue::from_str(&format!(
                            "--bc-segment VMIN must be finite and less than VMAX in '{value}'"
                        )));
                    }
                    if !segment_bc.is_finite() || segment_bc <= 0.0 {
                        return Err(JsValue::from_str(&format!(
                            "--bc-segment BC must be finite and greater than zero in '{value}'"
                        )));
                    }
                    segments.push(crate::BCSegmentData {
                        velocity_min: vmin * velocity_to_fps,
                        velocity_max: vmax * velocity_to_fps,
                        bc_value: segment_bc,
                    });
                }

                let candidates = [DragModel::G1, DragModel::G7];
                let result = analyze_bc_segments(
                    &segments,
                    source_model,
                    target_model,
                    &candidates,
                    speed_of_sound_fps,
                )
                .map_err(|error| JsValue::from_str(&error.to_string()))?;
                BcConversionReportV1::Banded { result }
            }
        };

        format_bc_conversion_report(&report, output)
            .map_err(|error| JsValue::from_str(&error.to_string()))
    }

    /// `drag-curve` in the browser terminal (MBA-1426 item 2, requested alongside MBA-1427 by
    /// the same external consumer — the reference curve his effective Cd curve is plotted
    /// against).
    ///
    /// All formatting comes from `drag::format_reference_drag_curve`, the SAME function the
    /// native CLI prints, so the two surfaces emit identical bytes and cannot drift the way the
    /// recoil CSV header did (MBA-1418). This handler only parses arguments and picks the form.
    ///
    /// Unknown arguments are a hard error, matching native clap behaviour — not this parser's
    /// older silently-ignore convention, which is the exact "flag that does nothing without
    /// saying so" class the last two releases spent effort closing.
    #[cfg(feature = "wasm-drag-curve")]
    fn handle_drag_curve_command(args: &[&str]) -> Result<String, JsValue> {
        let mut drag_model = DragModel::G7; // native's default
        let mut output = "table".to_string();

        let mut i = 0;
        while i < args.len() {
            match args[i] {
                "--drag-model" => {
                    if i + 1 >= args.len() {
                        return Err(JsValue::from_str("--drag-model requires a value"));
                    }
                    drag_model = DragModel::from_str(args[i + 1]).ok_or_else(|| {
                        JsValue::from_str(&format!(
                            "'{}' is not a recognized drag model (g1, g2, g5, g6, g7, g8, gi, \
                             gs, ra4)",
                            args[i + 1]
                        ))
                    })?;
                    i += 1;
                }
                "-o" | "--output" => {
                    if i + 1 >= args.len() {
                        return Err(JsValue::from_str("--output requires a value"));
                    }
                    output = args[i + 1].to_lowercase();
                    i += 1;
                }
                other => {
                    return Err(JsValue::from_str(&format!(
                        "Unknown drag-curve argument '{other}'"
                    )));
                }
            }
            i += 1;
        }

        let format = match output.as_str() {
            "table" => crate::drag::ReferenceDragCurveFormat::Table,
            "csv" => crate::drag::ReferenceDragCurveFormat::Csv,
            "json" => crate::drag::ReferenceDragCurveFormat::Json,
            // The PDF message is reserved for someone who actually asked for PDF (matching
            // native's rejection text); any other junk gets this surface's own invalid-format
            // convention. Telling `-o yaml` that "PDF has no form" blamed a format the user
            // never mentioned — caught in review.
            "pdf" => {
                return Err(JsValue::from_str(
                    "drag-curve has no PDF form; use -o table, -o csv, or -o json",
                ));
            }
            other => {
                return Err(JsValue::from_str(&format!(
                    "Invalid output format '{other}' for drag-curve (expected table, json, or csv)"
                )));
            }
        };

        Ok(crate::drag::format_reference_drag_curve(
            &drag_model,
            format,
        ))
    }

    /// `reticle` in the browser terminal (MBA-1361).
    ///
    /// Renders through the SAME `reticle::format_reticle_*` functions the native CLI uses,
    /// so identical inputs produce byte-identical output on both surfaces.
    ///
    /// **The one deliberate difference from native is the reticle SOURCE.** There is no
    /// filesystem here, so `--reticle-json` takes the description as an inline JSON STRING
    /// rather than a path — the same text-not-files split `drag_file`/`loadDragTable`
    /// already use. `--profile` does not exist here either (saved profiles are a native-only
    /// concept), and `reticle hold --range` is native-only: the browser terminal takes the
    /// angular solution directly with `--drop-mil`/`--wind-mil`, which is what `trajectory`
    /// above already prints. That gap is documented in CLI_USAGE and tracked with the
    /// MBA-1362 WASM-parity follow-up.
    #[cfg(feature = "wasm-reticle")]
    fn handle_reticle_command(args: &[&str]) -> Result<String, JsValue> {
        use crate::reticle::{
            format_reticle_description, format_reticle_hold, hold_point_in_reticle, FocalPlane,
            ReticleDescription, ReticleFormat,
        };

        let Some(verb) = args.first() else {
            return Err(JsValue::from_str(
                "reticle requires a subcommand: hold or generate",
            ));
        };
        let rest = &args[1..];

        // `-o`/`--output` and the generator's shared options are parsed the same way for
        // every verb, so pull them out with one helper each time.
        let parse_format = |token: &str| -> Result<ReticleFormat, JsValue> {
            match token.to_lowercase().as_str() {
                "table" => Ok(ReticleFormat::Table),
                "json" => Ok(ReticleFormat::Json),
                other => Err(JsValue::from_str(&format!(
                    "Invalid output format '{other}' for reticle (expected table or json)"
                ))),
            }
        };

        match *verb {
            "generate" => {
                let Some(layout) = rest.first() else {
                    return Err(JsValue::from_str(
                        "reticle generate requires a layout: mil-grid, tree, or bdc",
                    ));
                };
                let layout_args = &rest[1..];

                let mut spacing = 1.0_f64;
                let mut extent = 10.0_f64;
                let mut rows = 5_usize;
                let mut row_spacing = 1.0_f64;
                let mut spread_step = 0.5_f64;
                let mut drops: Vec<(f64, f64)> = Vec::new();
                let mut name: Option<String> = None;
                let mut focal_plane = FocalPlane::First;
                let mut reference_mag = 1.0_f64;
                let mut format = ReticleFormat::Table;

                let mut i = 0;
                while i < layout_args.len() {
                    match layout_args[i] {
                        "--spacing" => {
                            spacing = parse_f64_arg(require_value(layout_args, i)?, "--spacing")?;
                            i += 1;
                        }
                        "--extent" => {
                            extent = parse_f64_arg(require_value(layout_args, i)?, "--extent")?;
                            i += 1;
                        }
                        "--rows" => {
                            let value = parse_f64_arg(require_value(layout_args, i)?, "--rows")?;
                            if !value.is_finite() || value < 1.0 || value.fract() != 0.0 {
                                return Err(JsValue::from_str(
                                    "--rows must be a whole number of at least 1",
                                ));
                            }
                            rows = value as usize;
                            i += 1;
                        }
                        "--row-spacing" => {
                            row_spacing =
                                parse_f64_arg(require_value(layout_args, i)?, "--row-spacing")?;
                            i += 1;
                        }
                        "--spread-step" => {
                            spread_step =
                                parse_f64_arg(require_value(layout_args, i)?, "--spread-step")?;
                            i += 1;
                        }
                        "--drop" => {
                            let token = require_value(layout_args, i)?;
                            let parts: Vec<&str> = token.split(':').collect();
                            if parts.len() != 2 {
                                return Err(JsValue::from_str(&format!(
                                    "invalid --drop '{token}': expected RANGE:DROP_MIL"
                                )));
                            }
                            let range = parse_f64_arg(parts[0], "--drop range")?;
                            let drop_mil = parse_f64_arg(parts[1], "--drop value")?;
                            drops.push((range, drop_mil));
                            i += 1;
                        }
                        "--name" => {
                            name = Some(require_value(layout_args, i)?.to_string());
                            i += 1;
                        }
                        "--focal-plane" => {
                            focal_plane =
                                match require_value(layout_args, i)?.to_lowercase().as_str() {
                                    "ffp" => FocalPlane::First,
                                    "sfp" => FocalPlane::Second,
                                    other => {
                                        return Err(JsValue::from_str(&format!(
                                            "invalid --focal-plane '{other}' (expected ffp or sfp)"
                                        )))
                                    }
                                };
                            i += 1;
                        }
                        "--reference-mag" => {
                            reference_mag =
                                parse_f64_arg(require_value(layout_args, i)?, "--reference-mag")?;
                            i += 1;
                        }
                        "-o" | "--output" => {
                            format = parse_format(require_value(layout_args, i)?)?;
                            i += 1;
                        }
                        other => {
                            return Err(JsValue::from_str(&format!(
                                "Unknown reticle generate argument '{other}'"
                            )));
                        }
                    }
                    i += 1;
                }

                let mut description = match layout {
                    &"mil-grid" => ReticleDescription::mil_grid(spacing, extent),
                    &"tree" => ReticleDescription::tree(rows, row_spacing, spread_step),
                    &"bdc" => {
                        if drops.is_empty() {
                            return Err(JsValue::from_str(
                                "reticle generate bdc requires at least one --drop RANGE:DROP_MIL",
                            ));
                        }
                        ReticleDescription::bdc_from_drops(&drops)
                    }
                    other => {
                        return Err(JsValue::from_str(&format!(
                            "Unknown reticle layout '{other}' (expected mil-grid, tree, or bdc)"
                        )))
                    }
                }
                .map_err(|e| JsValue::from_str(&e.to_string()))?;

                description.focal_plane = focal_plane;
                description.reference_magnification = reference_mag;
                if let Some(name) = name {
                    description.name = name;
                }
                description
                    .validate()
                    .map_err(|e| JsValue::from_str(&e.to_string()))?;
                Ok(format_reticle_description(&description, format))
            }

            "hold" => {
                let mut reticle_json: Option<String> = None;
                let mut drop_mil: Option<f64> = None;
                let mut wind_mil = 0.0_f64;
                let mut mag = 10.0_f64;
                let mut format = ReticleFormat::Table;

                let mut i = 0;
                while i < rest.len() {
                    match rest[i] {
                        "--reticle-json" => {
                            reticle_json = Some(require_value(rest, i)?.to_string());
                            i += 1;
                        }
                        "--drop-mil" => {
                            drop_mil = Some(parse_f64_arg(require_value(rest, i)?, "--drop-mil")?);
                            i += 1;
                        }
                        "--wind-mil" => {
                            wind_mil = parse_f64_arg(require_value(rest, i)?, "--wind-mil")?;
                            i += 1;
                        }
                        "--mag" => {
                            mag = parse_f64_arg(require_value(rest, i)?, "--mag")?;
                            i += 1;
                        }
                        "-o" | "--output" => {
                            format = parse_format(require_value(rest, i)?)?;
                            i += 1;
                        }
                        "--range" => {
                            return Err(JsValue::from_str(
                                "reticle hold --range is native-only in this build; run \
                                 `trajectory` to read the drop in mils and pass it with \
                                 --drop-mil",
                            ));
                        }
                        "--profile" => {
                            return Err(JsValue::from_str(
                                "the browser terminal has no saved profiles; pass the reticle \
                                 inline with --reticle-json '<JSON>'",
                            ));
                        }
                        other => {
                            return Err(JsValue::from_str(&format!(
                                "Unknown reticle hold argument '{other}'"
                            )));
                        }
                    }
                    i += 1;
                }

                let Some(text) = reticle_json else {
                    return Err(JsValue::from_str(
                        "reticle hold requires --reticle-json '<JSON>' (the description itself, \
                         not a path — this build has no filesystem)",
                    ));
                };
                let Some(drop_mil) = drop_mil else {
                    return Err(JsValue::from_str("reticle hold requires --drop-mil <MIL>"));
                };
                let description: ReticleDescription = serde_json::from_str(&text)
                    .map_err(|e| JsValue::from_str(&format!("invalid reticle JSON: {e}")))?;
                description
                    .validate()
                    .map_err(|e| JsValue::from_str(&format!("invalid reticle: {e}")))?;
                let hold = hold_point_in_reticle(drop_mil, wind_mil, mag, &description)
                    .map_err(|e| JsValue::from_str(&e.to_string()))?;
                Ok(format_reticle_hold(&hold, &description, mag, format))
            }

            other => Err(JsValue::from_str(&format!(
                "Unknown reticle subcommand '{other}' (expected hold or generate)"
            ))),
        }
    }

    fn format_trajectory_json(
        &self,
        result: &crate::cli_api::TrajectoryResult,
        units: UnitSystem,
        los_height_m: f64,
        target_speed_mps: f64,
        zero_angle_degrees: Option<f64>,
        with_drag_coefficient: bool,
        // MBA-1403: None = LOS reference (byte-identical); Some(cos) = target plane —
        // drop values divided by it, and the legend's drop axis says so. Keys unchanged.
        target_drops_cos: Option<f64>,
        // MBA-1358: windage tracking CF for mover_ring_mil (dial-unit, divided by
        // the CF); mover_ring_m stays raw meters. /1.0 is bit-exact.
        ring_windage_cf: f64,
    ) -> String {
        // LOS height is cant-invariant (see format_trajectory_table).
        let los_height = los_height_m;
        // /1.0 in LOS mode is bit-exact — default output stays byte-identical.
        let drop_denominator = target_drops_cos.unwrap_or(1.0);
        // Mover ring (MBA-1325): additive fields, only when --target-speed > 0. Units are
        // in the field names (mover_ring_m is always meters, MBA-1315 hygiene) regardless
        // of --units, matching the native CLI's `-o json` per-point contract.
        let ring_enabled = target_speed_mps > 0.0;
        // McCoy coordinate system: X=downrange, Y=vertical, Z=lateral
        let points: Vec<serde_json::Value> = result
            .points
            .iter()
            .map(|p| {
                let mut point = match units {
                    UnitSystem::Imperial => {
                        serde_json::json!({
                            "range_yards": p.position.x * 1.09361,  // X is downrange (McCoy)
                            "drop_inches": (los_height - p.position.y) / drop_denominator * 39.3701,
                            "drift_inches": p.position.z * 39.3701,  // Z is lateral (windage, McCoy)
                            "velocity_fps": p.velocity_magnitude * 3.28084,
                            "energy_ftlb": p.kinetic_energy * 0.737562149,
                            "time_seconds": p.time
                        })
                    }
                    UnitSystem::Metric => {
                        serde_json::json!({
                            "range_meters": p.position.x,  // X is downrange (McCoy)
                            "drop_cm": (los_height - p.position.y) / drop_denominator * 100.0,
                            "drift_cm": p.position.z * 100.0,  // Z is lateral (windage, McCoy)
                            "velocity_mps": p.velocity_magnitude,
                            "energy_joules": p.kinetic_energy,
                            "time_seconds": p.time
                        })
                    }
                };
                if ring_enabled {
                    let (ring_m, ring_mil) = mover_ring(target_speed_mps, p.time, p.position.x);
                    if let Some(obj) = point.as_object_mut() {
                        obj.insert("mover_ring_m".to_string(), serde_json::json!(ring_m));
                        // MBA-1358: dialed quantity — divided by the windage CF
                        // (/1.0 exact).
                        if let Some(mil) = ring_mil {
                            obj.insert(
                                "mover_ring_mil".to_string(),
                                serde_json::json!(mil / ring_windage_cf),
                            );
                        }
                    }
                }
                // MBA-1427: the projectile's own Cd, straight off the point the shared solver
                // annotated — NOT re-derived here, which would reintroduce exactly the drift
                // this feature exists to prevent. Additive and flag-gated so default JSON is
                // byte-identical; absent (not null) when sectional density is unknown, matching
                // native's skip_serializing_if shape. Dimensionless, so identical under both
                // unit systems.
                if let Some(cd) = p.drag_coefficient_json_value(with_drag_coefficient) {
                    if let Some(obj) = point.as_object_mut() {
                        obj.insert("drag_coefficient".to_string(), serde_json::json!(cd));
                    }
                }
                point
            })
            .collect();

        let summary = match units {
            UnitSystem::Imperial => {
                serde_json::json!({
                    "max_range_yards": result.max_range * 1.09361,
                    "max_height_inches": result.max_height * 39.3701,
                    "time_of_flight_seconds": result.time_of_flight,
                    "impact_velocity_fps": result.impact_velocity * 3.28084
                })
            }
            UnitSystem::Metric => {
                serde_json::json!({
                    "max_range_meters": result.max_range,
                    "max_height_cm": result.max_height * 100.0,
                    "time_of_flight_seconds": result.time_of_flight,
                    "impact_velocity_mps": result.impact_velocity
                })
            }
        };

        let mut output = serde_json::json!({
            "trajectory": points,
            "summary": summary,
            "legend": trajectory_json_legend(units, target_drops_cos.is_some()),
        });
        // MBA-1402 parity: top-level and present only when auto-zero actually ran, matching
        // native's `skip_serializing_if` shape. Absent — not null — on a bare --angle run, so a
        // consumer that never uses auto-zero sees a byte-identical document.
        if let Some(degrees) = zero_angle_degrees {
            output["zero_angle_degrees"] = serde_json::json!(degrees);
        }

        serde_json::to_string_pretty(&output)
            .unwrap_or_else(|_| "Error formatting JSON".to_string())
    }

    /// MBA-1433: the terminal's second CSV form — native's `metric,value,unit` summary
    /// document, reachable with `--csv-summary`.
    ///
    /// Native's trajectory CSV has always had two shapes and picks between them with
    /// `--full`; the browser's `--full` sets sampling density instead, so until this flag
    /// existed the summary shape had no spelling here at all and every field that lives only
    /// in it — `zero_angle_degrees` above all, which is what an external consumer reported
    /// missing — was structurally unreachable from a browser build. Injecting those rows into
    /// the point table instead would have corrupted it for everyone parsing it, so this is a
    /// separate document, not a header.
    ///
    /// The rows are native's, byte for byte: same names, same order, same precision, and
    /// deliberately native's own conversion factors (`/0.3048` for velocity, `*0.737562` for
    /// energy) rather than the slightly different ones the point-table rows above use —
    /// `UnitConverter::*_from_metric` is what produces native's bytes, and a summary that
    /// disagreed with native in the last digit would be a worse answer than no summary.
    /// `max_height` is in yards/meters here and inches/centimeters in the point table for
    /// the same reason: that is native's contract for this document.
    ///
    /// Two of native's conditional rows are NOT emitted: `stability_coefficient` and
    /// `spin_drift`. Native derives both from the station temperature/pressure it resolved
    /// for the solve, and this surface hands the unresolved atmosphere to the solver's own
    /// constructor and never sees those resolved values; re-deriving them here would print a
    /// number that disagrees with native's. The browser surface reports neither quantity in
    /// its table or JSON forms either, so this document is not alone in omitting them — it is
    /// a parity gap of its own, not something this flag silently dropped.
    fn format_trajectory_csv_summary(
        result: &crate::cli_api::TrajectoryResult,
        units: UnitSystem,
        zero_angle_degrees: Option<f64>,
    ) -> String {
        let (dist_unit, vel_unit, energy_unit) = match units {
            UnitSystem::Metric => ("m", "m/s", "J"),
            UnitSystem::Imperial => ("yd", "fps", "ft-lb"),
        };
        // Native `UnitConverter::{distance,velocity,energy}_from_metric`, inlined because
        // that type is native-only (main.rs). Metric passes straight through. Written as
        // native writes them — two divisions and one multiplication — because `x / 0.9144`
        // and `x * (1.0 / 0.9144)` are not the same f64, and this document's whole point is
        // matching native's bytes.
        let distance = |v: f64| match units {
            UnitSystem::Metric => v,
            UnitSystem::Imperial => v / 0.9144,
        };
        let velocity = |v: f64| match units {
            UnitSystem::Metric => v,
            UnitSystem::Imperial => v / 0.3048,
        };
        let energy = |v: f64| match units {
            UnitSystem::Metric => v,
            UnitSystem::Imperial => v * 0.737562,
        };

        let mut output = String::new();
        output.push_str("metric,value,unit\n");
        output.push_str(&format!(
            "max_range,{:.2},{}\n",
            distance(result.max_range),
            dist_unit
        ));
        output.push_str(&format!(
            "max_height,{:.2},{}\n",
            distance(result.max_height),
            dist_unit
        ));
        output.push_str(&format!("time_of_flight,{:.4},s\n", result.time_of_flight));
        output.push_str(&format!(
            "impact_velocity,{:.2},{}\n",
            velocity(result.impact_velocity),
            vel_unit
        ));
        output.push_str(&format!(
            "impact_energy,{:.2},{}\n",
            energy(result.impact_energy),
            energy_unit
        ));
        // Present only when --auto-zero actually solved an angle, exactly as native's row is
        // (and as the JSON form's top-level field is, MBA-1402).
        if let Some(degrees) = zero_angle_degrees {
            output.push_str(&format!("zero_angle_degrees,{:.4},degrees\n", degrees));
        }
        output
    }

    fn format_trajectory_csv(
        &self,
        result: &crate::cli_api::TrajectoryResult,
        units: UnitSystem,
        full: bool,
        los_height_m: f64,
        target_speed_mps: f64,
        // MBA-1403: None = LOS reference (byte-identical); Some(cos) = target plane —
        // drop values divided by it, Drop column header relabeled Drop_target. This
        // function stays rows-only on purpose: the summary form is a SEPARATE document
        // ([`format_trajectory_csv_summary`], `--csv-summary`), because summary rows mixed
        // into the point table would break a consumer reading it as one uniform table —
        // which is how native keeps them apart too (MBA-1433).
        target_drops_cos: Option<f64>,
        // MBA-1358: windage tracking CF for the ring_mil column (divided by the CF);
        // /1.0 is bit-exact.
        ring_windage_cf: f64,
    ) -> String {
        let mut output = String::new();
        // Mover ring (MBA-1325): extra column, header carries the unit; only emitted
        // when --target-speed enabled it (additive, matches table/JSON).
        let ring_enabled = target_speed_mps > 0.0;

        // Header
        let target_drops = target_drops_cos.is_some();
        match units {
            UnitSystem::Imperial => {
                if target_drops {
                    output.push_str("Range(yards),Drop_target(inches),Drift(inches),Velocity(fps),Energy(ft-lb),Time(seconds)");
                } else {
                    output.push_str("Range(yards),Drop(inches),Drift(inches),Velocity(fps),Energy(ft-lb),Time(seconds)");
                }
            }
            UnitSystem::Metric => {
                if target_drops {
                    output.push_str(
                        "Range(meters),Drop_target(cm),Drift(cm),Velocity(m/s),Energy(joules),Time(seconds)",
                    );
                } else {
                    output.push_str(
                        "Range(meters),Drop(cm),Drift(cm),Velocity(m/s),Energy(joules),Time(seconds)",
                    );
                }
            }
        }
        if ring_enabled {
            output.push_str(",Ring(mil)\n");
        } else {
            output.push('\n');
        }

        // Determine sampling interval
        let max_range_display = match units {
            UnitSystem::Imperial => result.max_range * 1.09361,
            UnitSystem::Metric => result.max_range,
        };

        let sample_interval = if full {
            if max_range_display < 100.0 {
                10.0
            } else {
                25.0
            }
        } else {
            if max_range_display < 500.0 {
                50.0
            } else {
                100.0
            }
        };

        let mut current_range = 0.0;
        // LOS height is cant-invariant (see format_trajectory_table).
        let los_height = los_height_m;

        for (idx, point) in result.points.iter().enumerate() {
            // McCoy coordinate system: X=downrange, Y=vertical, Z=lateral
            let range_display = match units {
                UnitSystem::Imperial => point.position.x * 1.09361, // X is downrange (McCoy)
                UnitSystem::Metric => point.position.x,             // X is downrange (McCoy)
            };

            let is_last_point = idx == result.points.len() - 1;

            if range_display >= current_range || is_last_point {
                // MBA-1403: /1.0 in LOS mode is bit-exact — default stays byte-identical.
                let drop = (los_height - point.position.y) / target_drops_cos.unwrap_or(1.0);

                let row = match units {
                    UnitSystem::Imperial => {
                        let energy_ftlb = point.kinetic_energy * 0.737562149;
                        format!(
                            "{:.1},{:.2},{:.2},{:.0},{:.0},{:.3}",
                            range_display,
                            drop * 39.3701,
                            point.position.z * 39.3701, // Z is lateral (windage, McCoy)
                            point.velocity_magnitude * 3.28084,
                            energy_ftlb,
                            point.time
                        )
                    }
                    UnitSystem::Metric => format!(
                        "{:.1},{:.2},{:.2},{:.0},{:.0},{:.3}",
                        range_display,
                        drop * 100.0,
                        point.position.z * 100.0, // Z is lateral (windage, McCoy)
                        point.velocity_magnitude,
                        point.kinetic_energy,
                        point.time
                    ),
                };
                if ring_enabled {
                    // Downrange is position.x (McCoy frame) regardless of the CSV's
                    // lateral/downrange column swap above.
                    let (_, ring_mil) = mover_ring(target_speed_mps, point.time, point.position.x);
                    match ring_mil {
                        // MBA-1358: dialed quantity — divided by the windage CF
                        // (/1.0 exact).
                        Some(mil) => {
                            output.push_str(&format!("{},{:.3}\n", row, mil / ring_windage_cf))
                        }
                        None => output.push_str(&format!("{},\n", row)),
                    }
                } else {
                    output.push_str(&format!("{}\n", row));
                }

                if range_display >= current_range {
                    current_range += sample_interval;
                }
            }
        }

        output
    }

    /// MBA-737: standalone powder-temperature velocity resolution — native `powder`
    /// command parity. The physics rides the same shared
    /// `resolve_powder_adjusted_velocity` the trajectory/lead solvers call. NOTE:
    /// this command always applies the linear model, while trajectory/lead gate it
    /// behind --use-powder-sensitivity (a curve applies there unconditionally).
    /// Output (table/json/csv) is returned as the terminal string.
    #[cfg(feature = "wasm-powder")]
    fn handle_powder_command(&self, args: &[&str], units: UnitSystem) -> Result<String, JsValue> {
        use crate::cli_api::{parse_powder_sweep, resolve_powder_adjusted_velocity};

        let mut velocity: Option<f64> = None;
        let mut temperature: Option<f64> = None;
        let mut powder_temp_sensitivity: Option<f64> = None;
        let mut powder_temp: Option<f64> = None;
        let mut powder_temp_curve_str: Option<String> = None;
        let mut sweep_str: Option<String> = None;
        let mut mass: Option<f64> = None;
        let mut out_fmt = "table";

        // Parse arguments
        let mut i = 0;
        while i < args.len() {
            match args[i] {
                "-v" | "--velocity" => {
                    if i + 1 < args.len() {
                        velocity = Some(
                            args[i + 1]
                                .parse()
                                .map_err(|_| JsValue::from_str("Invalid velocity"))?,
                        );
                        i += 1;
                    }
                }
                "--temperature" => {
                    if i + 1 < args.len() {
                        temperature = Some(
                            args[i + 1]
                                .parse()
                                .map_err(|_| JsValue::from_str("Invalid temperature"))?,
                        );
                        i += 1;
                    }
                }
                "--powder-temp-sensitivity" => {
                    if i + 1 < args.len() {
                        powder_temp_sensitivity =
                            Some(args[i + 1].parse().map_err(|_| {
                                JsValue::from_str("Invalid powder temp sensitivity")
                            })?);
                        i += 1;
                    }
                }
                "--powder-temp" => {
                    if i + 1 < args.len() {
                        powder_temp = Some(
                            args[i + 1]
                                .parse()
                                .map_err(|_| JsValue::from_str("Invalid powder temperature"))?,
                        );
                        i += 1;
                    }
                }
                "--powder-temp-curve" => {
                    if i + 1 < args.len() {
                        powder_temp_curve_str = Some(args[i + 1].to_string());
                        i += 1;
                    }
                }
                "--sweep" => {
                    if i + 1 < args.len() {
                        sweep_str = Some(args[i + 1].to_string());
                        i += 1;
                    }
                }
                "-m" | "--mass" => {
                    if i + 1 < args.len() {
                        mass = Some(
                            args[i + 1]
                                .parse()
                                .map_err(|_| JsValue::from_str("Invalid mass"))?,
                        );
                        i += 1;
                    }
                }
                "-o" | "--output" => {
                    if i + 1 < args.len() {
                        out_fmt = args[i + 1];
                        i += 1;
                    }
                }
                _ => {}
            }
            i += 1;
        }
        if !matches!(out_fmt, "table" | "json" | "csv") {
            return Err(JsValue::from_str(
                "Invalid output format for powder (expected table, json, or csv)",
            ));
        }
        // Same numeric ranges the native clap definition enforces (f64_range).
        if let Some(v) = velocity {
            if !(0.0..=6000.0).contains(&v) {
                return Err(JsValue::from_str("Velocity must be between 0 and 6000"));
            }
        }
        if let Some(m) = mass {
            if !(0.1..=2000.0).contains(&m) {
                return Err(JsValue::from_str("Mass must be between 0.1 and 2000"));
            }
        }

        // SI conversions — identical factors to the native handler.
        let powder_temp_curve_si: Option<Vec<(f64, f64)>> = match powder_temp_curve_str.as_deref() {
            Some(s) => Some(parse_powder_temp_curve_str(s, units)?),
            None => None,
        };
        let has_curve = powder_temp_curve_si.as_ref().is_some_and(|c| !c.is_empty());
        let curve_ref = powder_temp_curve_si.as_deref();

        let to_temp_c = |t: f64| match units {
            UnitSystem::Imperial => (t - 32.0) * 5.0 / 9.0,
            UnitSystem::Metric => t,
        };
        let from_temp_c = |t: f64| match units {
            UnitSystem::Imperial => t * 9.0 / 5.0 + 32.0,
            UnitSystem::Metric => t,
        };
        let to_vel_si = |v: f64| match units {
            UnitSystem::Imperial => v * 0.3048,
            UnitSystem::Metric => v,
        };
        let from_vel_si = |v: f64| match units {
            UnitSystem::Imperial => v / 0.3048,
            UnitSystem::Metric => v,
        };

        let sens_display = powder_temp_sensitivity.unwrap_or(match units {
            UnitSystem::Imperial => 1.0,
            UnitSystem::Metric => 0.3048 / (5.0 / 9.0),
        });
        // fps/degF -> m/s/degC (imperial): velocity factor over the delta-degree factor.
        let sens_si = match units {
            UnitSystem::Imperial => sens_display * 0.3048 / (5.0 / 9.0),
            UnitSystem::Metric => sens_display,
        };
        let ref_temp_c = powder_temp
            .map(to_temp_c)
            .unwrap_or(crate::constants::DEFAULT_POWDER_REFERENCE_TEMP_C);
        let velocity_si = velocity.map(to_vel_si);
        let mass_kg: Option<f64> = mass.map(|m| match units {
            UnitSystem::Imperial => m * crate::constants::GRAINS_TO_KG,
            UnitSystem::Metric => m * 0.001,
        });

        // Validation — same rules and messages as the native handler.
        if !has_curve && velocity.is_none() {
            return Err(JsValue::from_str(
                "--velocity is required for the linear model (or supply --powder-temp-curve)",
            ));
        }
        let sweep_temps: Option<Vec<f64>> = match sweep_str.as_deref() {
            Some(s) => Some(parse_powder_sweep(s).map_err(|e| JsValue::from_str(&e))?),
            None => None,
        };
        if sweep_temps.is_none() {
            if !has_curve && temperature.is_none() {
                return Err(JsValue::from_str(
                    "--temperature is required (the shot-day air temperature), or use --sweep",
                ));
            }
            if has_curve && powder_temp.is_none() && temperature.is_none() {
                return Err(JsValue::from_str(
                    "--powder-temp or --temperature is required with --powder-temp-curve, or use --sweep",
                ));
            }
        }

        let resolve_at_c = |temp_c: f64| -> f64 {
            resolve_powder_adjusted_velocity(
                velocity_si.unwrap_or(0.0),
                temp_c,
                !has_curve,
                sens_si,
                ref_temp_c,
                curve_ref,
                None,
            )
        };
        let energy_at = |v_mps: f64| -> Option<f64> {
            mass_kg.map(|m| {
                let e_j = 0.5 * m * v_mps * v_mps;
                match units {
                    UnitSystem::Imperial => e_j * 0.737562, // Joules to ft-lbs
                    UnitSystem::Metric => e_j,
                }
            })
        };
        let (vel_unit, temp_unit, energy_unit) = match units {
            UnitSystem::Imperial => ("fps", "°F", "ft·lb"),
            UnitSystem::Metric => ("m/s", "°C", "J"),
        };

        struct PowderRow {
            temp_display: f64,
            velocity_display: f64,
            shift_display: Option<f64>,
            energy_display: Option<f64>,
        }
        let row_at = |temp_display: f64, temp_c: f64| -> PowderRow {
            let v_mps = resolve_at_c(temp_c);
            let v_display = from_vel_si(v_mps);
            PowderRow {
                temp_display,
                velocity_display: v_display,
                shift_display: velocity.map(|nominal| v_display - nominal),
                energy_display: energy_at(v_mps),
            }
        };

        let rows: Vec<PowderRow> = match &sweep_temps {
            Some(temps) => temps.iter().map(|&t| row_at(t, to_temp_c(t))).collect(),
            None => {
                let (t_display, t_c) = if has_curve {
                    match (powder_temp, temperature) {
                        (Some(td), _) => (td, to_temp_c(td)),
                        (None, Some(td)) => (td, to_temp_c(td)),
                        _ => unreachable!("validated above"),
                    }
                } else {
                    let td = temperature.expect("validated above");
                    (td, to_temp_c(td))
                };
                vec![row_at(t_display, t_c)]
            }
        };

        let model_desc = if has_curve {
            let curve = curve_ref.expect("has_curve");
            format!(
                "measured curve, {} points ({:.1}\u{2013}{:.1} {})",
                curve.len(),
                from_temp_c(curve[0].0),
                from_temp_c(curve[curve.len() - 1].0),
                temp_unit
            )
        } else {
            format!("linear, {:.2} {}/{}", sens_display, vel_unit, temp_unit)
        };

        let mut out = String::new();
        match out_fmt {
            "json" => {
                let round1 = |x: f64| (x * 10.0).round() / 10.0;
                let rows_json: Vec<serde_json::Value> = rows
                    .iter()
                    .map(|r| {
                        let mut o = serde_json::json!({
                            "temperature": round1(r.temp_display),
                            "velocity": round1(r.velocity_display),
                        });
                        if let Some(s) = r.shift_display {
                            o["shift"] = serde_json::json!(round1(s));
                        }
                        if let Some(e) = r.energy_display {
                            o["energy"] = serde_json::json!(e.round());
                        }
                        o
                    })
                    .collect();
                let mut result = serde_json::json!({
                    "command": "powder",
                    "units": match units {
                        UnitSystem::Imperial => "imperial",
                        UnitSystem::Metric => "metric",
                    },
                    "model": if has_curve { "curve" } else { "linear" },
                });
                if !has_curve {
                    result["sensitivity"] = serde_json::json!(sens_display);
                    result["reference_temp"] = serde_json::json!(round1(from_temp_c(ref_temp_c)));
                } else {
                    result["curve_points"] = serde_json::json!(curve_ref.expect("has_curve").len());
                }
                if let Some(v) = velocity {
                    result["nominal_velocity"] = serde_json::json!(v);
                }
                if let Some(m) = mass {
                    result["mass"] = serde_json::json!(m);
                }
                if sweep_temps.is_some() {
                    result["sweep"] = serde_json::json!(rows_json);
                } else {
                    result["resolved"] = rows_json
                        .into_iter()
                        .next()
                        .unwrap_or(serde_json::json!(null));
                }
                out.push_str(
                    &serde_json::to_string_pretty(&result)
                        .map_err(|e| JsValue::from_str(&e.to_string()))?,
                );
                out.push('\n');
            }
            "csv" => {
                let (temp_a, vel_a, energy_a) = match units {
                    UnitSystem::Imperial => ("f", "fps", "ftlb"),
                    UnitSystem::Metric => ("c", "mps", "j"),
                };
                let has_shift = rows.first().is_some_and(|r| r.shift_display.is_some());
                let has_energy = rows.first().is_some_and(|r| r.energy_display.is_some());
                out.push_str(&format!("temperature_{},velocity_{}", temp_a, vel_a));
                if has_shift {
                    out.push_str(&format!(",shift_{}", vel_a));
                }
                if has_energy {
                    out.push_str(&format!(",energy_{}", energy_a));
                }
                out.push('\n');
                for r in &rows {
                    out.push_str(&format!("{:.1},{:.1}", r.temp_display, r.velocity_display));
                    if let Some(s) = r.shift_display {
                        out.push_str(&format!(",{:.1}", s));
                    }
                    if let Some(e) = r.energy_display {
                        out.push_str(&format!(",{:.0}", e));
                    }
                    out.push('\n');
                }
            }
            _ => {
                out.push_str("Powder Temperature Velocity\n");
                out.push_str("===========================\n");
                out.push_str(&format!("  Model:              {}\n", model_desc));
                if !has_curve {
                    out.push_str(&format!(
                        "  Reference temp:     {:.1} {}\n",
                        from_temp_c(ref_temp_c),
                        temp_unit
                    ));
                }
                if let Some(v) = velocity {
                    out.push_str(&format!("  Nominal velocity:   {:.1} {}\n", v, vel_unit));
                }
                out.push('\n');
                if rows.len() == 1 {
                    let r = &rows[0];
                    let temp_label = if has_curve {
                        "Powder temp:"
                    } else {
                        "Shot temp:"
                    };
                    out.push_str(&format!(
                        "  {:<20}{:.1} {}\n",
                        temp_label, r.temp_display, temp_unit
                    ));
                    match r.shift_display {
                        Some(s) => out.push_str(&format!(
                            "  Resolved velocity:  {:.1} {}  ({:+.1})\n",
                            r.velocity_display, vel_unit, s
                        )),
                        None => out.push_str(&format!(
                            "  Resolved velocity:  {:.1} {}\n",
                            r.velocity_display, vel_unit
                        )),
                    }
                    if let Some(e) = r.energy_display {
                        out.push_str(&format!("  Muzzle energy:      {:.0} {}\n", e, energy_unit));
                    }
                } else {
                    let has_shift = rows.first().is_some_and(|r| r.shift_display.is_some());
                    let has_energy = rows.first().is_some_and(|r| r.energy_display.is_some());
                    out.push_str(&format!(
                        "  {:>10}  {:>14}",
                        format!("Temp ({})", temp_unit),
                        format!("Velocity ({})", vel_unit)
                    ));
                    if has_shift {
                        out.push_str(&format!("  {:>12}", format!("Shift ({})", vel_unit)));
                    }
                    if has_energy {
                        out.push_str(&format!("  {:>15}", format!("Energy ({})", energy_unit)));
                    }
                    out.push('\n');
                    for r in &rows {
                        out.push_str(&format!(
                            "  {:>10.1}  {:>14.1}",
                            r.temp_display, r.velocity_display
                        ));
                        if let Some(s) = r.shift_display {
                            out.push_str(&format!("  {:>12.1}", s));
                        }
                        if let Some(e) = r.energy_display {
                            out.push_str(&format!("  {:>15.0}", e));
                        }
                        out.push('\n');
                    }
                }
            }
        }
        Ok(out)
    }

    /// Free recoil (MBA-1372): mirrors the native `recoil` subcommand's flags exactly.
    /// See `ballistics_engine::recoil` for the SAAMI momentum-balance math and the
    /// gas-velocity convention (SAAMI type-keyed factor by default; `--gas-velocity` /
    /// `--gas-velocity-factor` are the fixed/override escape hatches).
    #[cfg(feature = "wasm-recoil")]
    fn handle_recoil_command(&self, args: &[&str], units: UnitSystem) -> Result<String, JsValue> {
        let mut bullet_weight: Option<f64> = None;
        let mut charge_weight: Option<f64> = None;
        let mut velocity: Option<f64> = None;
        let mut firearm_weight: Option<f64> = None;
        let mut firearm_type_str = "rifle";
        let mut gas_velocity_factor: Option<f64> = None;
        let mut gas_velocity: Option<f64> = None;
        let mut out_fmt = "table";

        let mut i = 0;
        while i < args.len() {
            match args[i] {
                "-b" | "--bullet-weight" => {
                    if i + 1 < args.len() {
                        bullet_weight = Some(
                            args[i + 1]
                                .parse()
                                .map_err(|_| JsValue::from_str("Invalid bullet weight"))?,
                        );
                        i += 1;
                    }
                }
                "-c" | "--charge-weight" => {
                    if i + 1 < args.len() {
                        charge_weight = Some(
                            args[i + 1]
                                .parse()
                                .map_err(|_| JsValue::from_str("Invalid charge weight"))?,
                        );
                        i += 1;
                    }
                }
                "-v" | "--velocity" => {
                    if i + 1 < args.len() {
                        velocity = Some(
                            args[i + 1]
                                .parse()
                                .map_err(|_| JsValue::from_str("Invalid velocity"))?,
                        );
                        i += 1;
                    }
                }
                "-f" | "--firearm-weight" => {
                    if i + 1 < args.len() {
                        firearm_weight = Some(
                            args[i + 1]
                                .parse()
                                .map_err(|_| JsValue::from_str("Invalid firearm weight"))?,
                        );
                        i += 1;
                    }
                }
                "--firearm-type" => {
                    if i + 1 < args.len() {
                        firearm_type_str = args[i + 1];
                        i += 1;
                    }
                }
                "--gas-velocity-factor" => {
                    if i + 1 < args.len() {
                        gas_velocity_factor = Some(
                            args[i + 1]
                                .parse()
                                .map_err(|_| JsValue::from_str("Invalid gas velocity factor"))?,
                        );
                        i += 1;
                    }
                }
                "--gas-velocity" => {
                    if i + 1 < args.len() {
                        gas_velocity = Some(
                            args[i + 1]
                                .parse()
                                .map_err(|_| JsValue::from_str("Invalid gas velocity"))?,
                        );
                        i += 1;
                    }
                }
                "-o" | "--output" => {
                    if i + 1 < args.len() {
                        out_fmt = args[i + 1];
                        i += 1;
                    }
                }
                _ => {}
            }
            i += 1;
        }
        if !matches!(out_fmt, "table" | "json" | "csv") {
            return Err(JsValue::from_str(
                "Invalid output format for recoil (expected table, json, or csv)",
            ));
        }

        let bullet_weight =
            bullet_weight.ok_or_else(|| JsValue::from_str("--bullet-weight is required"))?;
        let charge_weight =
            charge_weight.ok_or_else(|| JsValue::from_str("--charge-weight is required"))?;
        let velocity = velocity.ok_or_else(|| JsValue::from_str("--velocity is required"))?;
        let firearm_weight =
            firearm_weight.ok_or_else(|| JsValue::from_str("--firearm-weight is required"))?;

        // Same numeric ranges the native clap definition enforces (f64_range).
        if !(0.1..=2000.0).contains(&bullet_weight) {
            return Err(JsValue::from_str(
                "Bullet weight must be between 0.1 and 2000",
            ));
        }
        if !(0.0..=1000.0).contains(&charge_weight) {
            return Err(JsValue::from_str(
                "Charge weight must be between 0 and 1000",
            ));
        }
        if !(1.0..=6000.0).contains(&velocity) {
            return Err(JsValue::from_str("Velocity must be between 1 and 6000"));
        }
        if !(0.1..=500.0).contains(&firearm_weight) {
            return Err(JsValue::from_str(
                "Firearm weight must be between 0.1 and 500",
            ));
        }
        if let Some(f) = gas_velocity_factor {
            if !(0.0..=20.0).contains(&f) {
                return Err(JsValue::from_str(
                    "Gas velocity factor must be between 0 and 20",
                ));
            }
        }
        if let Some(v) = gas_velocity {
            if !(0.0..=20000.0).contains(&v) {
                return Err(JsValue::from_str(
                    "Gas velocity must be between 0 and 20000",
                ));
            }
        }

        let firearm_type = match firearm_type_str.to_ascii_lowercase().as_str() {
            "rifle" => FirearmType::Rifle,
            "pistol" => FirearmType::Pistol,
            "shotgun-average" | "shotgun" => FirearmType::ShotgunAverage,
            "shotgun-long" => FirearmType::ShotgunLong,
            other => {
                return Err(JsValue::from_str(&format!(
                    "Invalid --firearm-type '{other}' (expected rifle, pistol, shotgun-average, or shotgun-long)"
                )))
            }
        };

        let bullet_mass_kg = match units {
            UnitSystem::Imperial => bullet_weight * crate::constants::GRAINS_TO_KG,
            UnitSystem::Metric => bullet_weight * 0.001, // grams -> kg
        };
        let charge_mass_kg = match units {
            UnitSystem::Imperial => charge_weight * crate::constants::GRAINS_TO_KG,
            UnitSystem::Metric => charge_weight * 0.001, // grams -> kg
        };
        let firearm_mass_kg = match units {
            UnitSystem::Imperial => firearm_weight * POUNDS_TO_KG,
            UnitSystem::Metric => firearm_weight, // already kg
        };
        let muzzle_velocity_mps = match units {
            UnitSystem::Imperial => velocity * 0.3048,
            UnitSystem::Metric => velocity,
        };

        // Precedence: --gas-velocity (absolute) > --gas-velocity-factor (override ratio)
        // > --firearm-type (SAAMI default) -- identical to the native handler.
        let (gas_model, gas_model_desc): (GasVelocityModel, String) = if let Some(v) = gas_velocity
        {
            let v_mps = match units {
                UnitSystem::Imperial => v * 0.3048,
                UnitSystem::Metric => v,
            };
            (GasVelocityModel::Fixed(v_mps), "fixed".to_string())
        } else if let Some(f) = gas_velocity_factor {
            (GasVelocityModel::Factor(f), format!("factor({f:.3})"))
        } else {
            let name = match firearm_type {
                FirearmType::Rifle => "saami-rifle",
                FirearmType::Pistol => "saami-pistol",
                FirearmType::ShotgunAverage => "saami-shotgun-average",
                FirearmType::ShotgunLong => "saami-shotgun-long",
            };
            (GasVelocityModel::Saami(firearm_type), name.to_string())
        };
        let gas_velocity_mps = gas_model.resolve_mps(muzzle_velocity_mps);

        let result = free_recoil(FreeRecoilInputs {
            bullet_mass_kg,
            charge_mass_kg,
            muzzle_velocity_mps,
            firearm_mass_kg,
            gas_velocity_mps,
        })
        .map_err(|e| JsValue::from_str(&e))?;

        let (weight_unit, firearm_weight_unit, vel_unit, energy_unit, impulse_unit) = match units {
            UnitSystem::Imperial => ("gr", "lb", "fps", "ft-lb", "lb-s"),
            UnitSystem::Metric => ("g", "kg", "m/s", "J", "N-s"),
        };
        // 1 lbf = 4.4482216152605 N, exact by definition; used only to display the
        // recoil impulse (a genuine N*s quantity) in pound-seconds for imperial output.
        const LBF_TO_N: f64 = 4.4482216152605;
        let gas_velocity_display = match units {
            UnitSystem::Imperial => gas_velocity_mps / 0.3048,
            UnitSystem::Metric => gas_velocity_mps,
        };
        let recoil_velocity_display = match units {
            UnitSystem::Imperial => result.recoil_velocity_mps / 0.3048,
            UnitSystem::Metric => result.recoil_velocity_mps,
        };
        let recoil_energy_display = match units {
            UnitSystem::Imperial => result.recoil_energy_j * 0.737562,
            UnitSystem::Metric => result.recoil_energy_j,
        };
        let impulse_display = match units {
            UnitSystem::Imperial => result.impulse_ns / LBF_TO_N,
            UnitSystem::Metric => result.impulse_ns,
        };

        let mut out = String::new();
        match out_fmt {
            "json" => {
                let result_json = serde_json::json!({
                    "command": "recoil",
                    "units": match units {
                        UnitSystem::Imperial => "imperial",
                        UnitSystem::Metric => "metric",
                    },
                    "inputs": {
                        "bullet_weight": bullet_weight,
                        "charge_weight": charge_weight,
                        "velocity": velocity,
                        "firearm_weight": firearm_weight,
                    },
                    "gas_velocity_model": gas_model_desc,
                    "gas_velocity": gas_velocity_display,
                    "recoil_velocity": recoil_velocity_display,
                    "recoil_energy": recoil_energy_display,
                    "impulse": impulse_display,
                });
                out.push_str(
                    &serde_json::to_string_pretty(&result_json)
                        .map_err(|e| JsValue::from_str(&e.to_string()))?,
                );
                out.push('\n');
            }
            "csv" => {
                // MBA-1418: the CSV header must match native byte for byte. `vel_unit` above is
                // the DISPLAY spelling ("m/s") used by the table; native's machine surface uses
                // the ASCII form ("mps"), so metric CSV read `velocity_m/s` here and
                // `velocity_mps` there. Machine output that differs by surface breaks anyone
                // parsing both. Imperial ("fps") already agreed, which is why this survived.
                let vel_unit_csv = match units {
                    UnitSystem::Imperial => "fps",
                    UnitSystem::Metric => "mps",
                };
                out.push_str(&format!(
                    "bullet_weight_{w},charge_weight_{w},velocity_{v},firearm_weight_{fw},gas_velocity_{v},recoil_velocity_{v},recoil_energy_{e},impulse_{im}\n",
                    w = weight_unit,
                    v = vel_unit_csv,
                    fw = match units { UnitSystem::Imperial => "lb", UnitSystem::Metric => "kg" },
                    e = match units { UnitSystem::Imperial => "ftlb", UnitSystem::Metric => "j" },
                    im = match units { UnitSystem::Imperial => "lbs", UnitSystem::Metric => "ns" },
                ));
                out.push_str(&format!(
                    "{:.2},{:.2},{:.2},{:.2},{:.2},{:.3},{:.3},{:.4}\n",
                    bullet_weight,
                    charge_weight,
                    velocity,
                    firearm_weight,
                    gas_velocity_display,
                    recoil_velocity_display,
                    recoil_energy_display,
                    impulse_display,
                ));
            }
            _ => {
                out.push_str("Free Recoil (SAAMI Momentum Balance)\n");
                out.push_str("=====================================\n");
                out.push_str(&format!(
                    "  Firearm weight:      {:.2} {}\n",
                    firearm_weight, firearm_weight_unit
                ));
                out.push_str(&format!(
                    "  Bullet weight:       {:.1} {}\n",
                    bullet_weight, weight_unit
                ));
                out.push_str(&format!(
                    "  Charge weight:       {:.1} {}\n",
                    charge_weight, weight_unit
                ));
                out.push_str(&format!(
                    "  Muzzle velocity:     {:.1} {}\n",
                    velocity, vel_unit
                ));
                out.push_str(&format!(
                    "  Gas velocity model:  {}  ({:.1} {})\n",
                    gas_model_desc, gas_velocity_display, vel_unit
                ));
                out.push('\n');
                out.push_str(&format!(
                    "  Recoil velocity:     {:.2} {}\n",
                    recoil_velocity_display, vel_unit
                ));
                out.push_str(&format!(
                    "  Recoil energy:       {:.2} {}\n",
                    recoil_energy_display, energy_unit
                ));
                out.push_str(&format!(
                    "  Recoil impulse:      {:.3} {}\n",
                    impulse_display, impulse_unit
                ));
            }
        }
        Ok(out)
    }

    /// Power factor (MBA-1372): mirrors the native `power-factor` subcommand's flags
    /// exactly. PF is intrinsically grains/fps by every rulebook, so weight/velocity are
    /// converted to grains/fps regardless of `--units` before calling into
    /// `ballistics_engine::power_factor`; echoed weight/velocity stay in display units.
    #[cfg(feature = "wasm-power-factor")]
    fn handle_power_factor_command(
        &self,
        args: &[&str],
        units: UnitSystem,
    ) -> Result<String, JsValue> {
        let mut weight: Option<f64> = None;
        let mut velocity: Option<f64> = None;
        let mut organization: Option<String> = None;
        let mut out_fmt = "table";

        let mut i = 0;
        while i < args.len() {
            match args[i] {
                "-w" | "--weight" => {
                    if i + 1 < args.len() {
                        weight = Some(
                            args[i + 1]
                                .parse()
                                .map_err(|_| JsValue::from_str("Invalid weight"))?,
                        );
                        i += 1;
                    }
                }
                "-v" | "--velocity" => {
                    if i + 1 < args.len() {
                        velocity = Some(
                            args[i + 1]
                                .parse()
                                .map_err(|_| JsValue::from_str("Invalid velocity"))?,
                        );
                        i += 1;
                    }
                }
                "--organization" => {
                    if i + 1 < args.len() {
                        organization = Some(args[i + 1].to_string());
                        i += 1;
                    }
                }
                "-o" | "--output" => {
                    if i + 1 < args.len() {
                        out_fmt = args[i + 1];
                        i += 1;
                    }
                }
                _ => {}
            }
            i += 1;
        }
        if !matches!(out_fmt, "table" | "json" | "csv") {
            return Err(JsValue::from_str(
                "Invalid output format for power-factor (expected table, json, or csv)",
            ));
        }

        let weight = weight.ok_or_else(|| JsValue::from_str("--weight is required"))?;
        let velocity = velocity.ok_or_else(|| JsValue::from_str("--velocity is required"))?;
        if !(0.1..=2000.0).contains(&weight) {
            return Err(JsValue::from_str("Weight must be between 0.1 and 2000"));
        }
        if !(1.0..=6000.0).contains(&velocity) {
            return Err(JsValue::from_str("Velocity must be between 1 and 6000"));
        }

        let weight_gr = match units {
            UnitSystem::Imperial => weight,
            UnitSystem::Metric => weight * GRAINS_PER_GRAM,
        };
        let velocity_fps = match units {
            UnitSystem::Imperial => velocity,
            UnitSystem::Metric => velocity / 0.3048,
        };

        let raw_pf = weight_gr * velocity_fps / 1000.0;
        let scored_pf = scored_power_factor(weight_gr, velocity_fps);
        let mut rows = pf_evaluate_all(weight_gr, velocity_fps);
        if let Some(org) = organization.as_deref() {
            let org_lower = org.to_ascii_lowercase();
            rows.retain(|r| r.organization.eq_ignore_ascii_case(&org_lower));
            if rows.is_empty() {
                return Err(JsValue::from_str(&format!(
                    "--organization '{org}' matched nothing; expected uspsa, idpa, or sass"
                )));
            }
        }

        let (weight_unit, vel_unit) = match units {
            UnitSystem::Imperial => ("gr", "fps"),
            UnitSystem::Metric => ("g", "m/s"),
        };

        let mut out = String::new();
        match out_fmt {
            "json" => {
                let rows_json: Vec<serde_json::Value> = rows
                    .iter()
                    .map(|r| {
                        serde_json::json!({
                            "organization": r.organization,
                            "class": r.class,
                            "min_pf": r.min_pf,
                            "pf_pass": r.pf_pass,
                            "min_velocity_fps": r.min_velocity_fps,
                            "max_velocity_fps": r.max_velocity_fps,
                            "velocity_pass": r.velocity_pass,
                            "pass": r.pass,
                        })
                    })
                    .collect();
                let result_json = serde_json::json!({
                    "command": "power-factor",
                    "units": match units {
                        UnitSystem::Imperial => "imperial",
                        UnitSystem::Metric => "metric",
                    },
                    "weight": weight,
                    "velocity": velocity,
                    "power_factor_raw": raw_pf,
                    "power_factor_scored": scored_pf,
                    "thresholds": rows_json,
                });
                out.push_str(
                    &serde_json::to_string_pretty(&result_json)
                        .map_err(|e| JsValue::from_str(&e.to_string()))?,
                );
                out.push('\n');
            }
            "csv" => {
                out.push_str(
                    "organization,class,min_pf,pf_pass,min_velocity_fps,max_velocity_fps,velocity_pass,pass\n",
                );
                for r in &rows {
                    out.push_str(&format!(
                        "{},{},{:.0},{},{},{},{},{}\n",
                        r.organization,
                        r.class,
                        r.min_pf,
                        r.pf_pass,
                        r.min_velocity_fps
                            .map(|v| format!("{v:.0}"))
                            .unwrap_or_default(),
                        r.max_velocity_fps
                            .map(|v| format!("{v:.0}"))
                            .unwrap_or_default(),
                        r.velocity_pass.map(|b| b.to_string()).unwrap_or_default(),
                        r.pass,
                    ));
                }
            }
            _ => {
                out.push_str("Power Factor\n");
                out.push_str("============\n");
                out.push_str(&format!(
                    "  Weight:              {:.1} {}\n",
                    weight, weight_unit
                ));
                out.push_str(&format!(
                    "  Velocity:            {:.1} {}\n",
                    velocity, vel_unit
                ));
                out.push_str(&format!("  Power factor (raw):  {:.2}\n", raw_pf));
                out.push_str(&format!("  Power factor (scored): {:.0}\n", scored_pf));
                out.push('\n');
                out.push_str(&format!(
                    "  {:<8}  {:<26}  {:>8}  {:>6}  {:>18}\n",
                    "Org", "Class", "Min PF", "Pass", "Velocity limit"
                ));
                for r in &rows {
                    let vel_limit = match (r.min_velocity_fps, r.max_velocity_fps) {
                        (Some(min), Some(max)) => format!("{:.0}-{:.0} fps", min, max),
                        (Some(min), None) => format!(">= {:.0} fps", min),
                        (None, Some(max)) => format!("<= {:.0} fps", max),
                        (None, None) => "-".to_string(),
                    };
                    out.push_str(&format!(
                        "  {:<8}  {:<26}  {:>8.0}  {:>6}  {:>18}\n",
                        r.organization,
                        r.class,
                        r.min_pf,
                        if r.pass { "PASS" } else { "FAIL" },
                        vel_limit,
                    ));
                }
            }
        }
        Ok(out)
    }

    fn show_help(&self) -> String {
        // Split per command so a gated-out command's help text (and its examples) leave
        // the binary with it. The chunks concatenate back to the original text exactly.
        let mut help = String::new();
        help.push_str(
            r#"Ballistics Engine - WebAssembly Version

Usage: ballistics [OPTIONS] <COMMAND>

Commands:
  trajectory      Calculate ballistic trajectory"#,
        );
        #[cfg(feature = "wasm-zero")]
        help.push_str(
            r#"
  zero           Calculate sight adjustment for zero"#,
        );
        #[cfg(feature = "wasm-monte-carlo")]
        help.push_str(
            r#"
  monte-carlo    Run Monte Carlo simulation"#,
        );
        #[cfg(feature = "wasm-truing")]
        help.push_str(
            r#"
  true-velocity  Calculate effective muzzle velocity from observed drop"#,
        );
        #[cfg(feature = "wasm-truing")]
        help.push_str(
            r#"
  true-wind      Back-solve effective crosswind from an observed horizontal miss"#,
        );
        #[cfg(feature = "wasm-bc-convert")]
        help.push_str(
            r#"
  bc-convert     Convert published BC values between G1 and G7"#,
        );
        #[cfg(feature = "wasm-estimate-bc")]
        help.push_str(
            r#"
  estimate-bc    Estimate BC from trajectory data"#,
        );
        #[cfg(feature = "wasm-lead")]
        help.push_str(
            r#"
  lead           Calculate moving-target lead (hold)"#,
        );
        #[cfg(feature = "wasm-powder")]
        help.push_str(
            r#"
  powder         Resolve powder-temperature velocity shift (no trajectory)"#,
        );
        #[cfg(feature = "wasm-recoil")]
        help.push_str(
            r#"
  recoil         Free recoil energy/velocity/impulse (SAAMI momentum balance)"#,
        );
        #[cfg(feature = "wasm-power-factor")]
        help.push_str(
            r#"
  power-factor   Power factor + USPSA/IDPA/SASS rulebook pass/fail"#,
        );
        #[cfg(feature = "wasm-drag-curve")]
        help.push_str(
            r#"
  drag-curve     Print a built-in reference drag function as (Mach, Cd) data"#,
        );
        #[cfg(feature = "wasm-reticle")]
        help.push_str(
            r#"
  reticle        Reticle hold points and parametric reticle generation"#,
        );
        help.push_str(
            r#"
  help           Show this help message

Global Options:
  -u, --units <SYSTEM>  Unit system (imperial/metric) [default: imperial]

Host API (JavaScript, not a CLI flag):
  loadDragTable(bytes)   Load a custom Mach:Cd drag table (CSV, same format as native
                         --drag-table). Also accepts .drg vendor drag-curve text as a fallback
                         when the bytes aren't valid CSV. Once loaded, EVERY
                         trajectory/zero/lead/monte-carlo run applies it automatically (no
                         --use-* flag needed); -b/--bc is still accepted but ignored for drag
                         while a table is active.
  hasDragTable()         Report whether a drag table is currently loaded.
  clearDragTable()       Unload the drag table, reverting to the selected --drag-model +
                         BC drag. Lets one instance compare CDM vs G7: load -> solve ->
                         clear -> solve.
  loadBc5dTable(bytes)   Load a BC5D correction table (see --use-bc-segments below).
  hasBc5dTable()         Report whether a BC5D table is currently loaded.

Trajectory Command:
  ballistics trajectory [OPTIONS]
  
  Basic Options:
    -v, --velocity <VEL>         Muzzle velocity (fps/m/s)
    -b, --bc <BC>                Ballistic coefficient
    -m, --mass <MASS>            Mass (grains/grams)
    -d, --diameter <DIA>         Diameter (inches/mm)
    -a, --angle <ANGLE>          Launch angle (degrees)
    --drag-model <MODEL>         Drag model (G1/G2/G5/G6/G7/G8/GI/GS/RA4)
    --cd-scale <FACTOR>          Whole-curve drag scale for a loaded drag table
                                 (1.0 = neutral, typical 0.90-1.10). Requires a
                                 drag table (loadDragTable)
    --max-range <RANGE>          Maximum range (yards/meters)
    -z, --auto-zero <DIST>       Auto-zero at distance
    --zero-poi-up <OFFSET>       Deliberate POI offset AT the zero range (in/cm, signed;
                                 positive = zeroed to impact HIGH). Angular zero-state
                                 bias; needs --auto-zero (MBA-1359)
    --zero-poi-right <OFFSET>    Deliberate POI offset AT the zero range (in/cm, signed;
                                 positive = impacts RIGHT); needs --auto-zero (MBA-1359)
    --sight-offset <OFFSET>      Lateral sight-to-bore mount offset (in/mm, signed;
                                 positive = sight RIGHT of bore, MBA-1396). Physical
                                 mount geometry: drift starts offset left of the sight
                                 line; with --auto-zero it converges to the sight line
                                 at the zero range, without a zero it stays displaced
    --drops-reference <REF>      Drop reference plane: los (default) = perpendicular
                                 to the line of sight; target = vertical in the target
                                 plane (drop / cos(shooting angle), JBM's "target
                                 plane"); relabels the Drop column (MBA-1403)
    --elevation-cf <FACTOR>      Elevation scope tracking correction factor from a
                                 tall-target test (MBA-1358): actual/dialed travel
                                 (0.95 = under-tracks 5%). The auto-zero banner's
                                 MOA/mrad dial values are DIVIDED by it. Strictly
                                 between 0.5 and 1.5
    --windage-cf <FACTOR>        Windage tracking correction factor (MBA-1358): the
                                 mover Ring dial outputs (table/JSON/CSV) are divided
                                 by it. Same bounds as --elevation-cf
    -o, --output <FORMAT>        Output format (table/json/csv)
    --full                       Show all trajectory points
    --csv-summary                With -o csv, emit the metric,value,unit SUMMARY
                                 document (max_range, max_height, time_of_flight,
                                 impact_velocity, impact_energy, and
                                 zero_angle_degrees when --auto-zero solved one)
                                 instead of the per-point table. Native's second
                                 CSV form; without it the CSV is unchanged
    --with-drag-coefficient      Add each point's effective drag coefficient to
                                 -o json (the projectile's OWN Cd, form-factor
                                 scaled — a segmented BC shows its band steps).
                                 Off by default: JSON without it is unchanged
    --plot [STYLE]               Append terminal charts after the table (drop and
                                 drift vs range); STYLE = braille (default) or ascii
                                 (for fonts without braille glyph coverage)
    --target-speed <SPEED>       Mover ring: per-point ring radius = speed x ToF
                                 (mph/m/s, 0-300; 0 = off). Adds a Ring column (table),
                                 mover_ring_m/mover_ring_mil (json), ring_mil (csv)
    --adjustment-unit <UNIT>     Ring table column unit: mil/moa/smoa/iphy/clicks
                                 [default: mil]. Needs --target-speed — the Ring
                                 column is the only thing it changes here
    --elevation-click-value <S>  Turret elevation click graduation, e.g. 0.25moa or
                                 0.1mil; required (once) when --adjustment-unit clicks
    --windage-click-value <S>    Turret windage click graduation (accepted for CLI
                                 parity; the Ring column always uses the elevation one)

  Environmental:
    --wind-speed <SPEED>         Wind speed (mph/m/s)
    --wind-direction <DIR>       Wind direction (deg; 0=headwind, 90=from right) or a
                                 clock position (3oc, 10h30, 10:30; 12oc = headwind)
    --wind-ref <shooter|compass> Wind direction frame (default shooter). compass =
                                 earth-fixed bearings (0=N) for --wind-direction and
                                 every --wind-segment angle, re-referenced against
                                 --shot-direction; rejects clock positions
    --wind-vertical <SPEED>      Vertical wind (mph/m/s); positive = updraft (raises POI)
    --wind-segment <S:A:D[:V]>   Downrange wind seg speed:angle:until-dist[:vertical] (repeatable).
                                 ANGLE also takes colon-free clock forms (10:3oc:400).
                                 Optional 4th field is ALWAYS m/s updraft-positive, unlike
                                 speed which follows --units
    --temperature <TEMP>         Temperature (F/C)
    --pressure <PRESSURE>        Pressure (inHg/hPa)
    --zero-density-altitude <DA> Zero-day density altitude for --auto-zero (ft/m);
                                 supersedes --zero-altitude and --zero-pressure/
                                 --zero-pressure-type for the zero solve only
    --humidity <HUMIDITY>        Humidity (0-100%)
    --altitude <ALT>             Altitude (feet/meters)
    
  Advanced Physics:
    --enable-magnus              Enable Magnus effect
    --enable-coriolis            Enable Coriolis effect
    --enable-spin-drift          Enable empirical Litz spin drift
    --enable-wind-shear          Enable altitude-dependent wind
    --enable-pitch-damping       Enable transonic stability
    --enable-precession          Enable angular motion physics
    --use-euler                  Use Euler integration (less accurate)
    --use-rk4-fixed              Use fixed-step RK4 (default: adaptive RK45)
    --time-step <SECONDS>        Integration time step (seconds) [default: 0.001]
    --sample-trajectory          Enable trajectory sampling
    --sample-interval <DIST>     Trajectory sampling interval (yards/meters) [default: 10]
    --use-bc-segments            Use velocity-based BC (from a loaded BC5D table)
    --bc-segment <VMIN:VMAX:BC>  Manual velocity-keyed BC segment (repeatable; fps/m/s per --units)
    --print-bc-segments          Print the active BC segment ladder (velocity/Mach span + BC)
                                 applied to this run, or a note when none are active
    --dsf-point <MACH:DSF>       Drop-scale-factor truing point (repeatable; up to 6). Scales
                                 predicted drop by DSF at MACH (0 < MACH < 1.2, 0.5 < DSF < 2.0)
                                 — WASM has no saved profile, so pass the table per call
                                 (native CLI equivalent: a saved profile's `dsf` table)
    --use-powder-sensitivity     Enable powder temp sensitivity
    --ignore-ground-impact       Disable ground-impact truncation; trajectory runs to
                                 --max-range regardless of drop below the muzzle

  Additional Parameters:
    --twist-rate <RATE>          Barrel twist (inches/turn imperial, mm/turn metric)
    --twist-right <BOOL>         Right-hand twist (true/false)
    --latitude <LAT>             Latitude for Coriolis (degrees)
    --shot-direction <DEG>       Compass bearing of the shot for Coriolis (0=N, 90=E)
    --shooting-angle <ANGLE>     Uphill/downhill angle (degrees)
    --cant <DEGREES>             Rifle cant angle (degrees); positive = clockwise from the
                                 shooter, moving point of impact right and low
    --sight-height <HEIGHT>      Sight height above bore (inches/mm)
    --muzzle-height <HEIGHT>     Shooter height above ground (inches/mm; also accepts
                                 --bore-height, matching the native CLI). A value above
                                 ~39,370in/1,000,000mm (1000m) triggers a warning: it feeds
                                 air density, thinning it over the whole flight — use
                                 --altitude for site elevation, --ignore-ground-impact to
                                 defeat ground truncation
    --target-height <HEIGHT>     Target height above ground (inches/mm)
    --powder-temp <TEMP>         Powder temperature
    --powder-temp-sensitivity <SENS>  Velocity change per degree"#,
        );
        #[cfg(feature = "wasm-zero")]
        help.push_str(
            r#"

Zero Command:
  ballistics zero [OPTIONS]
  
  Options:
    -v, --velocity <VEL>         Muzzle velocity
    -b, --bc <BC>                Ballistic coefficient
    -m, --mass <MASS>            Mass
    -d, --diameter <DIA>         Diameter
    --drag-model <MODEL>         Drag model (G1/G2/G5/G6/G7/G8/GI/GS/RA4)
    --cd-scale <FACTOR>          Whole-curve drag scale for a loaded drag table
                                 (1.0 = neutral, typical 0.90-1.10). Requires a
                                 drag table (loadDragTable)
    --target-distance <DIST>     Target distance for zero
    --from-angle <DEGREES>       Inverse: solve the zero RANGE(S) a stored bore
                                 angle produces. Reports BOTH line-of-sight
                                 crossings (near, ascending; far, descending)
                                 and names which one zero_range is. Conflicts
                                 with --target-distance; give exactly one
    --sight-height <HEIGHT>      Sight height above bore
    --elevation-cf <FACTOR>      Elevation scope tracking correction factor
                                 (MBA-1358, actual/dialed): the MOA/mrad dial values
                                 in the results are DIVIDED by it. Strictly between
                                 0.5 and 1.5
    --temperature <T>            Zero-day air temperature (°F/°C)
    --pressure <P>               Zero-day pressure (inHg/hPa)
    --pressure-type <TYPE>       absolute (default) or qnh — a QNH altimeter
                                 setting is reduced against --altitude
    --humidity <H>               Relative humidity percent
    --altitude <ALT>             Zero-day altitude (ft/m)
    --density-altitude <DA>      Single-value atmosphere entry (ft/m); supersedes
                                 --altitude and --pressure/--pressure-type"#,
        );
        #[cfg(feature = "wasm-drag-curve")]
        help.push_str(
            r#"

Drag Curve Command:
  ballistics drag-curve [OPTIONS]

  Print a built-in reference drag function as (Mach, Cd) data — the same
  numbers the solver interpolates, so a chart cannot drift from the engine.
  This is the REFERENCE curve for the model's standard projectile; for the
  effective Cd a specific bullet flew, use trajectory --with-drag-coefficient.
  Note the tables do not share a Mach domain: most run to Mach 5, GS and RA4
  stop at Mach 4.

  Options:
    --drag-model <MODEL>         Model to print (G1/G2/G5/G6/G7/G8/GI/GS/RA4)
                                 [default: g7]
    -o, --output <FORMAT>        table (default), csv, or json"#,
        );
        #[cfg(feature = "wasm-reticle")]
        help.push_str(
            r#"

Reticle Command:
  ballistics reticle generate <mil-grid|tree|bdc> [OPTIONS]
  ballistics reticle hold --reticle-json '<JSON>' --drop-mil <MIL> [OPTIONS]

  Places a firing solution where you actually read it: a point in your own
  reticle, FFP/SFP aware. An SFP mark's true subtension is scaled by
  reference-mag / magnification, so a 2 mil mark on a reticle calibrated at
  10x covers 4 mil at 5x. The hold itself is always TRUE angular; only the
  MARKS are rescaled. Excluded by design: Horus/TREMOR grid layouts and
  wind-dot calibration (patented), and any vendor reticle catalog.

  generate options (all layouts):
    --name <NAME>                Name to store in the description
    --focal-plane <ffp|sfp>      Focal plane [default: ffp]
    --reference-mag <X>          Magnification the subtensions are true at
                                 (sfp only) [default: 1.0]
    -o, --output <FORMAT>        table (default) or json. json emits the schema
                                 that `reticle hold --reticle-json` consumes

  generate mil-grid:             A plain mil-hash CROSS, not a filled grid
    --spacing <MIL>              Mark spacing [default: 1.0]
    --extent <MIL>               Reach from center [default: 10.0]

  generate tree:                 Generic widening holdover tree
    --rows <N>                   Holdover rows below center [default: 5]
    --row-spacing <MIL>          Vertical spacing between rows [default: 1.0]
    --spread-step <MIL>          Windage step within a row [default: 0.5]

  generate bdc:                  Ladder from ALREADY-SOLVED drops (no solve here)
    --drop <RANGE:DROP_MIL>      One pair per mark; repeatable

  hold options:
    --reticle-json <JSON>        The reticle description ITSELF as inline JSON.
                                 This build has no filesystem, so unlike the
                                 native CLI this is text, not a path
    --drop-mil <MIL>             Angular drop to hold (+ = below line of sight)
    --wind-mil <MIL>             Angular wind deflection (+ = bullet goes right)
                                 [default: 0]
    --mag <X>                    Magnification in use [default: 10.0]
    -o, --output <FORMAT>        table (default) or json

  Native-only: `reticle hold --range` (solve the drop here first with
  `trajectory` and pass it as --drop-mil) and `--profile`."#,
        );
        #[cfg(feature = "wasm-monte-carlo")]
        help.push_str(
            r#"

Monte Carlo Command:
  ballistics monte-carlo [OPTIONS]

  Options:
    -v, --velocity <VEL>         Base velocity
    -b, --bc <BC>                Base BC
    -m, --mass <MASS>            Mass
    -d, --diameter <DIA>         Diameter
    --drag-model <MODEL>         Drag model (G1/G2/G5/G6/G7/G8/GI/GS/RA4)
    --cd-scale <FACTOR>          Whole-curve drag scale for a loaded drag table
                                 (1.0 = neutral, typical 0.90-1.10). Requires a
                                 drag table (loadDragTable)
    -n, --num-sims <N>           Number of simulations
    --velocity-std <STD>         Velocity std deviation
    --angle-std <STD>            Angle std deviation
    --bc-std <STD>               BC std deviation
    --wind-speed-std <STD>       Wind speed std deviation (--wind-std also accepted)
    --wind-direction-std <STD>   Wind direction std deviation (degrees)

  WEZ (Weapon Employment Zone) sweep:
    --wez                        WEZ sweep mode: hit probability vs range for a
                                 target size instead of a single summary
    -a, --angle <ANGLE>          Launch (elevation) angle in degrees, held for
                                 every sweep step (from `ballistics zero`,
                                 typically) [default: 0]
    --target-size <WxH|R>        WEZ target size: WIDTHxHEIGHT (inches imperial,
                                 cm metric; e.g. 18x30) for a rectangle centered
                                 on the point of aim, or a single number for a
                                 circular radius. Required with --wez
    --wind-call-error <ERR>      Shooter's wind CALL error (mph/m/s): uncertainty
                                 in the shooter's own wind estimate, composed with
                                 the wind std in quadrature [default: 0]
    --wez-start <DIST>           Sweep start range (yd/m) [default: 200]
    --wez-end <DIST>             Sweep end range, inclusive (yd/m) [default: 1000]
    --wez-step <DIST>            Sweep step (yd/m) [default: 100]
    -o, --output <FORMAT>        WEZ output format: summary/statistics/full
                                 (table/csv/json accepted as aliases)
                                 [default: summary]

  Browser note: a WEZ sweep runs num-sims full trajectory solves per range step
  (deterministic but heavy) — prefer -n 300 or fewer for interactive use."#,
        );
        #[cfg(feature = "wasm-truing")]
        help.push_str(
            r#"

True Velocity Command:
  ballistics true-velocity --range <DIST> --measured-drop <DROP> [OPTIONS]

  Calculates the effective muzzle velocity that reproduces an observed drop.
  With one or more --observed impacts it fits muzzle velocity and (when the
  observations constrain it) ballistic coefficient jointly via the real
  forward model (joint MV+BC calibration).

  Options:
    --measured-drop <DROP>       Measured drop at --range (MIL by default;
                                 follows --drop-unit in multi-observation mode).
                                 Required
    --range <DIST>               Range where drop was measured (yd/m). Required
    --observed <RANGE:DROP>      Additional observed impact (repeatable; e.g.
                                 600:5.1). RANGE follows --units, DROP follows
                                 --drop-unit. Enables joint MV+BC calibration
    --drop-unit <UNIT>           Drop unit for --measured-drop/--observed in
                                 multi-observation mode: mil/moa/in [default: mil]
    --elevation-cf <FACTOR>      Elevation scope tracking correction factor
                                 (MBA-1358, actual/dialed): dialed (mil/moa)
                                 observations are MULTIPLIED by it before the fit
                                 (scope-dial -> true angular) so scope error is
                                 not baked into the trued MV/BC; report dial
                                 values are shown back in scope units (/CF). 'in'
                                 drops never scale. Strictly between 0.5 and 1.5
    -b, --bc <BC>                Ballistic coefficient (starting value; fitted
                                 when the observations allow)
    --drag-model <MODEL>         Drag model (G1/G7) [default: g1]
    -m, --mass <MASS>            Bullet weight (grains/grams)
    -d, --diameter <DIA>         Bullet diameter (inches/mm)
    --chrono-velocity <VEL>      Chronograph velocity for comparison (fps/m/s)
    --chrono-distance <DIST>     Distance --chrono-velocity was measured at,
                                 downrange of the muzzle (ft/m). Nonzero
                                 back-solves the true muzzle velocity via the
                                 real forward drag model; zero/absent is a
                                 no-op. Valid range 1-98 ft / 0.3-30 m;
                                 requires --chrono-velocity
    --zero-distance <DIST>       Zero distance (yd/m) [default: 100]
    --sight-height <HEIGHT>      Sight height above bore (in/mm) [default: 2/50]
    --temperature <T>            Temperature (°F/°C) [default: 59/15]
    --pressure <P>               Pressure (inHg/hPa) [default: 29.92/1013.25]
    --pressure-type <TYPE>       absolute (default) or qnh (reduced vs --altitude)
    --humidity <H>               Humidity (0-100%) [default: 50]
    --altitude <A>               Altitude (ft/m) [default: 0]
    --offline                    Accepted for native-command parity (the WASM
                                 terminal always calculates locally)
    -o, --output <FORMAT>        Output format (table/json/csv) [default: table]"#,
        );
        #[cfg(feature = "wasm-truing")]
        help.push_str(
            r#"

True Wind Command:
  ballistics true-wind --miss <RANGE:RIGHT> --twist-rate <TWIST> [OPTIONS]

  Back-solves the effective crosswind from an observed horizontal miss, so wind
  CALLS can be calibrated instead of guessed at. Spin drift is always modelled
  (hence the required twist rate); Coriolis is modelled when --latitude and
  --shot-direction are both supplied. Anything the model has no data for stays
  absorbed in the solved wind, and the report says which effects those were.

  Signs: --miss positive = impact RIGHT of aim. Solved wind positive = wind FROM
  the shooter's LEFT (9 o'clock) pushing impacts right; negative = FROM the right
  pushing left. Wind-FROM convention (0 = headwind, per the 0.19.0 sign fix).
  --miss values are LINEAR inches off the target, not dial readings, so scope
  tracking correction factors do not apply and this command takes none.

  Options:
    --miss <RANGE:RIGHT[:SIGMA]> Observed horizontal miss (repeatable; e.g.
                                 600:8.5 or 600:8.5:0.75). RANGE follows --units,
                                 RIGHT/SIGMA are inches in BOTH unit systems.
                                 Required. Supply SIGMA on every --miss or none
    -v, --velocity <VEL>         Known muzzle velocity (fps/m/s) [default:
                                 2700/823]
    -b, --bc <BC>                Ballistic coefficient [default: 0.475]
    --drag-model <MODEL>         Drag model (G1/G7) [default: g1]
    -m, --mass <MASS>            Bullet weight (grains/grams)
    -d, --diameter <DIA>         Bullet diameter (inches/mm)
    --twist-rate <TWIST>         Barrel twist (in/turn imperial, mm/turn metric).
                                 Required: without it spin drift would be read
                                 as wind
    --twist-right [<BOOL>]       Right-hand twist [default: true]
    --latitude <LAT>             Firing latitude (degrees). With --shot-direction
                                 this subtracts Coriolis
    --shot-direction <AZ>        Shot azimuth (degrees, 0=N, 90=E). Pairs with
                                 --latitude
    --called-wind <SPEED>        The wind you CALLED (mph/m/s, same sign
                                 convention). Adds a wind-call correction factor
    --zero-distance <DIST>       Zero distance (yd/m) [default: 100]
    --sight-height <HEIGHT>      Sight height above bore (in/mm) [default: 2/50]
    --temperature <T>            Temperature (°F/°C) [default: 59/15]
    --pressure <P>               Pressure (inHg/hPa) [default: 29.92/1013.25]
    --pressure-type <TYPE>       absolute (default) or qnh (reduced vs --altitude)
    --humidity <H>               Humidity (0-100%) [default: 50]
    --altitude <A>               Altitude (ft/m) [default: 0]
    --offline                    Accepted for native-command parity (this command
                                 is local on both surfaces)
    -o, --output <FORMAT>        Output format (table/json/csv) [default: table]"#,
        );
        #[cfg(feature = "wasm-bc-convert")]
        help.push_str(
            r#"

BC Convert Command:
  ballistics bc-convert --source-model <g1|g7> --target-model <g1|g7> [OPTIONS]

  Converts a published BC between the G1 and G7 reference drag families. Scalar
  mode converts one --bc at one --mach or --velocity. Banded mode converts every
  repeated --bc-segment and recommends the better-fitting single-BC family.

  Options:
    --source-model <MODEL>      Drag family used by the supplied BC value(s) [required]
    --target-model <MODEL>      Drag family to convert into [required]
    -b, --bc <BC>               Scalar BC; conflicts with --bc-segment
    --mach <MACH>               Scalar conversion Mach; conflicts with --velocity,
                                --speed-of-sound, and --bc-segment
    --velocity <VEL>            Scalar conversion velocity (fps/m/s); conflicts with
                                --mach and --bc-segment
    --bc-segment <VMIN:VMAX:BC> Velocity-banded BC (repeatable; fps/m/s per --units).
                                Conflicts with --bc, --mach, and --velocity
    --speed-of-sound <VEL>      Speed of sound in the current velocity units; valid with
                                --velocity or banded mode [default: 1116.437 fps / 340.29 m/s]
    -o, --output <FORMAT>       Output format (table/json/csv) [default: table]"#,
        );
        #[cfg(feature = "wasm-estimate-bc")]
        help.push_str(r#"

Estimate BC Command:
  ballistics estimate-bc [OPTIONS]

  Options:
    -v, --velocity <VEL>         Muzzle velocity (fps/m/s)
    -m, --mass <MASS>            Mass (grains/grams)
    -d, --diameter <DIA>         Diameter (inches/mm)
    --data <PAIRS>               Drop data: "dist,drop;..." (yd,in / m,mm)
    --velocity-data <PAIRS>      Velocity data: "dist,vel;..." (yd,fps / m,m/s)
    --drag-model <MODEL>         g1, g7, both, or any single family (g2/g5/g6/g8/gi/gs/ra4) [default: both]
    --zero-range <DIST>          Zero range of the drop data (yd/m). Dope cards are
                                 zeroed — pass this so drop is fit below line of sight.
    --sight-height <H>           Sight height above bore (in/mm) for the zeroed fit
    --temperature <T>            Air temp the data was measured at (°F/°C) [59/15]
    --pressure <P>               Pressure the data was measured at (inHg/hPa) [29.92/1013.25]
    --pressure-type <TYPE>       absolute (default) or qnh (reduced vs --altitude)
    --humidity <H>               Relative humidity (percent) [50]
    --altitude <A>               Altitude the data was measured at (ft/m) [0]

  Prints a BC for each drag model x data basis you supply. For a DOPE CARD, pass
  --zero-range (drop is below line of sight) and set the atmosphere it was made at.
  Without --zero-range, drop is treated as bore-referenced (flat-fire). --velocity-data
  gives a velocity-retention fit (immune to zero/angle). A fit that can't be pinned
  down is flagged UNRELIABLE."#);
        #[cfg(feature = "wasm-lead")]
        help.push_str(
            r#"

Lead Command:
  ballistics lead --target-speed <SPEED> [OPTIONS]

  Options:
    -v, --velocity <VEL>          Muzzle velocity (fps/m/s)
    -b, --bc <BC>                 Ballistic coefficient
    -m, --mass <MASS>             Mass (grains/grams)
    -d, --diameter <DIA>          Diameter (inches/mm)
    --drag-model <MODEL>          Drag model (G1/G2/G5/G6/G7/G8/GI/GS/RA4)
    --cd-scale <FACTOR>            Whole-curve drag scale for a loaded drag table
                                  (1.0 = neutral, typical 0.90-1.10). Requires a
                                  drag table (loadDragTable)
    --sight-height <HEIGHT>       Sight height above bore (inches/mm)
    --temperature <T>             Air temperature (°F/°C) [default: 15°C standard]
    --pressure <P>                Barometric pressure (inHg/hPa) [default: 1013.25 hPa]
    --pressure-type <TYPE>       absolute (default) or qnh (reduced vs --altitude)
    --humidity <H>                Relative humidity (percent) [default: 50]
    --altitude <A>                Altitude (ft/m) [default: 0]
    --wind-speed <SPEED>          Wind speed (mph/m/s) [default: 0]
    --wind-direction <DEG>        Wind direction, degrees, wind-FROM [default: 0]
                                  0=headwind, 90=from right, 180=tailwind, 270=from left;
                                  clock forms accepted (3oc, 10h30, 10:30; 12oc = headwind)
    --use-powder-sensitivity      Enable linear powder temperature sensitivity
    --powder-temp-sensitivity <S> Sensitivity (fps/°F or m/s/°C) [default: 1.0 fps/°F]
    --powder-temp <T>             Powder temperature (°F/°C); curve lookup temp, or
                                  linear-model reference temp [default: 70°F/21°C]
    --powder-temp-curve <T:V,...> Measured powder-temp->velocity curve (overrides
                                  --powder-temp-sensitivity)
    --target-speed <SPEED>        Target speed (mph/m/s) [required]
    --target-angle <DEG>          Direction of target travel, degrees [default: 90]
                                  0=away, 90=left-to-right, 180=toward, 270=right-to-left;
                                  positive lead = hold in direction of travel
    --range <DIST>                Range to target (yards/meters) [default: 500]
    --adjustment-unit <UNIT>      mil/moa/smoa/iphy/clicks [default: mil]; clicks
                                  requires --windage-click-value (MBA-1410)
    --windage-click-value <S>     Turret click graduation for --adjustment-unit clicks,
                                  e.g. 0.25moa or 0.1mil
    --windage-cf <FACTOR>         Windage scope tracking correction factor (MBA-1358,
                                  actual/dialed): the dial-unit lead outputs are
                                  DIVIDED by it (mover lead is a dialed quantity);
                                  the linear lead never is. Strictly between 0.5
                                  and 1.5
    -o, --output <FORMAT>         Output format (table/json) [default: table]

  Time of flight is solved under the supplied wind/atmosphere (wind-aware lead);
  the lead figure itself is pure target motion — wind hold stays separate."#,
        );
        #[cfg(feature = "wasm-powder")]
        help.push_str(
            r#"

Powder Command:
  ballistics powder [OPTIONS]

  Resolves the powder-temperature-adjusted muzzle velocity without running a
  trajectory. A curve carries to trajectory/lead as-is; for the linear model those
  commands additionally need --use-powder-sensitivity (powder always applies it).

  Options:
    -v, --velocity <VEL>          Nominal muzzle velocity (fps/m/s) at the reference
                                  temperature. Required for the linear model; with a
                                  curve it only anchors the reported shift.
    --temperature <T>             Shot-day air temperature (°F/°C); curve lookup
                                  fallback when --powder-temp is unset
    --powder-temp-sensitivity <S> Sensitivity (fps/°F or m/s/°C) [default: 1.0 fps/°F]
    --powder-temp <T>             Powder temperature (°F/°C); curve lookup temp
                                  [default: --temperature], or linear-model reference
                                  temp [default: 70°F/21°C]
    --powder-temp-curve <T:V,...> Measured powder-temp->velocity curve (overrides
                                  --powder-temp-sensitivity; clamped at endpoints)
    --sweep <START:END:STEP>      Velocity table across temperatures (°F/°C)
    -m, --mass <MASS>             Bullet mass (grains/grams): adds muzzle energy
    -o, --output <FORMAT>         Output format (table/json/csv) [default: table]"#,
        );
        #[cfg(feature = "wasm-recoil")]
        help.push_str(
            r#"

Recoil Command:
  ballistics recoil [OPTIONS]

  Free recoil energy, velocity, and impulse from a SAAMI momentum balance: ejecta
  (bullet) + propellant gas recoiling against the firearm. Gas velocity defaults to
  SAAMI's own type-keyed multiplier of the muzzle velocity (rifle 1.75x, pistol/
  average shotgun 1.5x, long-barrel shotgun 1.25x); --gas-velocity-factor and
  --gas-velocity are escape hatches for a different ratio or an absolute constant
  (e.g. the ~4700 fps smokeless rule of thumb).

  Options:
    -b, --bullet-weight <W>       Bullet weight (grains/grams) [required]
    -c, --charge-weight <W>       Powder charge weight (grains/grams) [required]
    -v, --velocity <VEL>          Muzzle velocity (fps/m/s) [required]
    -f, --firearm-weight <W>      Firearm weight incl. attachments (lb/kg) [required]
    --firearm-type <TYPE>         rifle/pistol/shotgun-average/shotgun-long
                                  [default: rifle]
    --gas-velocity-factor <F>     Override: gas velocity = F * muzzle velocity
    --gas-velocity <VEL>          Override: absolute gas velocity (fps/m/s)
    -o, --output <FORMAT>         Output format (table/json/csv) [default: table]"#,
        );
        #[cfg(feature = "wasm-power-factor")]
        help.push_str(
            r#"

Power Factor Command:
  ballistics power-factor [OPTIONS]

  Power factor (weight x velocity / 1000) with per-organization pass/fail against a
  DATA TABLE of published rulebook minimums (USPSA, IDPA, SASS). A load exactly ON a
  threshold PASSES (every rulebook uses "meets or exceeds" language, never a strict
  "greater than"); see CLI_USAGE.md for citations and the truncation convention.

  Options:
    -w, --weight <W>              Bullet weight (grains/grams) [required]
    -v, --velocity <VEL>          Velocity (fps/m/s) [required]
    --organization <ORG>          Filter to one organization: uspsa/idpa/sass
                                  [default: all]
    -o, --output <FORMAT>         Output format (table/json/csv) [default: table]"#,
        );
        help.push_str(
            r#"

Examples:
  ballistics trajectory -v 2700 -b 0.475 -m 168 -d 0.308
  ballistics trajectory --auto-zero 200 --enable-spin-drift
  ballistics --units metric trajectory -v 823 -b 0.475 -m 10.9"#,
        );
        #[cfg(feature = "wasm-zero")]
        help.push_str(
            r#"
  ballistics zero --target-distance 300"#,
        );
        #[cfg(feature = "wasm-bc-convert")]
        help.push_str(
            r#"
  ballistics bc-convert --source-model g1 --target-model g7 -b 0.475 --velocity 2700
  ballistics bc-convert --source-model g1 --target-model g7 \
    --bc-segment 2500:3000:0.475 --bc-segment 1500:2500:0.465 -o json"#,
        );
        #[cfg(feature = "wasm-estimate-bc")]
        help.push_str(
            r#"
  ballistics estimate-bc -v 2700 -m 168 -d 0.308 --data "100,2.1;200,9.4;300,22.8"
  ballistics estimate-bc -v 2650 -m 77 -d 0.224 --data "300,29;500,89.9" \
    --velocity-data "300,1980;500,1560" --drag-model both"#,
        );
        #[cfg(feature = "wasm-monte-carlo")]
        help.push_str(
            r#"
  ballistics monte-carlo -n 1000 --velocity-std 10
  ballistics monte-carlo -v 2700 -b 0.475 -m 168 -d 0.308 --wez \
    --target-size 18x30 -n 300 --wez-start 200 --wez-end 500 --wez-step 100"#,
        );
        #[cfg(feature = "wasm-truing")]
        help.push_str(
            r#"
  ballistics true-velocity --range 300 --measured-drop 1.8 -b 0.475 -m 168 -d 0.308
  ballistics true-velocity --range 300 --measured-drop 1.8 --observed 600:5.1 \
    --observed 900:10.9 -b 0.475 -m 168 -d 0.308 --chrono-velocity 2700
  ballistics true-wind --miss 500:12.4 --miss 700:26.8 -v 2700 -b 0.475 -m 168 \
    -d 0.308 --drag-model g7 --twist-rate 11 --called-wind 6"#,
        );
        #[cfg(feature = "wasm-reticle")]
        help.push_str(
            r#"
  ballistics reticle generate tree --rows 6 --row-spacing 1 --spread-step 0.5 -o json
  ballistics reticle hold --mag 6 --drop-mil 4.2 --wind-mil 1.1 --reticle-json \
    '{"name":"demo","focal_plane":"sfp","reference_magnification":12,
      "marks":[{"down_mil":0,"right_mil":0,"kind":"center"},
               {"down_mil":2,"right_mil":0,"kind":"hash"}]}'"#,
        );
        #[cfg(feature = "wasm-recoil")]
        help.push_str(
            r#"
  ballistics recoil -b 168 -c 43 -v 2700 -f 8.5"#,
        );
        #[cfg(feature = "wasm-power-factor")]
        help.push_str(
            r#"
  ballistics power-factor -w 147 -v 900 --organization uspsa"#,
        );
        help
    }
}

// ============================================================================
// Object-Oriented API
// ============================================================================

/// Object-oriented calculator for programmatic use
/// Provides a type-safe, fluent API alternative to the CLI interface
#[wasm_bindgen]
pub struct Calculator {
    // Projectile properties
    bc: f64,
    velocity_fps: f64,
    mass_grains: f64,
    diameter_inches: f64,
    drag_model: String,

    // Environmental conditions
    wind_speed_mph: f64,
    wind_direction_deg: f64,
    // Downrange wind segments as (speed_mph, angle_deg, until_yards); when non-empty
    // these are emitted as --wind-segment flags and override the scalar wind above.
    wind_segments: Vec<(f64, f64, f64)>,
    temperature_f: f64,
    pressure_inhg: f64,
    humidity_percent: f64,
    altitude_ft: f64,

    // Shooting parameters
    sight_height_inches: f64,
    zero_range_yards: Option<f64>,
    max_range_yards: f64,

    // Advanced options
    enable_spin_drift: bool,
    enable_coriolis: bool,
    twist_rate_inches: Option<f64>,
    latitude_deg: Option<f64>,

    // Ground-impact handling. The solver stops the trajectory when the projectile reaches
    // the ground plane, which sits `bore_height` below the muzzle and defaults to 60 in
    // (5 ft). For a typical .308 that terminates the solve around 516 yd, so a long-range
    // request silently came back short: `calculateTrajectory(1000)` returned the impact
    // point, which reports its true `range_yards` but carries no other signal. Both knobs
    // exist on the `trajectory` command; they had no builder equivalent until now.
    bore_height_inches: Option<f64>,
    ignore_ground_impact: bool,

    // MBA-1368: wind entry frame ("shooter" | "compass") and the shot's compass
    // bearing. Both additive — no existing method signature changed (R6).
    wind_reference: Option<String>,
    shot_direction_deg: Option<f64>,
}

#[wasm_bindgen]
impl Calculator {
    /// Create a new calculator with default values
    /// Defaults: .308 Winchester 168gr at 2700 fps, standard atmosphere
    #[wasm_bindgen(constructor)]
    pub fn new() -> Self {
        Calculator {
            bc: 0.475,
            velocity_fps: 2700.0,
            mass_grains: 168.0,
            diameter_inches: 0.308,
            drag_model: "G1".to_string(), // G1 matches the G1-scale default BC (0.475) and the CLI default

            wind_speed_mph: 0.0,
            wind_direction_deg: 0.0, // wind-FROM convention: 0 = headwind, matching the CLI/trajectory defaults
            wind_segments: Vec::new(),
            temperature_f: 59.0,
            pressure_inhg: 29.92,
            humidity_percent: 50.0,
            altitude_ft: 0.0,

            sight_height_inches: 2.0,
            zero_range_yards: None,
            max_range_yards: 1000.0,

            enable_spin_drift: false,
            enable_coriolis: false,
            twist_rate_inches: None,
            latitude_deg: None,

            // None = defer to the trajectory command's own 60 in default, so an existing
            // caller that never touches these keeps byte-identical output.
            bore_height_inches: None,
            ignore_ground_impact: false,

            wind_reference: None,
            shot_direction_deg: None,
        }
    }

    // Projectile property setters (fluent API)

    #[wasm_bindgen(js_name = setBC)]
    pub fn set_bc(mut self, bc: f64) -> Self {
        self.bc = bc;
        self
    }

    #[wasm_bindgen(js_name = setVelocity)]
    pub fn set_velocity(mut self, velocity_fps: f64) -> Self {
        self.velocity_fps = velocity_fps;
        self
    }

    #[wasm_bindgen(js_name = setMass)]
    pub fn set_mass(mut self, mass_grains: f64) -> Self {
        self.mass_grains = mass_grains;
        self
    }

    #[wasm_bindgen(js_name = setDiameter)]
    pub fn set_diameter(mut self, diameter_inches: f64) -> Self {
        self.diameter_inches = diameter_inches;
        self
    }

    #[wasm_bindgen(js_name = setDragModel)]
    pub fn set_drag_model(mut self, model: &str) -> Self {
        self.drag_model = model.to_string();
        self
    }

    // Environmental setters

    #[wasm_bindgen(js_name = setWind)]
    pub fn set_wind(mut self, speed_mph: f64, direction_deg: f64) -> Self {
        self.wind_speed_mph = speed_mph;
        self.wind_direction_deg = direction_deg;
        self
    }

    /// Add a downrange wind segment: `speed_mph` from `direction_deg`
    /// (wind-FROM: 0 = headwind, 90 = from the right) out to `until_yards`.
    /// Each segment applies from the previous boundary to `until_yards`; wind is
    /// zero beyond the last segment. When any segment is added it overrides the
    /// scalar `setWind` value. Repeatable.
    #[wasm_bindgen(js_name = addWindSegment)]
    pub fn add_wind_segment(
        mut self,
        speed_mph: f64,
        direction_deg: f64,
        until_yards: f64,
    ) -> Self {
        self.wind_segments
            .push((speed_mph, direction_deg, until_yards));
        self
    }

    /// Remove all downrange wind segments (reverts to the scalar `setWind`).
    #[wasm_bindgen(js_name = clearWindSegments)]
    pub fn clear_wind_segments(mut self) -> Self {
        self.wind_segments.clear();
        self
    }

    /// MBA-1368: choose the wind entry frame — "shooter" (default; wind-FROM angles
    /// relative to the line of fire) or "compass" (earth-fixed bearings, 0 = north,
    /// covering `setWind` AND every `addWindSegment` direction, re-referenced against
    /// the shot azimuth at solve time). Compass mode requires `setShotDirection`;
    /// invalid values surface when the command runs. Additive method — no existing
    /// signature changed.
    #[wasm_bindgen(js_name = setWindReference)]
    pub fn set_wind_reference(mut self, mode: &str) -> Self {
        self.wind_reference = Some(mode.to_string());
        self
    }

    /// MBA-1368: compass bearing of the shot (degrees, 0 = north, 90 = east) —
    /// required by `setWindReference("compass")`; also feeds Coriolis when enabled.
    #[wasm_bindgen(js_name = setShotDirection)]
    pub fn set_shot_direction(mut self, bearing_deg: f64) -> Self {
        self.shot_direction_deg = Some(bearing_deg);
        self
    }

    #[wasm_bindgen(js_name = setTemperature)]
    pub fn set_temperature(mut self, temp_f: f64) -> Self {
        self.temperature_f = temp_f;
        self
    }

    #[wasm_bindgen(js_name = setPressure)]
    pub fn set_pressure(mut self, pressure_inhg: f64) -> Self {
        self.pressure_inhg = pressure_inhg;
        self
    }

    #[wasm_bindgen(js_name = setHumidity)]
    pub fn set_humidity(mut self, humidity: f64) -> Self {
        self.humidity_percent = humidity;
        self
    }

    #[wasm_bindgen(js_name = setAltitude)]
    pub fn set_altitude(mut self, altitude_ft: f64) -> Self {
        self.altitude_ft = altitude_ft;
        self
    }

    // Shooting parameter setters

    #[wasm_bindgen(js_name = setSightHeight)]
    pub fn set_sight_height(mut self, height_inches: f64) -> Self {
        self.sight_height_inches = height_inches;
        self
    }

    #[wasm_bindgen(js_name = setZeroRange)]
    pub fn set_zero_range(mut self, range_yards: f64) -> Self {
        self.zero_range_yards = Some(range_yards);
        self
    }

    #[wasm_bindgen(js_name = setMaxRange)]
    pub fn set_max_range(mut self, range_yards: f64) -> Self {
        self.max_range_yards = range_yards;
        self
    }

    // Advanced option setters

    #[wasm_bindgen(js_name = enableSpinDrift)]
    pub fn enable_spin_drift_opt(mut self, enabled: bool, twist_rate: Option<f64>) -> Self {
        self.enable_spin_drift = enabled;
        self.twist_rate_inches = twist_rate;
        self
    }

    /// Height of the bore above the ground, in inches (default 60 = 5 ft). The solve stops
    /// when the projectile falls this far below the muzzle, so raising it pushes the
    /// ground-impact cutoff further downrange. Use [`Self::ignore_ground_impact`] to remove
    /// the cutoff entirely rather than setting an implausible height.
    #[wasm_bindgen(js_name = setBoreHeight)]
    pub fn set_bore_height(mut self, height_inches: f64) -> Self {
        self.bore_height_inches = Some(height_inches);
        self
    }

    /// Solve all the way to the requested range instead of stopping at ground impact.
    ///
    /// Without this, `calculateTrajectory(range)` returns the closest point it actually
    /// solved, which for a typical .308 is around 516 yd — short of a 1000 yd request, and
    /// reported only by the `range_yards` field of the returned object.
    #[wasm_bindgen(js_name = ignoreGroundImpact)]
    pub fn ignore_ground_impact(mut self, ignore: bool) -> Self {
        self.ignore_ground_impact = ignore;
        self
    }

    #[wasm_bindgen(js_name = enableCoriolis)]
    pub fn enable_coriolis_opt(mut self, enabled: bool, latitude: Option<f64>) -> Self {
        self.enable_coriolis = enabled;
        self.latitude_deg = latitude;
        self
    }

    // Calculation method

    /// Calculate trajectory and return result as JavaScript object
    /// Returns: { range_yards, drop_inches, drift_inches, velocity_fps, energy_ftlb, time_seconds }
    /// (`drift_inches`, not `windage_inches` -- the wrong name here is what a wasm test was
    /// written against, and it failed on a field that has never existed. MBA-1535.)
    #[wasm_bindgen(js_name = calculateTrajectory)]
    pub fn calculate_trajectory(&self, range_yards: f64) -> Result<JsValue, JsValue> {
        // Build CLI command from parameters
        let mut cmd = format!(
            "ballistics trajectory -v {} -b {} -m {} -d {} --drag-model {} --max-range {}",
            self.velocity_fps,
            self.bc,
            self.mass_grains,
            self.diameter_inches,
            self.drag_model,
            range_yards
        );

        // Add environmental parameters
        if self.wind_speed_mph > 0.0 {
            cmd.push_str(&format!(
                " --wind-speed {} --wind-direction {}",
                self.wind_speed_mph, self.wind_direction_deg
            ));
        }
        for (speed_mph, direction_deg, until_yards) in &self.wind_segments {
            cmd.push_str(&format!(
                " --wind-segment {}:{}:{}",
                speed_mph, direction_deg, until_yards
            ));
        }
        // MBA-1368: emit the entry frame + shot bearing whenever set (the trajectory
        // handler validates the pairing and values).
        if let Some(bearing) = self.shot_direction_deg {
            cmd.push_str(&format!(" --shot-direction {}", bearing));
        }
        if let Some(reference) = &self.wind_reference {
            cmd.push_str(&format!(" --wind-ref {}", reference));
        }

        cmd.push_str(&format!(
            " --temperature {} --pressure {} --humidity {} --altitude {}",
            self.temperature_f, self.pressure_inhg, self.humidity_percent, self.altitude_ft
        ));

        // Add shooting parameters
        cmd.push_str(&format!(" --sight-height {}", self.sight_height_inches));

        if let Some(zero) = self.zero_range_yards {
            cmd.push_str(&format!(" --auto-zero {}", zero));
        }

        // Add advanced options
        if self.enable_spin_drift {
            cmd.push_str(" --enable-spin-drift");
            if let Some(twist) = self.twist_rate_inches {
                cmd.push_str(&format!(" --twist-rate {}", twist));
            }
        }

        if self.enable_coriolis {
            cmd.push_str(" --enable-coriolis");
            if let Some(lat) = self.latitude_deg {
                cmd.push_str(&format!(" --latitude {}", lat));
            }
        }

        if let Some(bore_height) = self.bore_height_inches {
            cmd.push_str(&format!(" --bore-height {}", bore_height));
        }

        if self.ignore_ground_impact {
            cmd.push_str(" --ignore-ground-impact");
        }

        // Use JSON output format for easy parsing
        cmd.push_str(" -o json");

        // Execute command
        let wasm_ballistics = WasmBallistics::new();
        let result_str = wasm_ballistics.run_command(&cmd)?;

        // Strip any text before the JSON (like zero info messages)
        let json_str = if let Some(json_start) = result_str.find('{') {
            &result_str[json_start..]
        } else {
            &result_str
        };

        // Parse JSON result
        let json_result: serde_json::Value = serde_json::from_str(json_str).map_err(|e| {
            JsValue::from_str(&format!(
                "JSON parse error: {}. Result was: {}",
                e,
                &json_str[..json_str.len().min(500)]
            ))
        })?;

        // Find the point closest to the requested range
        if let Some(trajectory) = json_result.get("trajectory").and_then(|t| t.as_array()) {
            let target_point = trajectory
                .iter()
                .min_by_key(|p| {
                    let range = p.get("range_yards").and_then(|r| r.as_f64()).unwrap_or(0.0);
                    ((range - range_yards).abs() * 100.0) as i64
                })
                .ok_or_else(|| JsValue::from_str("No trajectory points found"))?;

            // Manually construct JavaScript object to avoid Map conversion
            let result = js_sys::Object::new();
            js_sys::Reflect::set(
                &result,
                &"range_yards".into(),
                &target_point
                    .get("range_yards")
                    .and_then(|v| v.as_f64())
                    .unwrap_or(0.0)
                    .into(),
            )?;
            js_sys::Reflect::set(
                &result,
                &"drop_inches".into(),
                &target_point
                    .get("drop_inches")
                    .and_then(|v| v.as_f64())
                    .unwrap_or(0.0)
                    .into(),
            )?;
            js_sys::Reflect::set(
                &result,
                &"drift_inches".into(),
                &target_point
                    .get("drift_inches")
                    .and_then(|v| v.as_f64())
                    .unwrap_or(0.0)
                    .into(),
            )?;
            js_sys::Reflect::set(
                &result,
                &"velocity_fps".into(),
                &target_point
                    .get("velocity_fps")
                    .and_then(|v| v.as_f64())
                    .unwrap_or(0.0)
                    .into(),
            )?;
            js_sys::Reflect::set(
                &result,
                &"energy_ftlb".into(),
                &target_point
                    .get("energy_ftlb")
                    .and_then(|v| v.as_f64())
                    .unwrap_or(0.0)
                    .into(),
            )?;
            js_sys::Reflect::set(
                &result,
                &"time_seconds".into(),
                &target_point
                    .get("time_seconds")
                    .and_then(|v| v.as_f64())
                    .unwrap_or(0.0)
                    .into(),
            )?;

            Ok(result.into())
        } else {
            Err(JsValue::from_str("Invalid trajectory data"))
        }
    }

    /// Get full trajectory table as array of points
    /// Returns array of: [{ range_yards, drop_inches, windage_inches, velocity_fps, energy_ftlb, time_sec }, ...]
    ///
    /// ⚠️ DIFFERENT KEYS FROM [`Self::calculate_trajectory`], which answers `drift_inches`
    /// and `time_seconds`. The two have never agreed and the difference is load-bearing for
    /// existing embedders, so it is documented here rather than quietly unified (MBA-1535).
    #[wasm_bindgen(js_name = getFullTrajectory)]
    pub fn get_full_trajectory(&self) -> Result<JsValue, JsValue> {
        // Build CLI command (similar to calculate_trajectory but get full table)
        let mut cmd = format!(
            "ballistics trajectory -v {} -b {} -m {} -d {} --drag-model {} --max-range {} --full",
            self.velocity_fps,
            self.bc,
            self.mass_grains,
            self.diameter_inches,
            self.drag_model,
            self.max_range_yards
        );

        // Add environmental parameters
        if self.wind_speed_mph > 0.0 {
            cmd.push_str(&format!(
                " --wind-speed {} --wind-direction {}",
                self.wind_speed_mph, self.wind_direction_deg
            ));
        }
        for (speed_mph, direction_deg, until_yards) in &self.wind_segments {
            cmd.push_str(&format!(
                " --wind-segment {}:{}:{}",
                speed_mph, direction_deg, until_yards
            ));
        }
        // MBA-1368: emit the entry frame + shot bearing whenever set (the trajectory
        // handler validates the pairing and values).
        if let Some(bearing) = self.shot_direction_deg {
            cmd.push_str(&format!(" --shot-direction {}", bearing));
        }
        if let Some(reference) = &self.wind_reference {
            cmd.push_str(&format!(" --wind-ref {}", reference));
        }

        cmd.push_str(&format!(
            " --temperature {} --pressure {} --humidity {} --altitude {}",
            self.temperature_f, self.pressure_inhg, self.humidity_percent, self.altitude_ft
        ));

        cmd.push_str(&format!(" --sight-height {}", self.sight_height_inches));

        if let Some(zero) = self.zero_range_yards {
            cmd.push_str(&format!(" --auto-zero {}", zero));
        }

        if self.enable_spin_drift {
            cmd.push_str(" --enable-spin-drift");
            if let Some(twist) = self.twist_rate_inches {
                cmd.push_str(&format!(" --twist-rate {}", twist));
            }
        }

        if self.enable_coriolis {
            cmd.push_str(" --enable-coriolis");
            if let Some(lat) = self.latitude_deg {
                cmd.push_str(&format!(" --latitude {}", lat));
            }
        }

        if let Some(bore_height) = self.bore_height_inches {
            cmd.push_str(&format!(" --bore-height {}", bore_height));
        }

        if self.ignore_ground_impact {
            cmd.push_str(" --ignore-ground-impact");
        }

        cmd.push_str(" -o json");

        // Execute command
        let wasm_ballistics = WasmBallistics::new();
        let result_str = wasm_ballistics.run_command(&cmd)?;

        // Strip any text before the JSON (like zero info messages)
        let json_str = if let Some(json_start) = result_str.find('{') {
            &result_str[json_start..]
        } else {
            &result_str
        };

        // Parse JSON result and return trajectory array
        let json_result: serde_json::Value = serde_json::from_str(json_str).map_err(|e| {
            JsValue::from_str(&format!(
                "JSON parse error: {}. Result: {}",
                e,
                &json_str[..json_str.len().min(500)]
            ))
        })?;

        if let Some(trajectory) = json_result.get("trajectory") {
            // Convert trajectory array to JavaScript array of plain objects
            let js_array = js_sys::Array::new();

            if let Some(points) = trajectory.as_array() {
                for point in points {
                    let js_point = js_sys::Object::new();

                    // Extract each field and add to JavaScript object
                    if let Some(range) = point.get("range_yards").and_then(|v| v.as_f64()) {
                        js_sys::Reflect::set(&js_point, &"range_yards".into(), &range.into())?;
                    }
                    if let Some(drop) = point.get("drop_inches").and_then(|v| v.as_f64()) {
                        js_sys::Reflect::set(&js_point, &"drop_inches".into(), &drop.into())?;
                    }
                    // The JSON producer emits "drift_inches"/"time_seconds"; read those (the old
                    // "windage_inches"/"time_sec" lookups always missed, dropping both fields).
                    // Keep the public output keys (windage_inches/time_sec) unchanged.
                    if let Some(windage) = point.get("drift_inches").and_then(|v| v.as_f64()) {
                        js_sys::Reflect::set(&js_point, &"windage_inches".into(), &windage.into())?;
                    }
                    if let Some(velocity) = point.get("velocity_fps").and_then(|v| v.as_f64()) {
                        js_sys::Reflect::set(&js_point, &"velocity_fps".into(), &velocity.into())?;
                    }
                    if let Some(energy) = point.get("energy_ftlb").and_then(|v| v.as_f64()) {
                        js_sys::Reflect::set(&js_point, &"energy_ftlb".into(), &energy.into())?;
                    }
                    if let Some(time) = point.get("time_seconds").and_then(|v| v.as_f64()) {
                        js_sys::Reflect::set(&js_point, &"time_sec".into(), &time.into())?;
                    }

                    js_array.push(&js_point);
                }
            }

            Ok(js_array.into())
        } else {
            Err(JsValue::from_str("No trajectory data found"))
        }
    }
}

/// The engine's versioned JSON command bridge, as one JavaScript function.
///
/// One request envelope in, one response envelope out, both as strings:
///
/// ```text
/// in:   {"api_version":1,"command":"solve","request":{ … }}
/// ok:   {"ok":true,"api_version":1,"engine_version":"…","command":"solve","result":{ … }}
/// err:  {"ok":false,"api_version":1,"engine_version":"…","error":{"code":"…","message":"…"}}
/// ```
///
/// This is the module's programmatic surface, deliberately separate from the
/// browser terminal above. The terminal's commands are per-feature gated because a
/// stripped build is a smaller download; the bridge is not gateable that way — it
/// is a single entry point onto every command the build actually contains, and it
/// costs nothing but serde, which is already a core dependency.
///
/// It is the ONLY route from JavaScript to `corrections.bc5d_table_path` and
/// `atmosphere.pressure_reference`, and the only one that validates
/// `effects.wind_shear_model` against a typed enum rather than silently resolving
/// an unrecognised name to the power law.
///
/// Failures arrive INSIDE the returned JSON — this never throws. Ask
/// `meta.capabilities` for the command list, which depends on what this build
/// compiled in rather than on what the bridge knows how to dispatch.
#[cfg(feature = "bridge")]
#[wasm_bindgen(js_name = bridgeCall)]
pub fn bridge_call(request_json: &str) -> String {
    crate::bridge::bridge_call(request_json)
}
