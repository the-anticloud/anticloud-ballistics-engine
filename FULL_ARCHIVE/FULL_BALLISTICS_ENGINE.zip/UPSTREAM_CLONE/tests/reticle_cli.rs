//! MBA-1361: the `reticle` command family end to end — generators, the hold point, the
//! saved-profile attachment, and the solve-json wire block.
//!
//! The library-level focal-plane / nearest-mark / off-reticle math is pinned in
//! `src/reticle.rs`'s own tests; this file pins the SURFACES: that the native binary emits
//! the shared formatter verbatim (the `drag_curve_cli` contract, for the same MBA-1418
//! reason), that `generate -o json` round-trips into `hold --reticle-json` and
//! `profile save --reticle-json`, and that a request without a `reticle` block leaves the
//! solve-json response byte-identical.
//!
//! Hermetic: profiles live under `$HOME/.ballistics/profiles`, so every profile invocation
//! points `HOME` at a private temp dir (same pattern as `tests/dsf_profile_cli.rs`).

use std::process::Command;

use ballistics_engine::reticle::{
    format_reticle_description, format_reticle_hold, hold_point_in_reticle, FocalPlane, MarkKind,
    ReticleDescription, ReticleFormat, ReticleMark,
};
use ballistics_engine::reticle_import::import_ventum_reticle;

const BIN: &str = env!("CARGO_BIN_EXE_ballistics");

fn tempfile_dir(tag: &str) -> std::path::PathBuf {
    use std::sync::atomic::{AtomicU32, Ordering};
    static N: AtomicU32 = AtomicU32::new(0);
    let dir = std::env::temp_dir().join(format!(
        "reticle-cli-{tag}-{}-{}",
        std::process::id(),
        N.fetch_add(1, Ordering::Relaxed)
    ));
    std::fs::create_dir_all(&dir).unwrap();
    dir
}

fn run(args: &[&str]) -> (String, String, bool) {
    let output = Command::new(BIN).args(args).output().expect("reticle");
    (
        String::from_utf8_lossy(&output.stdout).into_owned(),
        String::from_utf8_lossy(&output.stderr).into_owned(),
        output.status.success(),
    )
}

fn sfp_fixture() -> ReticleDescription {
    ReticleDescription {
        name: "fixture".to_string(),
        focal_plane: FocalPlane::Second,
        reference_magnification: 10.0,
        marks: vec![
            ReticleMark::new(0.0, 0.0, MarkKind::Center),
            ReticleMark::new(2.0, 0.0, MarkKind::Hash),
            ReticleMark::new(4.0, 0.0, MarkKind::Hash),
            ReticleMark::new(2.0, 1.0, MarkKind::Dot),
        ],
    }
}

fn write_fixture(dir: &std::path::Path, reticle: &ReticleDescription) -> std::path::PathBuf {
    let path = dir.join("reticle.json");
    std::fs::write(&path, serde_json::to_string(reticle).unwrap()).unwrap();
    path
}

/// The binary's stdout IS the shared formatter's string, byte for byte, for both the hold
/// and the description renderings. Equality rather than fragment checks, because a
/// fragment check is exactly what let the `recoil` CSV header divergence survive.
#[test]
fn native_output_is_the_shared_formatter_verbatim() {
    let dir = tempfile_dir("formatter");
    let reticle = sfp_fixture();
    let path = write_fixture(&dir, &reticle);

    for (flag, format) in [
        ("table", ReticleFormat::Table),
        ("json", ReticleFormat::Json),
    ] {
        let (stdout, stderr, ok) = run(&[
            "reticle",
            "hold",
            "--reticle-json",
            path.to_str().unwrap(),
            "--drop-mil",
            "3.6",
            "--wind-mil",
            "1.4",
            "--mag",
            "5",
            "-o",
            flag,
        ]);
        assert!(ok, "hold -o {flag} failed: {stderr}");
        let expected = format_reticle_hold(
            &hold_point_in_reticle(3.6, 1.4, 5.0, &reticle).unwrap(),
            &reticle,
            5.0,
            format,
        );
        assert_eq!(
            stdout, expected,
            "hold -o {flag} must be the shared formatter"
        );
    }

    for (flag, format) in [
        ("table", ReticleFormat::Table),
        ("json", ReticleFormat::Json),
    ] {
        let (stdout, stderr, ok) = run(&[
            "reticle",
            "generate",
            "mil-grid",
            "--spacing",
            "1",
            "--extent",
            "5",
            "-o",
            flag,
        ]);
        assert!(ok, "generate -o {flag} failed: {stderr}");
        let expected =
            format_reticle_description(&ReticleDescription::mil_grid(1.0, 5.0).unwrap(), format);
        assert_eq!(
            stdout, expected,
            "generate -o {flag} must be the shared formatter"
        );
    }
}

/// `generate -o json` emits exactly what `hold --reticle-json` consumes — the round trip
/// the two commands are advertised to form.
#[test]
fn generate_json_round_trips_into_hold() {
    let dir = tempfile_dir("roundtrip");
    let (stdout, stderr, ok) = run(&[
        "reticle",
        "generate",
        "tree",
        "--rows",
        "4",
        "--row-spacing",
        "1.0",
        "--spread-step",
        "0.5",
        "--name",
        "generated",
        "-o",
        "json",
    ]);
    assert!(ok, "generate failed: {stderr}");
    let parsed: ReticleDescription = serde_json::from_str(&stdout).unwrap();
    assert_eq!(parsed.name, "generated");

    let path = dir.join("tree.json");
    std::fs::write(&path, &stdout).unwrap();
    let (hold_out, stderr, ok) = run(&[
        "reticle",
        "hold",
        "--reticle-json",
        path.to_str().unwrap(),
        "--drop-mil",
        "3.0",
        "--wind-mil",
        "1.5",
        "--mag",
        "10",
    ]);
    assert!(ok, "hold failed: {stderr}");
    // Row 3 (down 3.0) carries dots at +/-0.5, 1.0, 1.5 — the hold lands exactly on one.
    assert!(
        hold_out.contains("distance from hold: 0.000 mil"),
        "{hold_out}"
    );
}

/// SFP subtension rescaling is visible through the CLI, not just the library: the same
/// hold reads a different mark at a different magnification.
#[test]
fn sfp_rescaling_changes_the_named_mark_through_the_cli() {
    let dir = tempfile_dir("sfp");
    let path = write_fixture(&dir, &sfp_fixture());
    let hold_at = |mag: &str| {
        let (stdout, stderr, ok) = run(&[
            "reticle",
            "hold",
            "--reticle-json",
            path.to_str().unwrap(),
            "--drop-mil",
            "4.0",
            "--mag",
            mag,
            "-o",
            "json",
        ]);
        assert!(ok, "hold at {mag}x failed: {stderr}");
        serde_json::from_str::<serde_json::Value>(&stdout).unwrap()
    };

    // At the reference magnification, 4 mil is the 4 mil mark (index 2).
    let at_reference = hold_at("10");
    assert_eq!(at_reference["nearest_mark"]["index"], 2);
    assert_eq!(at_reference["mark_scale"], 1.0);

    // At half of it the etched 2 mil mark covers 4 mil, so the same hold reads mark 1.
    let at_half = hold_at("5");
    assert_eq!(at_half["nearest_mark"]["index"], 1);
    assert_eq!(at_half["mark_scale"], 2.0);
    assert_eq!(at_half["nearest_mark"]["true_down_mil"], 4.0);
    // The hold point itself never moves — only the marks are rescaled.
    assert_eq!(at_half["hold"]["down_mil"], 4.0);
    assert_eq!(at_reference["hold"]["down_mil"], 4.0);
}

/// An FFP reticle reads the same mark at every magnification.
#[test]
fn ffp_hold_is_magnification_invariant_through_the_cli() {
    let dir = tempfile_dir("ffp");
    let mut reticle = sfp_fixture();
    reticle.focal_plane = FocalPlane::First;
    let path = write_fixture(&dir, &reticle);

    let mut seen = Vec::new();
    for mag in ["3", "10", "25"] {
        let (stdout, stderr, ok) = run(&[
            "reticle",
            "hold",
            "--reticle-json",
            path.to_str().unwrap(),
            "--drop-mil",
            "3.6",
            "--mag",
            mag,
            "-o",
            "json",
        ]);
        assert!(ok, "hold at {mag}x failed: {stderr}");
        let mut value: serde_json::Value = serde_json::from_str(&stdout).unwrap();
        // Everything except the echoed magnification must be identical.
        value["magnification"] = serde_json::Value::Null;
        seen.push(value);
    }
    assert_eq!(seen[0], seen[1]);
    assert_eq!(seen[1], seen[2]);
}

/// `--range` solves the trajectory and reads the hold off it, and the answer is the drop
/// `come-ups` reports for the same load and zero (both go through one hold curve).
#[test]
fn range_solve_matches_the_come_ups_drop() {
    let dir = tempfile_dir("range");
    let path = write_fixture(&dir, &ReticleDescription::mil_grid(1.0, 12.0).unwrap());
    let (stdout, stderr, ok) = run(&[
        "reticle",
        "hold",
        "--reticle-json",
        path.to_str().unwrap(),
        "--range",
        "600",
        "--mag",
        "10",
        "-v",
        "2700",
        "-b",
        "0.475",
        "-m",
        "168",
        "-d",
        "0.308",
        "--zero-distance",
        "100",
        "-o",
        "json",
    ]);
    assert!(ok, "range solve failed: {stderr}");
    let hold: serde_json::Value = serde_json::from_str(&stdout).unwrap();
    let down = hold["hold"]["down_mil"].as_f64().unwrap();

    let (come_ups, stderr, ok) = run(&[
        "come-ups",
        "-v",
        "2700",
        "-b",
        "0.475",
        "-m",
        "168",
        "-d",
        "0.308",
        "--zero-distance",
        "100",
        "--start",
        "600",
        "--end",
        "600",
        "--step",
        "100",
        "-o",
        "json",
    ]);
    assert!(ok, "come-ups failed: {stderr}");
    let rows: serde_json::Value = serde_json::from_str(&come_ups).unwrap();
    let expected = rows["data"][0]["drop"]
        .as_f64()
        .unwrap_or_else(|| panic!("come-ups shape changed: {come_ups}"));
    assert!(
        (down - expected).abs() < 0.02,
        "reticle --range drop {down} mil should match the come-up {expected} mil"
    );
}

/// Contradictory and incomplete invocations are rejected rather than silently resolved.
#[test]
fn rejects_ambiguous_and_incomplete_invocations() {
    let dir = tempfile_dir("reject");
    let path = write_fixture(&dir, &sfp_fixture());
    let p = path.to_str().unwrap();

    // Both hold sources at once.
    let (_, stderr, ok) = run(&[
        "reticle",
        "hold",
        "--reticle-json",
        p,
        "--drop-mil",
        "1",
        "--range",
        "500",
    ]);
    assert!(!ok);
    assert!(stderr.contains("mutually exclusive"), "{stderr}");

    // Neither hold source.
    let (_, stderr, ok) = run(&["reticle", "hold", "--reticle-json", p]);
    assert!(!ok);
    assert!(stderr.contains("firing solution is required"), "{stderr}");

    // No reticle at all.
    let (_, stderr, ok) = run(&["reticle", "hold", "--drop-mil", "1"]);
    assert!(!ok);
    assert!(stderr.contains("reticle is required"), "{stderr}");

    // --wind-mil is meaningless with --range (the wind comes from the wind flags there).
    let (_, stderr, ok) = run(&[
        "reticle",
        "hold",
        "--reticle-json",
        p,
        "--range",
        "500",
        "--wind-mil",
        "1",
    ]);
    assert!(!ok);
    assert!(
        stderr.contains("--wind-mil applies to --drop-mil only"),
        "{stderr}"
    );

    // --range without a load.
    let (_, stderr, ok) = run(&["reticle", "hold", "--reticle-json", p, "--range", "500"]);
    assert!(!ok);
    assert!(stderr.contains("--range requires"), "{stderr}");

    // Non-physical magnification (rejected on both planes).
    let (_, stderr, ok) = run(&[
        "reticle",
        "hold",
        "--reticle-json",
        p,
        "--drop-mil",
        "1",
        "--mag",
        "0",
    ]);
    assert!(!ok, "{stderr}");

    // CSV/PDF have no reticle form.
    for format in ["csv", "pdf"] {
        let (_, stderr, ok) = run(&[
            "reticle",
            "hold",
            "--reticle-json",
            p,
            "--drop-mil",
            "1",
            "-o",
            format,
        ]);
        assert!(!ok);
        assert!(stderr.contains("no "), "{stderr}");
    }

    // A malformed description file is rejected at the flag that named it.
    let bad = dir.join("bad.json");
    std::fs::write(&bad, "{\"name\":\"x\"}").unwrap();
    let (_, stderr, ok) = run(&[
        "reticle",
        "hold",
        "--reticle-json",
        bad.to_str().unwrap(),
        "--drop-mil",
        "1",
    ]);
    assert!(!ok);
    assert!(stderr.contains("invalid reticle JSON"), "{stderr}");
}

/// A reticle attaches to a saved profile, survives an unrelated re-save, and clears on
/// request — the same three-way treatment the DSF table gets.
#[test]
fn profile_attachment_round_trips_and_carries_forward() {
    let home = tempfile_dir("profile");
    let reticle = sfp_fixture();
    let path = write_fixture(&home, &reticle);

    let save = |extra: &[&str]| {
        let mut args: Vec<&str> = vec![
            "profile", "save", "scoped", "-v", "2700", "-b", "0.475", "-m", "168", "-d", "0.308",
        ];
        args.extend_from_slice(extra);
        let output = Command::new(BIN)
            .env("HOME", &home)
            .args(&args)
            .output()
            .expect("profile save");
        assert!(
            output.status.success(),
            "profile save failed: {}",
            String::from_utf8_lossy(&output.stderr)
        );
    };
    let stored = || -> serde_json::Value {
        serde_json::from_str(
            &std::fs::read_to_string(
                home.join(".ballistics")
                    .join("profiles")
                    .join("scoped.json"),
            )
            .unwrap(),
        )
        .unwrap()
    };

    // A profile saved without the flag has no `reticle` key at all.
    save(&[]);
    assert!(stored().get("reticle").is_none(), "{}", stored());

    save(&["--reticle-json", path.to_str().unwrap()]);
    let attached: ReticleDescription = serde_json::from_value(stored()["reticle"].clone()).unwrap();
    assert_eq!(attached, reticle);

    // An unrelated re-save carries it forward.
    save(&["--sight-height", "2.2"]);
    assert_eq!(
        serde_json::from_value::<ReticleDescription>(stored()["reticle"].clone()).unwrap(),
        reticle
    );

    // `reticle hold --profile` finds it.
    let output = Command::new(BIN)
        .env("HOME", &home)
        .args([
            "reticle",
            "hold",
            "--profile",
            "scoped",
            "--drop-mil",
            "4",
            "--mag",
            "5",
            "-o",
            "json",
        ])
        .output()
        .expect("hold --profile");
    assert!(
        output.status.success(),
        "{}",
        String::from_utf8_lossy(&output.stderr)
    );
    let value: serde_json::Value =
        serde_json::from_str(&String::from_utf8_lossy(&output.stdout)).unwrap();
    assert_eq!(value["reticle"], "fixture");
    assert_eq!(value["nearest_mark"]["index"], 1);

    // --clear-reticle drops the key entirely.
    save(&["--clear-reticle"]);
    assert!(stored().get("reticle").is_none(), "{}", stored());

    // A profile with no reticle names the fix rather than solving with nothing.
    let output = Command::new(BIN)
        .env("HOME", &home)
        .args(["reticle", "hold", "--profile", "scoped", "--drop-mil", "4"])
        .output()
        .expect("hold --profile");
    assert!(!output.status.success());
    assert!(
        String::from_utf8_lossy(&output.stderr).contains("no attached reticle"),
        "{}",
        String::from_utf8_lossy(&output.stderr)
    );

    // The two attachment flags contradict each other.
    let output = Command::new(BIN)
        .env("HOME", &home)
        .args([
            "profile",
            "save",
            "scoped",
            "-v",
            "2700",
            "-b",
            "0.475",
            "-m",
            "168",
            "-d",
            "0.308",
            "--reticle-json",
            path.to_str().unwrap(),
            "--clear-reticle",
        ])
        .output()
        .expect("profile save");
    assert!(!output.status.success());
    assert!(
        String::from_utf8_lossy(&output.stderr).contains("mutually exclusive"),
        "{}",
        String::from_utf8_lossy(&output.stderr)
    );
}

const SOLVE_REQUEST: &str = r#"{"schema_version":1,
 "projectile":{"mass_kg":0.01134,"diameter_m":0.00782,"drag_model":"G7","ballistic_coefficient":0.243},
 "rifle":{"muzzle_velocity_mps":823.0,"sight_height_m":0.05,"muzzle_height_m":1.2},
 "shot":{"max_range_m":700.0},
 "atmosphere":{"altitude_m":0.0,"temperature_k":293.15,"pressure_pa":100000.0,"relative_humidity":0.4},
 "wind":{"speed_mps":4.47,"direction_from_rad":1.5707963267948966},
 "solver":{"method":"rk45","time_step_s":0.001},
 "effects":{"magnus":false,"coriolis":false,"enhanced_spin_drift":false},
 "sampling":{"interval_m":100.0}}"#;

fn solve_json(request: &str) -> (serde_json::Value, bool) {
    use std::io::Write;
    use std::process::Stdio;
    let mut child = Command::new(BIN)
        .arg("solve-json")
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .expect("solve-json");
    child
        .stdin
        .as_mut()
        .unwrap()
        .write_all(request.as_bytes())
        .unwrap();
    let output = child.wait_with_output().unwrap();
    (
        serde_json::from_slice(&output.stdout).unwrap_or_else(|_| {
            panic!(
                "solve-json emitted non-JSON: {}",
                String::from_utf8_lossy(&output.stdout)
            )
        }),
        output.status.success(),
    )
}

/// The `reticle` block is versioned-OPTIONAL: a request without it produces a response
/// with no `reticle_hold` key at all, and adding one changes nothing else in the response.
#[test]
fn solve_json_reticle_block_is_purely_additive() {
    let (plain, ok) = solve_json(SOLVE_REQUEST);
    assert!(ok, "{plain}");
    assert!(
        plain.get("reticle_hold").is_none(),
        "absent request block must leave the key absent, not null: {plain}"
    );

    let with_reticle = SOLVE_REQUEST.replace(
        "\"sampling\":{\"interval_m\":100.0}",
        "\"sampling\":{\"interval_m\":100.0},\
         \"reticle\":{\"range_m\":600.0,\"magnification\":5.0,\
         \"description\":{\"name\":\"fixture\",\"focal_plane\":\"sfp\",\
         \"reference_magnification\":10.0,\"marks\":[\
         {\"down_mil\":0.0,\"right_mil\":0.0,\"kind\":\"center\"},\
         {\"down_mil\":2.0,\"right_mil\":0.0,\"kind\":\"hash\",\"label\":\"600\"},\
         {\"down_mil\":4.0,\"right_mil\":0.0,\"kind\":\"hash\"}]}}",
    );
    let (mut held, ok) = solve_json(&with_reticle);
    assert!(ok, "{held}");
    let hold = held["reticle_hold"].clone();
    assert!(hold.is_object(), "{held}");
    assert_eq!(hold["range_m"], 600.0);
    assert_eq!(hold["magnification"], 5.0);
    assert_eq!(hold["mark_scale"], 2.0);
    // The hold must agree with the response's own samples at that range.
    let samples = held["samples"].as_array().unwrap();
    let at_600 = samples
        .iter()
        .find(|s| (s["distance_m"].as_f64().unwrap() - 600.0).abs() < 1e-9)
        .expect("a 600 m sample");
    let expected_down = at_600["drop_m"].as_f64().unwrap() / 600.0 * 1000.0;
    assert!(
        (hold["down_mil"].as_f64().unwrap() - expected_down).abs() < 1e-9,
        "{hold} vs sample {at_600}"
    );

    // Everything else is unchanged, apart from the Task 1 (0.33.0) resolved echo of the
    // reticle request itself: present (mirroring the request) only when the request
    // carried a reticle block.
    assert!(plain["resolved_request"].get("reticle").is_none());
    assert!(held["resolved_request"]["reticle"].is_object());
    held["reticle_hold"] = serde_json::Value::Null;
    held["resolved_request"]["reticle"] = serde_json::Value::Null;
    let mut plain_padded = plain.clone();
    plain_padded["reticle_hold"] = serde_json::Value::Null;
    plain_padded["resolved_request"]["reticle"] = serde_json::Value::Null;
    assert_eq!(
        held, plain_padded,
        "the reticle block must not move the solve"
    );
}

/// A hold requested beyond the sampled trajectory is a structured error, never an
/// extrapolation.
#[test]
fn solve_json_rejects_a_reticle_range_outside_the_trajectory() {
    let request = SOLVE_REQUEST.replace(
        "\"sampling\":{\"interval_m\":100.0}",
        "\"sampling\":{\"interval_m\":100.0},\
         \"reticle\":{\"range_m\":5000.0,\"magnification\":5.0,\
         \"description\":{\"name\":\"x\",\"focal_plane\":\"ffp\",\
         \"reference_magnification\":1.0,\"marks\":[\
         {\"down_mil\":2.0,\"right_mil\":0.0,\"kind\":\"hash\"}]}}",
    );
    let (response, ok) = solve_json(&request);
    assert!(!ok, "{response}");
    assert_eq!(response["status"], "error");
    assert_eq!(response["error"]["code"], "invalid_value");
    assert_eq!(response["error"]["path"], "$.reticle.range_m");

    // An unknown key inside the strict envelope is rejected too.
    let request = SOLVE_REQUEST.replace(
        "\"sampling\":{\"interval_m\":100.0}",
        "\"sampling\":{\"interval_m\":100.0},\
         \"reticle\":{\"range_m\":600.0,\"magnification\":5.0,\"mag\":3.0,\
         \"description\":{\"name\":\"x\",\"focal_plane\":\"ffp\",\
         \"reference_magnification\":1.0,\"marks\":[\
         {\"down_mil\":2.0,\"right_mil\":0.0,\"kind\":\"hash\"}]}}",
    );
    let (response, ok) = solve_json(&request);
    assert!(!ok, "{response}");
    assert_eq!(response["status"], "error");
}

/// MBA-1440: Bero's Vortex MBR dot-tree in the Ventum format — three `dot` rows, each a
/// horizontal mirrored `repeat`, expanding to a 78-mark FFP tree.
const VENTUM_MBR: &str = r#"{
  "name": "MBR",
  "plane": "ffp",
  "unit": "mil",
  "spec": [
    { "type":"dot", "y":4,  "x":1, "r":0.12, "repeat":{ "axis":"x","step":1,"n":9,  "mirror":true } },
    { "type":"dot", "y":8,  "x":1, "r":0.12, "repeat":{ "axis":"x","step":1,"n":13, "mirror":true } },
    { "type":"dot", "y":12, "x":1, "r":0.12, "repeat":{ "axis":"x","step":1,"n":17, "mirror":true } }
  ]
}"#;

/// `reticle import`'s stdout IS the shared formatter's string over the converter's own
/// output, byte for byte — the same MBA-1418 verbatim contract the generators are held to
/// above. Equality, not fragment checks, so a formatter drift can't slip through.
#[test]
fn import_output_is_the_shared_formatter_verbatim() {
    let dir = tempfile_dir("import-fmt");
    let path = dir.join("mbr.ventum.json");
    std::fs::write(&path, VENTUM_MBR).unwrap();

    let expected_desc = import_ventum_reticle(VENTUM_MBR).unwrap();
    for (flag, format) in [
        ("table", ReticleFormat::Table),
        ("json", ReticleFormat::Json),
    ] {
        let (stdout, stderr, ok) = run(&["reticle", "import", path.to_str().unwrap(), "-o", flag]);
        assert!(ok, "import -o {flag} failed: {stderr}");
        assert_eq!(
            stdout,
            format_reticle_description(&expected_desc, format),
            "import -o {flag} must be the shared formatter"
        );
    }
}

/// `reticle import <ventum> -o json` emits exactly what `hold --reticle-json` consumes: the
/// converted description drops straight into the hold surface with no reshaping. The MBR
/// expands to 78 FFP dots; a hold on the y=4 row lands on a real dot (distance 0).
#[test]
fn import_json_round_trips_into_hold() {
    let dir = tempfile_dir("import-roundtrip");
    let ventum = dir.join("mbr.ventum.json");
    std::fs::write(&ventum, VENTUM_MBR).unwrap();

    let (stdout, stderr, ok) = run(&["reticle", "import", ventum.to_str().unwrap(), "-o", "json"]);
    assert!(ok, "import failed: {stderr}");
    let parsed: ReticleDescription = serde_json::from_str(&stdout).unwrap();
    assert_eq!(parsed.name, "MBR");
    assert_eq!(parsed.focal_plane, FocalPlane::First);
    assert_eq!(parsed.marks.len(), 78);

    let canonical = dir.join("mbr.json");
    std::fs::write(&canonical, &stdout).unwrap();
    // (down 4, right 2) is a dot in the first (y=4) row; the hold lands exactly on it.
    let (hold_out, stderr, ok) = run(&[
        "reticle",
        "hold",
        "--reticle-json",
        canonical.to_str().unwrap(),
        "--drop-mil",
        "4.0",
        "--wind-mil",
        "2.0",
        "--mag",
        "10",
    ]);
    assert!(ok, "hold failed: {stderr}");
    assert!(
        hold_out.contains("distance from hold: 0.000 mil"),
        "{hold_out}"
    );
}

/// Import rejects file-level failures the way the rest of the surface does: a missing file,
/// a decoration-only spec that yields no holdable marks (`validate` catches it as `NoMarks`
/// rather than emitting an empty reticle), and malformed input.
#[test]
fn import_rejects_bad_inputs() {
    let dir = tempfile_dir("import-reject");

    // Missing file: the error names what it was reading.
    let missing = dir.join("nope.json");
    let (_, stderr, ok) = run(&["reticle", "import", missing.to_str().unwrap()]);
    assert!(!ok);
    assert!(stderr.contains("reading reticle file"), "{stderr}");

    // Decoration-only spec (a lone line) has no holdable marks -> rejected, not an empty reticle.
    let deco = dir.join("deco.ventum.json");
    std::fs::write(
        &deco,
        r#"{"name":"deco","plane":"ffp","unit":"mil","spec":[{"type":"line","x1":-5,"y1":0,"x2":5,"y2":0}]}"#,
    )
    .unwrap();
    let (_, stderr, ok) = run(&["reticle", "import", deco.to_str().unwrap()]);
    assert!(!ok, "decoration-only import should fail: {stderr}");

    // Malformed Ventum JSON.
    let bad = dir.join("bad.ventum.json");
    std::fs::write(&bad, "{not json").unwrap();
    let (_, stderr, ok) = run(&["reticle", "import", bad.to_str().unwrap()]);
    assert!(!ok, "malformed import should fail: {stderr}");
}

/// MBA-1441: an import that could not represent part of the document SAYS so. The failure
/// this guards is the one the ticket is named for — a Ventum reticle whose horseshoe vanished,
/// coming back sparse and looking correct.
#[test]
fn import_reports_what_it_could_not_represent() {
    let dir = tempfile_dir("import-report");
    let path = dir.join("horseshoe.ventum.json");
    std::fs::write(
        &path,
        r#"{"name":"HS","plane":"ffp","unit":"mil","spec":[
            {"type":"dot","x":0,"y":4},
            {"type":"line","x1":-5,"y1":0,"x2":5,"y2":0},
            {"type":"circle","x":0,"y":0,"r":2,"start":200,"end":340}
        ]}"#,
    )
    .unwrap();

    let (stdout, stderr, ok) = run(&["reticle", "import", path.to_str().unwrap(), "-o", "json"]);
    assert!(ok, "import failed: {stderr}");
    // The tally names both dropped types and their count.
    assert!(
        stderr.contains("2 element(s) carry no hold point"),
        "missing drop tally: {stderr}"
    );
    assert!(
        stderr.contains("arc x1"),
        "arc not named in the tally: {stderr}"
    );
    assert!(
        stderr.contains("line x1"),
        "line not named in the tally: {stderr}"
    );
    // The horseshoe's apex is printed in shooter terms: 2 mil UP (270 degrees is the top).
    assert!(
        stderr.contains("apex 0.00 / 2.00 up mil"),
        "arc apex not reported, or reported on the wrong side: {stderr}"
    );

    // stdout is still the formatter verbatim — the notice must never contaminate a piped
    // document (the same contract `import_output_is_the_shared_formatter_verbatim` pins).
    let parsed: ReticleDescription = serde_json::from_str(&stdout).unwrap();
    assert_eq!(parsed.marks.len(), 1, "the arc must not have become marks");
}

/// The other half of the contract: a document that imports whole stays quiet. A notice on
/// every import would train the user to ignore it.
#[test]
fn import_is_silent_when_nothing_was_dropped() {
    let dir = tempfile_dir("import-quiet");
    let path = dir.join("mbr.ventum.json");
    std::fs::write(&path, VENTUM_MBR).unwrap();

    let (_, stderr, ok) = run(&["reticle", "import", path.to_str().unwrap()]);
    assert!(ok, "import failed: {stderr}");
    assert!(
        !stderr.contains("carry no hold point"),
        "a fully imported reticle must not warn: {stderr}"
    );
}

/// MBA-1441, the other silence: a `circle` the importer cannot fully read must neither take
/// the document down nor vanish from the notice.
///
/// Both halves are pinned here because both were wrong at different times. A `circle` whose
/// `repeat` is unusable used to fail the whole import (the dot went with the ring); a `circle`
/// whose declared sweep is unusable used to be retagged a plain ring and reported nothing at
/// all, while the same loss on its radius WAS reported. The library tests pin the report
/// fields; this pins the sentences the user actually reads.
#[test]
fn import_reports_a_circle_it_could_only_partly_read() {
    let dir = tempfile_dir("import-lenient");
    let path = dir.join("lenient.ventum.json");
    std::fs::write(
        &path,
        r#"{"name":"L","plane":"ffp","unit":"mil","spec":[
            {"type":"dot","x":0,"y":4},
            {"type":"circle","x":0,"y":0,"r":2,"start":200,"end":"340deg"},
            {"type":"circle","x":0,"y":0,"r":1,"repeat":{"axis":"diagonal","step":1,"n":4}}
        ]}"#,
    )
    .unwrap();

    let (stdout, stderr, ok) = run(&["reticle", "import", path.to_str().unwrap(), "-o", "json"]);
    // It imports at all: neither circle may refuse the document its dot belongs to.
    assert!(
        ok,
        "a partly-readable circle must not fail the import: {stderr}"
    );
    let parsed: ReticleDescription = serde_json::from_str(&stdout).unwrap();
    assert_eq!(parsed.marks.len(), 1, "the dot survives both circles");

    // The unreadable sweep keeps the ARC tag -- it is not quietly demoted to `circle` -- and
    // is reported under the same line an unreadable radius is.
    assert!(
        stderr.contains("arc x1"),
        "the declared arc lost its tag: {stderr}"
    );
    assert!(
        stderr.contains("1 further arc(s) declared geometry this importer could not read"),
        "an unreadable sweep must be reported like an unreadable radius: {stderr}"
    );
    // And no arc points are printed, because none could be computed honestly.
    assert!(
        !stderr.contains("apex"),
        "no apex may be reported for an arc whose geometry could not be read: {stderr}"
    );

    // The unreadable repeat is counted once AND declared as a count that may be low.
    assert!(
        stderr.contains("circle x1"),
        "the repeated ring is not counted: {stderr}"
    );
    assert!(
        stderr.contains("1 circle element(s) declared a `repeat` this importer could not read"),
        "an unreadable repeat must be declared, not swallowed: {stderr}"
    );
}

/// MBA-1536: the arc line a user reads is a pair of clockwise bearings, for a mirrored twin as
/// much as for the arc the document drew.
///
/// A centered `start: 290, end: 70` horseshoe with `mirror: true` draws two shapes, and the
/// twin's angles are computed by reflection rather than read. Reflected raw they came out
/// `(110, -110)` and this line printed `arc 110--110 deg` — a double dash where the reader
/// expects a range, and a negative number in a field the API documents as degrees clockwise
/// from 3 o'clock. The library test pins the reported values; this pins the printed sentence,
/// which is where it was noticed.
#[test]
fn a_mirrored_arcs_printed_angles_read_as_a_range() {
    let dir = tempfile_dir("import-mirror-arc");
    let path = dir.join("mirror.ventum.json");
    std::fs::write(
        &path,
        r#"{"name":"M","plane":"ffp","unit":"mil","spec":[
            {"type":"dot","x":0,"y":4},
            {"type":"circle","x":0,"y":0,"r":2,"start":290,"end":70,
             "repeat":{"axis":"x","step":1,"n":1,"mirror":true}}
        ]}"#,
    )
    .unwrap();

    let (_, stderr, ok) = run(&["reticle", "import", path.to_str().unwrap(), "-o", "json"]);
    assert!(ok, "import failed: {stderr}");
    // Both shapes are still reported: the original as the document wrote it, the twin reduced.
    assert!(
        stderr.contains("arc 290-70 deg"),
        "the original arc's own angles must be printed as written: {stderr}"
    );
    assert!(
        stderr.contains("arc 110-250 deg"),
        "the twin's reflected angles must print as clockwise bearings: {stderr}"
    );
    // The shape of the defect, independent of the numbers above: no arc line may contain a
    // double dash, which is what a negative second bearing produced.
    for line in stderr
        .lines()
        .filter(|l| l.trim_start().starts_with("arc "))
    {
        assert!(
            !line.contains("--"),
            "an arc line must read as a range, not a double dash: {line}"
        );
    }
}
