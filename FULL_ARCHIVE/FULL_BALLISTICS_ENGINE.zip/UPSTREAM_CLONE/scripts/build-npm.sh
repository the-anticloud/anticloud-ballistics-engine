#!/usr/bin/env bash
# Build npm-publishable package(s) from the WASM (wasm-bindgen) build (MBA-1321).
#
# NOT THE PUBLISH PATH. This script builds both wasm-bindgen targets side by side so the two
# shapes can be compared; it does not publish, and neither of its outputs is what ships.
#
# The package on npm — `ballistics-engine` — is the WEB build, produced and verified by
# scripts/release/npm-package.sh and published by .github/workflows/publish-npm.yml on a v* tag
# (MBA-1434, OIDC trusted publishing, no token). The "meant for npm publish" note on pkg/ below
# is how this was expected to go in MBA-1321, before the package existed; the first real publish
# went out of deploy-wasm.sh's --target web output instead and every version since has matched
# it. Do not "fix" that by publishing pkg/: the web build's entry point takes an explicit
# `await init()` and the bundler build's does not, so swapping them breaks every consumer's
# import inside a patch release. See RELEASE.md, "The npm channel".
#
# Produces two directories at the repo root, both gitignored and rebuilt from scratch on every
# run (safe to delete and re-run):
#
#   pkg/      --target bundler   The package meant for `npm publish`. Consumed via a native
#             `.wasm` ES import by bundlers that understand it (webpack with
#             experiments.asyncWebAssembly, Vite, Rollup + @rollup/plugin-wasm, Parcel).
#
#   pkg-web/  --target web       No-bundler build for direct `<script type="module">` browser
#             use or manual Node usage without a bundler. This is the SAME --target already
#             used to build ballistics.sh/ballistics.rs's WASM (see this repo's CLAUDE.md).
#             Documented and built here for completeness, but not published under the primary
#             package name in this PREP pass — see README.md.
#
# Why two directories instead of one dual-target npm package: `wasm-pack build --help` (checked
# against 0.13.1) takes exactly one `--target` per invocation and has no "build both" or "dual
# publish" mode. Stitching a bundler build and a web build into one package.json via manual
# "exports" conditions is possible in principle, but wasm-bindgen's bundler- and web-target
# output use different module wiring (the bundler target imports the .wasm file directly and
# expects the bundler to instantiate it; the web target ships an explicit async `init()` that
# fetches it) and wasm-pack itself doesn't generate or test that wiring for you. A single
# bundler-target package as the npm-published artifact — with the web build documented
# separately for the no-bundler case — is the ecosystem-standard shape for wasm-bindgen crates
# published to npm, and is what this script does.
#
# Both builds use --no-default-features: the crate's default `pdf`/`online` features pull in
# printpdf / ureq+ring, which do not compile for wasm32-unknown-unknown.
#
# Both go through scripts/build-wasm.sh rather than calling wasm-pack directly. That script
# defaults to the FULL terminal and verifies the emitted .wasm actually carries every gateable
# command, so the published package cannot silently ship as trajectory-only. Embedders who want
# a smaller module select their own subset with the same script -- see README.md's
# "Trimming the WASM module".
set -euo pipefail

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
repo_root="$(cd "$script_dir/.." && pwd)"
cd "$repo_root"

bundler_dir="pkg"
web_dir="pkg-web"

command -v wasm-pack >/dev/null 2>&1 || {
  echo "error: wasm-pack not found on PATH (https://rustwasm.github.io/wasm-pack/installer/)" >&2
  exit 1
}
command -v node >/dev/null 2>&1 || {
  echo "error: node not found on PATH (needed to post-process package.json, and to run npm pack/publish)" >&2
  exit 1
}

echo "==> building bundler target -> ${bundler_dir}/"
./scripts/build-wasm.sh --preset full --target bundler --out-dir "$bundler_dir"

echo "==> building web target -> ${web_dir}/"
./scripts/build-wasm.sh --preset full --target web --out-dir "$web_dir"

echo "==> post-processing ${bundler_dir}/package.json"
node "$script_dir/build-npm-postprocess.mjs" "$repo_root/$bundler_dir/package.json" "ballistics-engine"

echo "==> post-processing ${web_dir}/package.json"
node "$script_dir/build-npm-postprocess.mjs" "$repo_root/$web_dir/package.json" "ballistics-engine-web"

echo "==> installing README-npm.md as the package README"
cp "$repo_root/README-npm.md" "$repo_root/$bundler_dir/README.md"
cp "$repo_root/README-npm.md" "$repo_root/$web_dir/README.md"

cat <<EOF

==> done.

  ${bundler_dir}/      (bundler target -- for comparison; NOT what is published)
  ${web_dir}/  (web target -- the shape that IS published, as "ballistics-engine")

Neither directory is published from here. npm publishing is automated on a v* tag by
.github/workflows/publish-npm.yml, from the directory scripts/release/npm-package.sh
builds. To inspect what a release would actually ship:

  scripts/release/npm-package.sh X.Y.Z /tmp/npm-X.Y.Z
  npm pack --dry-run /tmp/npm-X.Y.Z

Compare the two tarballs here without publishing either:
  npm pack --dry-run ./${bundler_dir} && npm pack --dry-run ./${web_dir}
EOF
