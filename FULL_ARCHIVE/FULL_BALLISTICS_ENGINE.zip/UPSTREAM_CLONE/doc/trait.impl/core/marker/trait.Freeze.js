(function() {
    var implementors = Object.fromEntries([["drag_model",[["impl <a class=\"trait\" href=\"https://doc.rust-lang.org/1.89.0/core/marker/trait.Freeze.html\" title=\"trait core::marker::Freeze\">Freeze</a> for <a class=\"enum\" href=\"drag_model/enum.DragModel.html\" title=\"enum drag_model::DragModel\">DragModel</a>",1,["drag_model::DragModel"]]]]]);
    if (window.register_implementors) {
        window.register_implementors(implementors);
    } else {
        window.pending_implementors = implementors;
    }
})()
//{"start":57,"fragment_lengths":[305]}